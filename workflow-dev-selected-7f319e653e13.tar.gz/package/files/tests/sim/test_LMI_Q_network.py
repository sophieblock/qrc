from workflow.simulation.data import Data
from workflow.simulation.graph import Node, Network
from workflow.simulation.resources.classical_device import ClassicalDevice
from workflow.simulation.Process_Library.LMI_Q import *
from workflow.simulation.broker import Broker
from workflow.simulation.quantum import QuantumCircuit
from workflow.simulation.devices.quantum_devices import *

import pytest
import random

nm = 1e-7
ns = 1e-9
nb0 = 1 / 4
lambda00 = 585 * nm
sigma00 = 1 * ns
N_sigma00 = 4

c00 = 299792458e2
k00 = 2 * np.pi / lambda00
omega00 = c00 * k00

NF = 5


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    broker = Broker(
        classical_devices=[supercomputer],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
    )
    return broker


def test_get_pauli_decomp_sp():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    starting_inputs = [
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
        Data(data=detunings, properties={"Usage": "Mode Detunings"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
        Data(data="Schrodinger", properties={"Usage": "Framework"}),
    ]

    init_pulse = LMI_GetPauliDecomposition(inputs=starting_inputs)
    init_pulse.update()

    output_data = init_pulse.generate_output()

    usage_properties = [data.properties["Usage"] for data in output_data]
    expected_properties = [
        "Free Terms",
        "Interaction Terms",
        "Truncation Parameter",
    ]

    assert len(usage_properties) == len(expected_properties)
    assert all(property in expected_properties for property in usage_properties)

    for data in output_data:
        if data.properties["Usage"] == "Truncation Parameter":
            assert data.data == 2


def test_get_pauli_groupings_sp_network():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    starting_inputs = [
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
        Data(data=detunings, properties={"Usage": "Mode Detunings"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
        Data(data="Schrodinger", properties={"Usage": "Framework"}),
    ]

    pauli_decomp = Node(process_model=LMI_GetPauliDecomposition)
    pauli_group = Node(process_model=LMI_GetPauliGroupings)

    pauli_decomp.insert_output_node(pauli_group)

    network = Network(
        nodes=[pauli_decomp, pauli_group],
        input_nodes=[pauli_decomp],
        output_nodes=[pauli_group],
        broker=gen_broker(),
    )
    network.run(starting_nodes=[pauli_decomp], starting_inputs=[starting_inputs])

    assert isinstance(network.output_nodes[0].output_edges[0].data[0].data, dict)

    for key, val in network.output_nodes[0].output_edges[0].data[0].data.items():
        if key[1] == 1:
            assert len(val) == 0
        elif key[0] == 1:
            assert len(val) == 5
        elif key[0] == 2:
            assert len(val) == 15
        else:
            raise ValueError


def test_construct_trotter_sp_network():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    time = random.uniform(0.0, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data="Schrodinger", properties={"Usage": "Framework"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=float(time), properties={"Usage": "Trotter Timestep"}),
        ],
    ]

    pauli_decomp = Node(
        process_model=LMI_GetPauliDecomposition,
        evolution_time=time,
    )
    pauli_group = Node(process_model=LMI_GetPauliGroupings)
    trotter = Node(
        process_model=LMI_ConstructTrotter,
        framework="Schrodinger",
        trotter_step=0,
    )

    pauli_decomp.insert_output_node(pauli_group)
    pauli_decomp.insert_output_node(trotter)
    pauli_group.insert_output_node(trotter)

    network = Network(
        nodes=[pauli_decomp, pauli_group, trotter],
        input_nodes=[pauli_decomp, trotter],
        output_nodes=[trotter],
        broker=gen_broker(),
    )
    network.run(starting_nodes=[pauli_decomp, trotter], starting_inputs=starting_inputs)

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Trotter Circuit"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Step"] == 0
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )


def test_concat_circuit_sp_network():
    picture = "Schrodinger"
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    times = list(np.linspace(0.0, random.uniform(0.1, 1e3), 3))
    delta_t = float(times[1] - times[0])
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data=picture, properties={"Usage": "Framework"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [Data(data=float(times[-1]), properties={"Usage": "Evolution Time"})],
    ]

    pauli_decomp = Node(process_model=LMI_GetPauliDecomposition)
    groupings = Node(process_model=LMI_GetPauliGroupings)

    trotter_list = [
        Node(
            process_model=LMI_ConstructTrotter,
            framework=picture,
            trotter_step=step,
        )
        for step in range(3)
    ]

    concat_circ = Node(
        process_model=LMI_ConcatCircuit,
        framework=picture,
        trotter_steps=3,
    )

    pauli_decomp.insert_output_node(groupings)

    for node in trotter_list:
        pauli_decomp.insert_output_node(node)
        groupings.insert_output_node(node)
        node.insert_output_node(concat_circ)

    network = Network(
        nodes=[pauli_decomp, groupings, concat_circ] + trotter_list,
        input_nodes=[pauli_decomp, concat_circ] + trotter_list,
        output_nodes=[concat_circ],
        broker=gen_broker(),
    )
    network.run(
        starting_nodes=[pauli_decomp] + trotter_list + [concat_circ],
        starting_inputs=starting_inputs,
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in trotter_list:
        circuit: QuantumCircuit = node.output_edges[0].data[0].data
        circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    assert len(final_circuit.instructions) == circuit_depth


def test_init_QC_sp_network():
    picture = "Schrodinger"
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    evolution_time = random.uniform(0.1, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data=picture, properties={"Usage": "Framework"}),
            Data(data=evolution_time, properties={"Usage": "Evolution Time"}),
            Data(data=3, properties={"Usage": "Trotter Steps"}),
            Data(data=1, properties={"Usage": "Trotter Order"}),
        ]
    ]

    init_circ = Node(process_model=LMI_InitQuantumCircuit)

    network = Network(
        nodes=[init_circ],
        input_nodes=[init_circ],
        output_nodes=[],
        broker=gen_broker(),
    )
    network.run(starting_nodes=[init_circ], starting_inputs=starting_inputs)

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    assert len(final_circuit.instructions) == circuit_depth


def test_init_QC_sp_network_order_2():
    picture = "Schrodinger"
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    evolution_time = random.uniform(0.1, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data=picture, properties={"Usage": "Framework"}),
            Data(data=evolution_time, properties={"Usage": "Evolution Time"}),
            Data(data=3, properties={"Usage": "Trotter Steps"}),
            Data(data=2, properties={"Usage": "Trotter Order"}),
        ]
    ]

    init_circ = Node(process_model=LMI_InitQuantumCircuit)

    network = Network(
        nodes=[init_circ],
        input_nodes=[init_circ],
        output_nodes=[],
        broker=gen_broker(),
    )
    network.run(
        starting_nodes=[init_circ], starting_inputs=starting_inputs, simulate=False
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    assert len(final_circuit.instructions) == circuit_depth


def test_get_pauli_decomp_ip():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    starting_inputs = [
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
        Data(data=detunings, properties={"Usage": "Mode Detunings"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
        Data(data="Interaction", properties={"Usage": "Framework"}),
    ]

    time = random.uniform(0.1, 1e3)
    pauli_decomp = LMI_GetPauliDecomposition(
        inputs=starting_inputs, evolution_time=time
    )
    pauli_decomp.update()
    output_data = pauli_decomp.generate_output()

    usage_properties = [data.properties["Usage"] for data in output_data]
    expected_properties = [
        "Free Terms",
        "Interaction Terms",
        "Truncation Parameter",
    ]

    assert len(usage_properties) == len(expected_properties)
    assert all(property in expected_properties for property in usage_properties)

    for data in output_data:
        if data.properties["Usage"] == "Truncation Parameter":
            assert data.data == 2


def test_get_pauli_groupings_ip_network():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    time = random.uniform(0.1, 1e3)
    starting_inputs = [
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
        Data(data=detunings, properties={"Usage": "Mode Detunings"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
        Data(data="Interaction", properties={"Usage": "Framework"}),
    ]

    pauli_decomp = Node(
        process_model=LMI_GetPauliDecomposition,
        evolution_time=time,
    )
    pauli_group = Node(process_model=LMI_GetPauliGroupings)

    pauli_decomp.insert_output_node(pauli_group)

    network = Network(
        nodes=[pauli_decomp, pauli_group],
        input_nodes=[pauli_decomp],
        output_nodes=[pauli_group],
        broker=gen_broker(),
    )
    network.run(starting_nodes=[pauli_decomp], starting_inputs=[starting_inputs])

    assert isinstance(network.output_nodes[0].output_edges[0].data[0].data, dict)
    assert len(network.output_nodes[0].output_edges[0].data[0].data.keys()) > 0
    for key, val in network.output_nodes[0].output_edges[0].data[0].data.items():
        if key[0] == 1 and key[1] == 0:
            assert len(val) == 5
        elif key[0] == 1 and key[1] == 1:
            assert len(val) == 4
        elif key[0] == 2 and key[1] == 0:
            assert len(val) == 15
        elif key[0] == 2 and key[1] == 1:
            assert len(val) == 12
        else:
            raise ValueError


def test_construct_trotter_ip_network():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    time = random.uniform(0.1, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data="Interaction", properties={"Usage": "Framework"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=time, properties={"Usage": "Trotter Timestep"}),
        ],
    ]

    pauli_decomp = Node(
        process_model=LMI_GetPauliDecomposition,
        evolution_time=time,
    )
    pauli_group = Node(process_model=LMI_GetPauliGroupings)
    trotter = Node(
        process_model=LMI_ConstructTrotter,
        framework="Interaction",
        trotter_step=0,
    )

    pauli_decomp.insert_output_node(pauli_group)
    pauli_group.insert_output_node(trotter)

    network = Network(
        nodes=[pauli_decomp, pauli_group, trotter],
        input_nodes=[pauli_decomp, trotter],
        output_nodes=[trotter],
        broker=gen_broker(),
    )
    network.run(starting_nodes=[pauli_decomp, trotter], starting_inputs=starting_inputs)

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Trotter Circuit"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Step"] == 0
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )


def test_concat_circuit_ip_network():
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    times = list(np.linspace(0.0, random.uniform(0.1, 1e3), 3))
    delta_t = float(times[1] - times[0])
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data="Interaction", properties={"Usage": "Framework"}),
        ],
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data="Interaction", properties={"Usage": "Framework"}),
        ],
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data="Interaction", properties={"Usage": "Framework"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [
            Data(data=1, properties={"Usage": "Trotter Order"}),
            Data(data=delta_t, properties={"Usage": "Trotter Timestep"}),
        ],
        [Data(data=float(times[-1]), properties={"Usage": "Evolution Time"})],
    ]

    pauli_decomp_list = [
        Node(
            process_model=LMI_GetPauliDecomposition,
            evolution_time=time,
        )
        for time in times
    ]
    concat_circ = Node(
        process_model=LMI_ConcatCircuit,
        framework="Interaction",
        trotter_steps=3,
    )

    groups_list = [Node(process_model=LMI_GetPauliGroupings) for _ in range(len(times))]
    trotter_list = [
        Node(
            process_model=LMI_ConstructTrotter,
            framework="Interaction",
            trotter_step=step,
        )
        for step in range(3)
    ]

    for idx in range(len(pauli_decomp_list)):
        group = groups_list[idx]
        trotter = trotter_list[idx]

        pauli_decomp_list[idx].insert_output_node(group)
        pauli_decomp_list[idx].insert_output_node(concat_circ)
        group.insert_output_node(trotter)
        trotter.insert_output_node(concat_circ)

    network = Network(
        nodes=[concat_circ] + pauli_decomp_list + groups_list + trotter_list,
        input_nodes=pauli_decomp_list + trotter_list + [concat_circ],
        output_nodes=[concat_circ],
        broker=gen_broker(),
    )
    network.run(
        starting_nodes=pauli_decomp_list + trotter_list + [concat_circ],
        starting_inputs=starting_inputs,
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in trotter_list:
        circuit: QuantumCircuit = node.output_edges[0].data[0].data
        circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    qubits_per_photon = 2
    qubits_per_emitter = 1
    assert (
        len(final_circuit.instructions)
        == circuit_depth + NF * qubits_per_photon + qubits_per_emitter
    )


def test_init_QC_ip_network():
    picture = "Interaction"
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    evolution_time = random.uniform(0.1, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data=picture, properties={"Usage": "Framework"}),
            Data(data=evolution_time, properties={"Usage": "Evolution Time"}),
            Data(data=3, properties={"Usage": "Trotter Steps"}),
            Data(data=1, properties={"Usage": "Trotter Order"}),
        ]
    ]

    init_circ = Node(process_model=LMI_InitQuantumCircuit)

    network = Network(
        nodes=[init_circ],
        input_nodes=[init_circ],
        output_nodes=[],
        broker=gen_broker(),
    )
    network.run(
        starting_nodes=[init_circ], starting_inputs=starting_inputs, simulate=False
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    qubits_per_photon = 2
    qubits_per_emitter = 1
    assert (
        len(final_circuit.instructions)
        == circuit_depth + NF * qubits_per_photon + qubits_per_emitter
    )


def test_init_QC_ip_network_order_2():
    picture = "Interaction"
    detunings = [
        np.float64(-3.902699913818379e-07),
        np.float64(-1.9513499569091894e-07),
        np.float64(0.0),
        np.float64(1.9513499569091894e-07),
        np.float64(3.902699913818379e-07),
    ]
    gamma = 1.2195937230682433e-07
    evolution_time = random.uniform(0.1, 1e3)
    starting_inputs = [
        [
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=detunings, properties={"Usage": "Mode Detunings"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=gamma, properties={"Usage": "Interaction Strengths"}),
            Data(data=picture, properties={"Usage": "Framework"}),
            Data(data=evolution_time, properties={"Usage": "Evolution Time"}),
            Data(data=3, properties={"Usage": "Trotter Steps"}),
            Data(data=2, properties={"Usage": "Trotter Order"}),
        ]
    ]

    init_circ = Node(process_model=LMI_InitQuantumCircuit)

    network = Network(
        nodes=[init_circ],
        input_nodes=[init_circ],
        output_nodes=[],
        broker=gen_broker(),
    )
    network.run(
        starting_nodes=[init_circ], starting_inputs=starting_inputs, simulate=False
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    qubits_per_photon = 2
    qubits_per_emitter = 1
    assert (
        len(final_circuit.instructions)
        == circuit_depth + NF * qubits_per_photon + qubits_per_emitter
    )
