from workflow.simulation.data import Data
from workflow.simulation.graph import Node, DirectedEdge, Network
from workflow.simulation.resources.classical_device import ClassicalDevice
from workflow.simulation.broker import Broker
from workflow.simulation.Process_Library.matrix_ops import (
    MatrixMult,
    ConcatMatrix,
    GenVector,
)
import pytest


def generate_vector(rows, cols, vec_orientation, dtype):
    vector_rows = Data(rows, {"Usage": "Vector Rows"})
    vector_cols = Data(cols, {"Usage": "Vector Columns"})
    orientation = Data(vec_orientation, {"Usage": "Vector Orientation"})
    element_type = Data(dtype, {"Usage": "Element Type"})

    return GenVector(inputs=[vector_rows, vector_cols, orientation, element_type])


def generate_vector_alt_order(rows, cols, vec_orientation, dtype):
    vector_rows = Data(rows, {"Usage": "Vector Rows"})
    vector_cols = Data(cols, {"Usage": "Vector Columns"})
    orientation = Data(vec_orientation, {"Usage": "Vector Orientation"})
    element_type = Data(dtype, {"Usage": "Element Type"})

    return GenVector(inputs=[orientation, vector_rows, element_type, vector_cols])


def test_generate_vector():
    vec = generate_vector(1, 5, "Row Vector", float)


def test_generate_vector_alt_order():
    vec = generate_vector(1, 5, "Row Vector", float)
    alt_vec = generate_vector_alt_order(1, 5, "Row Vector", float)

    assert vec.validate_data()
    assert alt_vec.validate_data()

    vec.update()
    alt_vec.update()

    assert vec.result.rows == alt_vec.result.rows
    assert vec.result.cols == alt_vec.result.cols
    assert vec.result.element_type == alt_vec.result.element_type


def test_concat_matrix_row():
    vec1 = generate_vector(1, 5, "Row Vector", float)
    vec2 = generate_vector(2, 5, "Row Vector", float)

    vec1.update()
    mat1 = vec1.generate_output()[0]

    vec2.update()
    mat2 = vec2.generate_output()[0]
    concat_mat = ConcatMatrix(inputs=[mat1, mat2])

    assert concat_mat.validate_data()
    concat_mat.update()
    result = concat_mat.generate_output()

    assert result[0].data.rows == 3
    assert result[0].data.cols == 5
    assert result[0].properties["Vector Orientation"] == "Row Vector"
    # assert result[0].data.element_type == float


def test_concat_matrix_col():
    vec1 = generate_vector(5, 1, "Column Vector", float)
    vec2 = generate_vector(5, 2, "Column Vector", float)

    vec1.update()
    mat1 = vec1.generate_output()[0]

    vec2.update()
    mat2 = vec2.generate_output()[0]
    concat_mat = ConcatMatrix(inputs=[mat1, mat2])

    assert concat_mat.validate_data()
    concat_mat.update()
    result = concat_mat.generate_output()

    assert result[0].data.rows == 5
    assert result[0].data.cols == 3
    assert result[0].properties["Vector Orientation"] == "Column Vector"
    # assert result[0].data.element_type == float


def prepare_genvec_input_edges(node: Node, rows, cols, vec_orientation, dtype):
    input_edge = DirectedEdge(
        data=(
            Data(rows, {"Usage": "Vector Rows"}),
            Data(cols, {"Usage": "Vector Columns"}),
            Data(vec_orientation, {"Usage": "Vector Orientation"}),
            Data(dtype, {"Usage": "Element Type"}),
        ),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge)


def generate_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 20, "Clock Speed": 3 * 10**9},
    )

    broker = Broker(classical_devices=[supercomputer])
    return broker


def test_concat_matrix_network():
    genvec_node1 = Node(id=None, process_model=GenVector)
    genvec_node2 = Node(id=None, process_model=GenVector)
    concat_node = Node(id=None, process_model=ConcatMatrix)

    genvec_node1.insert_output_node(concat_node)
    genvec_node2.insert_output_node(concat_node)

    starting_inputs = [
        [
            Data(1, {"Usage": "Vector Rows"}),
            Data(5, {"Usage": "Vector Columns"}),
            Data("Row Vector", {"Usage": "Vector Orientation"}),
            Data(float, {"Usage": "Element Type"}),
        ],
        [
            Data(2, {"Usage": "Vector Rows"}),
            Data(5, {"Usage": "Vector Columns"}),
            Data("Row Vector", {"Usage": "Vector Orientation"}),
            Data(float, {"Usage": "Element Type"}),
        ],
    ]

    network = Network(
        "Concatenate Matrices",
        nodes=[genvec_node1, genvec_node2, concat_node],
        input_nodes=[genvec_node1, genvec_node2],
        output_nodes=[concat_node],
        broker=generate_broker(),
    )

    results = network.run(network.input_nodes, starting_inputs)

    assert len(concat_node.output_edges) == 1
    output_edge = concat_node.output_edges[0]
    result = output_edge.data[0]
    assert result.data.rows == 3
    assert result.data.cols == 5
    assert result.properties["Vector Orientation"] == "Row Vector"

    assert results.raw.loc[0]["Start Time [s]"] == 0.0
    assert (
        results.raw.loc[0]["End Time [s]"]
        == genvec_node1.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[0]["Memory Cost [B]"]
        == genvec_node1.process.required_resources.memory
    )

    assert results.raw.loc[1]["Start Time [s]"] == 0.0
    assert (
        results.raw.loc[1]["End Time [s]"]
        == genvec_node2.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[1]["Memory Cost [B]"]
        == genvec_node2.process.required_resources.memory
    )

    assert results.raw.loc[2]["Start Time [s]"] == max(
        results.raw.loc[0]["End Time [s]"], results.raw.loc[1]["End Time [s]"]
    )
    assert (
        results.raw.loc[2]["End Time [s]"]
        == results.raw.loc[2]["Start Time [s]"]
        + concat_node.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[2]["Memory Cost [B]"]
        == concat_node.process.required_resources.memory
    )


def generate_concat_matrix_network(row1, col1, row2, col2, orientation):
    genvec_node1 = Node(id=None, process_model=GenVector)
    genvec_node2 = Node(id=None, process_model=GenVector)
    concat_node = Node(id=None, process_model=ConcatMatrix)

    genvec_node1.insert_output_node(concat_node)
    genvec_node2.insert_output_node(concat_node)

    prepare_genvec_input_edges(genvec_node1, row1, col1, orientation, float)
    prepare_genvec_input_edges(genvec_node2, row2, col2, orientation, float)

    return Network(
        "Concatenate Matrices",
        nodes=[genvec_node1, genvec_node2, concat_node],
        input_nodes=[genvec_node1, genvec_node2],
        output_nodes=[concat_node],
        broker=generate_broker(),
    )


def test_combine_network():
    network1 = generate_concat_matrix_network(1, 5, 2, 5, "Row Vector")
    network2 = generate_concat_matrix_network(3, 5, 4, 5, "Row Vector")
    network = network1 @ network2

    assert network.input_nodes == network1.input_nodes + network2.input_nodes
    assert network.output_nodes == network1.output_nodes + network2.output_nodes
    assert len(network.broker.classical_devices) == 1
    assert network.broker.classical_devices == network1.broker.classical_devices
    assert network.broker.classical_devices == network2.broker.classical_devices


def test_extend_network_output_node():
    network1 = generate_concat_matrix_network(1, 5, 2, 5, "Row Vector")
    network2 = generate_concat_matrix_network(3, 5, 4, 5, "Row Vector")
    network = network1 @ network2

    concat_node = Node(id=None, process_model=ConcatMatrix)
    network.extend_node_destination(
        network1.output_nodes + network2.output_nodes, concat_node
    )

    assert network.output_nodes[0] == concat_node
    assert network1.output_nodes[0].output_nodes == [concat_node]
    assert network2.output_nodes[0].output_nodes == [concat_node]


def test_combine_concat_matrix_networks():
    network1 = generate_concat_matrix_network(1, 5, 2, 5, "Row Vector")
    network2 = generate_concat_matrix_network(3, 5, 4, 5, "Row Vector")
    network = network1 @ network2

    concat_node = Node(id=None, process_model=ConcatMatrix)
    network.extend_node_destination(
        network1.output_nodes + network2.output_nodes, concat_node
    )

    results = network.run(network.input_nodes)

    assert len(concat_node.output_edges) == 1
    output_edge = concat_node.output_edges[0]
    result = output_edge.data[0]
    assert result.data.rows == 10
    assert result.data.cols == 5
    assert result.properties["Vector Orientation"] == "Row Vector"
    # assert result.data.element_type == float

    def get_dataframe_node(dataframe_idx) -> Node:
        return network.get_node(results.raw.loc[dataframe_idx]["Node Idx"])[0]

    ## verify start time, end time and memory costs for genvector (first 4 rows in df)
    for df_idx in range(4):
        node: Node = get_dataframe_node(df_idx)
        assert results.raw.loc[df_idx]["Start Time [s]"] == 0.0
        assert (
            results.raw.loc[df_idx]["End Time [s]"]
            == node.process.compute_flop_count()
            / network.broker.classical_devices[0].clock_frequency
        )
        assert (
            results.raw.loc[df_idx]["Memory Cost [B]"]
            == node.process.required_resources.memory
        )

    # ConcatMatrix begins when its GenVectors complete:
    node: Node = get_dataframe_node(4)
    assert results.raw.loc[4]["Start Time [s]"] == max(
        results.raw.loc[0]["End Time [s]"], results.raw.loc[1]["End Time [s]"]
    )
    assert (
        results.raw.loc[4]["End Time [s]"]
        == results.raw.loc[4]["Start Time [s]"]
        + node.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[4]["Memory Cost [B]"] == node.process.required_resources.memory
    )

    node: Node = get_dataframe_node(5)
    assert results.raw.loc[5]["Start Time [s]"] == max(
        results.raw.loc[2]["End Time [s]"], results.raw.loc[3]["End Time [s]"]
    )
    assert (
        results.raw.loc[5]["End Time [s]"]
        == results.raw.loc[5]["Start Time [s]"]
        + node.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[5]["Memory Cost [B]"] == node.process.required_resources.memory
    )

    # MatrixMult begins when both ConcatMatrix completes:
    node: Node = get_dataframe_node(6)
    assert results.raw.loc[6]["Start Time [s]"] == max(
        results.raw.loc[4]["End Time [s]"], results.raw.loc[5]["End Time [s]"]
    )
    assert (
        results.raw.loc[6]["End Time [s]"]
        == results.raw.loc[6]["Start Time [s]"]
        + node.process.compute_flop_count()
        / network.broker.classical_devices[0].clock_frequency
    )
    assert (
        results.raw.loc[6]["Memory Cost [B]"] == node.process.required_resources.memory
    )


def test_combine_matmul_matrix_networks():
    base_network1 = generate_concat_matrix_network(5, 1, 5, 2, "Column Vector")
    base_network2 = generate_concat_matrix_network(5, 3, 5, 2, "Column Vector")
    concat_network1 = base_network1 @ base_network2

    concat_node = Node(id=None, process_model=ConcatMatrix)
    concat_network1.extend_node_destination(
        base_network1.output_nodes + base_network2.output_nodes, concat_node
    )

    base_network1 = generate_concat_matrix_network(1, 5, 2, 5, "Row Vector")
    base_network2 = generate_concat_matrix_network(3, 5, 4, 5, "Row Vector")
    concat_network2 = base_network1 @ base_network2

    concat_node = Node(id=None, process_model=ConcatMatrix)
    concat_network2.extend_node_destination(
        base_network1.output_nodes + base_network2.output_nodes, concat_node
    )

    matmul_network = concat_network1 @ concat_network2
    matmul_node = Node(id=None, process_model=MatrixMult)
    matmul_network.extend_node_destination(
        concat_network1.output_nodes + concat_network2.output_nodes, matmul_node
    )

    matmul_network.run(matmul_network.input_nodes)

    assert len(matmul_node.output_edges) == 1
    output_edge = matmul_node.output_edges[0]
    result = output_edge.data[0]
    assert result.data.rows == 10
    assert result.data.cols == 8
    # assert result.data.element_type == float


def test_add_matmul_matrix_networks():
    base_network1 = generate_concat_matrix_network(5, 1, 5, 2, "Column Vector")
    base_network2 = generate_concat_matrix_network(5, 3, 5, 2, "Column Vector")
    concat_network1 = base_network1 @ base_network2

    for output_node in concat_network1.output_nodes:
        output_node.process.output_properties[0]["Vector Orientation"] = "Column Vector"

    base_network1 = generate_concat_matrix_network(1, 5, 2, 5, "Row Vector")
    base_network2 = generate_concat_matrix_network(3, 5, 4, 5, "Row Vector")
    concat_network2 = base_network1 @ base_network2

    # for output_node in concat_network2.output_nodes:
    #     output_node.output_edges[0].data[0].properties[
    #         "Vector Orientation"
    #     ] = "Row Vector"

    for output_node in concat_network2.output_nodes:
        output_node.process.output_properties[0]["Vector Orientation"] = "Row Vector"

    input_network = concat_network1 @ concat_network2

    concat_node1 = Node(id=None, process_model=ConcatMatrix)
    concat_node2 = Node(id=None, process_model=ConcatMatrix)
    matmul_node = Node(id=None, process_model=MatrixMult)

    concat_node1.insert_output_node(matmul_node)
    concat_node2.insert_output_node(matmul_node)
    output_network = Network(
        name="Concat and Matrix Mult",
        nodes=[concat_node1, concat_node2, matmul_node],
        input_nodes=[concat_node1, concat_node2],
        output_nodes=[matmul_node],
        broker=generate_broker(),
    )

    # We want to add the outputs of input_network (2 column and 2 row matrices) as the inputs
    # of output_network which consists of 2 matrix concatenate nodes and a final matrix mult node.
    # Since the edge-to-node assignments are ambiguous at this point, we will add additional
    # expected_input_properties to include "Vertex Orientation"

    for input_property in output_network.input_nodes[0].expected_input_properties:
        input_property["Vector Orientation"] = "Row Vector"
    for input_property in output_network.input_nodes[1].expected_input_properties:
        input_property["Vector Orientation"] = "Column Vector"

    network = input_network + output_network

    assert len(network.input_nodes) == 8
    assert len(network.output_nodes) == 1
    assert len(network.broker.classical_devices) == 1
    assert network.broker.classical_devices == input_network.broker.classical_devices
    assert network.broker.classical_devices == output_network.broker.classical_devices

    df = network.run(network.input_nodes)

    assert len(network.output_nodes[0].output_edges) == 1
    output_edge = network.output_nodes[0].output_edges[0]
    result = output_edge.data[0]
    assert result.data.rows == 10
    assert result.data.cols == 8
    # assert result.data.element_type == float
