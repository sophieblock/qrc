from workflow.simulation.data import Data
from workflow.simulation.resources.classical_device import ClassicalDevice
from workflow.simulation.resources.personnel import Personnel
from workflow.simulation.resources.equipment import Equipment

from workflow.simulation.Process_Library.PDS import *
from workflow.simulation.broker import Broker
from workflow.simulation.devices.quantum_devices import *
import pytest


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    lab_scientist = Personnel(
        title="Lab Scientist",
        labor_cost=150000,
        overhead_cost=0,
        skillset=["Materials Research"],
    )

    p800 = Equipment(
        name="P800", operational_cost=42, overhead_cost=10, capacity=1, serial_id=None
    )

    storage = Equipment(
        name="Storage",
        operational_cost=0,
        overhead_cost=100,
        capacity=100,
    )

    broker = Broker(
        classical_devices=[supercomputer],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
        personnel=[lab_scientist],
        equipment=[p800, storage],
    )

    return broker


def test_surface_prep_no_treatment():
    network = PDS_b32_surface_prep()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Fresh Material Sample"})]
        ],
        selected_nodes=[0],
    )

    assert len(network.selection_nodes[0]) == 4
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_NoTreatment":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) in [
                "PDS_PassivationTreatment",
                "PDS_AnodizationTreatment",
                "PDS_PlatingTreatment",
            ]
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ready For Testing"
    )


def test_surface_prep_passivation_treatment():
    network = PDS_b32_surface_prep()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Fresh Material Sample"})]
        ],
        selected_nodes=[1],
    )

    assert len(network.selection_nodes[0]) == 4
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_PassivationTreatment":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) in [
                "PDS_NoTreatment",
                "PDS_AnodizationTreatment",
                "PDS_PlatingTreatment",
            ]
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ready For Testing"
    )


def test_surface_prep_anodization_treatment():
    network = PDS_b32_surface_prep()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Fresh Material Sample"})]
        ],
        selected_nodes=[2],
    )

    assert len(network.selection_nodes[0]) == 4
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_AnodizationTreatment":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) in [
                "PDS_PassivationTreatment",
                "PDS_NoTreatment",
                "PDS_PlatingTreatment",
            ]
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ready For Testing"
    )


def test_surface_prep_plating_treatment():
    network = PDS_b32_surface_prep()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Fresh Material Sample"})]
        ],
        selected_nodes=[3],
    )

    assert len(network.selection_nodes[0]) == 4
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_PlatingTreatment":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) in [
                "PDS_PassivationTreatment",
                "PDS_AnodizationTreatment",
                "PDS_NoTreatment",
            ]
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ready For Testing"
    )


def test_prepare_electrochem_cell():
    network = PDS_b33_prepare_electrochemical_cell()

    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Ready For Testing"})]
        ],
    )

    for node in network.nodes:
        assert node.process.status == "COMPLETED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "In Faraday Cage"
    )


def test_use_commercial_electrolyte():
    network = PDS_b36_use_commercial_electrolyte()
    network.input_nodes[0].process.selected = True

    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Reference Electrode Checked"})]
        ],
    )

    for node in network.nodes:
        assert node.process.status == "COMPLETED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Quiescent Electrolyte"
    )


def test_prepare_inhouse_electrolyte():
    network = PDS_b36_prepare_inhouse_electrolyte()
    network.input_nodes[0].process.selected = True

    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Reference Electrode Checked"})]
        ],
    )

    for node in network.nodes:
        assert node.process.status == "COMPLETED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Quiescent Electrolyte"
    )


def test_electrolyte_preparation_commercial():
    network = PDS_b36_electrolyte_preparation()

    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[0]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Reference Electrode Checked"})]
        ],
        selected_nodes=[0],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_RetrieveElectrolyte":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_MixElectrolyte"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Quiescent Electrolyte"
    )


def test_electrolyte_preparation_inhouse():
    network = PDS_b36_electrolyte_preparation()

    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[1]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Reference Electrode Checked"})]
        ],
        selected_nodes=[1],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_MixElectrolyte":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_RetrieveElectrolyte"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[1].output_edges[0].data[0].properties["Usage"]
        == "Quiescent Electrolyte"
    )


def test_ocp_vs_time_less_noble():
    network = PDS_b37_ocp_vs_time()
    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[0]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Checked Electrolyte PH"})]
        ],
        selected_nodes=[0],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_LessNobleOCP":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_MoreNobleOCP"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Recorded OCP"
    )


def test_ocp_vs_time_more_noble():
    network = PDS_b37_ocp_vs_time()
    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[1]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Checked Electrolyte PH"})]
        ],
        selected_nodes=[1],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_MoreNobleOCP":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_LessNobleOCP"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[1].output_edges[0].data[0].properties["Usage"]
        == "Recorded OCP"
    )


def test_scan_polarization_curve():
    network = PDS_b37_scan_polarization_curve()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[[Data(data="Sample", properties={"Usage": "Recorded OCP"})]],
    )

    assert all(node.process.status == "COMPLETED" for node in network.nodes)
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Cathodic Polarization Curve"
    )


def test_record_material_data():
    network = PDS_b37_record_material_data()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Cathodic Polarization Curve"})]
        ],
    )

    assert all(node.process.status == "COMPLETED" for node in network.nodes)
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Recorded Surface Prep Method"
    )


def test_polarization_curve_data_acq_less_noble():
    network = PDS_b37_polarization_curve_data_acquisition()
    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[0]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Checked Electrolyte PH"})]
        ],
        selected_nodes=[0],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_LessNobleOCP":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_MoreNobleOCP"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Recorded Surface Prep Method"
    )


def test_polarization_curve_data_acq_more_noble():
    network = PDS_b37_polarization_curve_data_acquisition()
    network.broker = gen_broker()
    network.run(
        starting_nodes=[network.input_nodes[1]],
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Checked Electrolyte PH"})]
        ],
        selected_nodes=[1],
    )

    assert len(network.selection_nodes[0]) == 2
    for node in network.selection_nodes[0]:
        if str(node.process) == "PDS_MoreNobleOCP":
            assert node.process.status == "COMPLETED"
        else:
            assert str(node.process) == "PDS_LessNobleOCP"
            assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Recorded Surface Prep Method"
    )


def test_final_curve_gen():
    network = PDS_b37_final_curve_generation()
    network.broker = gen_broker()
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Recorded Surface Prep Method"})]
        ],
    )

    assert all(node.process.status == "COMPLETED" for node in network.nodes)
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Recorded Relative Humidity"
    )


@pytest.mark.parametrize(
    "b1, b2, b3", [(i, j, k) for i in range(4) for j in range(2) for k in range(2)]
)
def test_PDS_network(b1, b2, b3):
    network = generate_PDS(broker=gen_broker())

    branch_selection = [b1, b2, b3]
    network.run(
        starting_nodes=network.input_nodes,
        starting_inputs=[
            [Data(data="Sample", properties={"Usage": "Fresh Material Sample"})]
        ],
        selected_nodes=branch_selection,
    )

    assert len(network.selection_nodes) == 3
    assert [len(network.selection_nodes[idx]) for idx in range(3)] == [4, 2, 2]

    branch1 = [
        "PDS_NoTreatment",
        "PDS_PassivationTreatment",
        "PDS_AnodizationTreatment",
        "PDS_PlatingTreatment",
    ]
    branch2 = ["PDS_RetrieveElectrolyte", "PDS_MixElectrolyte"]
    branch3 = ["PDS_LessNobleOCP", "PDS_MoreNobleOCP"]

    for branch_idx in range(3):
        for node in network.selection_nodes[branch_idx]:
            if (
                str(node.process)
                == locals()[f"branch{branch_idx+1}"][branch_selection[branch_idx]]
            ):
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Polarization Curve"
    )
