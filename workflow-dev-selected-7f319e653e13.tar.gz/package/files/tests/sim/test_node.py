from workflow.core.data_types import *
from workflow.simulation.data import Data
from workflow.simulation.process import Process, InitError
from workflow.simulation.graph import Node, DirectedEdge
from workflow.simulation.resources.classical_device import (
    DeviceAllocation,
    ClassicalResource,
)

import pytest
import re

from workflow.simulation.Process_Library.matrix_ops import MatrixMult


def test_matmult_update():
    mat1 = Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"})
    mat2 = Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"})
    matmul = MatrixMult([mat1, mat2])
    matmul.update()
    assert matmul.result.cols == 5
    assert matmul.result.rows == 2


def test_empty_gen_expected_output_edges():
    empty_node = Node(id=None, process_model=None)
    with pytest.raises(
        AttributeError, match=f"object has no attribute 'expected_input_properties'"
    ):
        empty_node.expected_input_properties
    assert empty_node.output_edges == []


def test_init_expected_input_properties():
    node = Node(id=None, process_model=MatrixMult)
    assert (
        node.expected_input_properties
        == [{"Data Type": type(MatrixType()), "Usage": "Matrix"}] * 2
    )


def test_append_existing_edge():
    node = Node(id=None, process_model=MatrixMult)
    input_edge = DirectedEdge(data=None, source_node=None, dest_nodes=[node])
    node.input_edges = [input_edge]

    with pytest.raises(
        AssertionError,
        match=re.escape(f"Edge {input_edge} already exists as an input edge"),
    ):
        node.append_input_edge(input_edge)


def test_append_edge_invalid_dest_node():
    node = Node(id=None, process_model=MatrixMult)
    other_node = Node()
    input_edge = DirectedEdge(
        data=None,
        source_node=None,
        dest_nodes=[other_node],
    )

    with pytest.raises(
        AssertionError,
        match=re.escape(
            f"Cannot append Edge to Node {node} that is assigned to {input_edge.dest_nodes}"
        ),
    ):
        node.append_input_edge(input_edge)


def test_append_input_edge():
    node = Node(id=None, process_model=MatrixMult)
    input_edge = DirectedEdge(data=None, source_node=None, dest_nodes=[node])
    node.append_input_edge(input_edge)
    assert node.input_edges == [input_edge]


def test_insert_output_node_type_OUTPUT():
    node = Node(id=None, process_model=MatrixMult)
    output_node = Node(id=None, process_model=MatrixMult)
    node.insert_output_node(output_node)

    assert node.output_nodes == [output_node]


def test_insert_output_node_type_INPUT():
    node = Node(id=None, process_model=MatrixMult)
    output_node = Node(id=None, process_model=MatrixMult)
    node.insert_output_node(output_node)

    assert node.output_nodes == [output_node]


def test_insert_output_node_type_NETWORK():
    node = Node(id=None, process_model=MatrixMult)
    output_node = Node(id=None, process_model=MatrixMult)
    node.insert_output_node(output_node)

    assert node.output_nodes == [output_node]


def test_start_valid_data():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    assert node.input_edges == [input_edge1, input_edge2]

    node.initialize()
    assert node.process.inputs == [input_edge1.data[0], input_edge2.data[0]]

    node.process.update()
    result = node.process.generate_output()[0]
    assert result.data.rows == 2
    assert result.data.cols == 5


def test_process_update_valid_data():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    node.process.update()
    result = node.process.generate_output()[0]
    assert result.data.rows == 2
    assert result.data.cols == 5


def test_start_invalid_matrix_dimensions():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(5, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    assert node.input_edges == [input_edge1, input_edge2]

    with pytest.raises(
        AssertionError, match=f"Invalid input data for process {str(node.process)}"
    ):
        node.initialize()


def test_start_invalid_data_element_type():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=String(3)), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    assert node.input_edges == [input_edge1, input_edge2]

    with pytest.raises(AssertionError, match="Invalid input data for process"):
        node.initialize()


def test_start_invalid_input_properties():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(
            Data(MatrixType(2, 4, element_type=String(10)), {"Usage": "Invalid Usage"}),
        ),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Invalid Usage"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    assert node.input_edges == [input_edge1, input_edge2]

    with pytest.raises(
        InitError, match=re.escape(f"does not satisfy expected properties:")
    ):
        node.initialize()


def test_execution_exact_timestep():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    # Dummy allocation to satisfy allocation
    required_resource = ClassicalResource(memory=1000, num_cores=1)
    node.allocation = {
        required_resource: DeviceAllocation(name="name", cores=1, memory=10**9)
    }
    node.process.required_resources = required_resource
    node.process.status = Process.ACTIVE
    node.process.time_till_completion = 5
    node.execute_process(timestep=5)
    assert node.process.time_till_completion == 0
    assert node.process.status == Process.COMPLETED


def test_execution_smaller_timestep():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    # Dummy allocation to satisfy allocation
    required_resource = ClassicalResource(memory=1000, num_cores=1)
    node.allocation = {
        required_resource: DeviceAllocation(name="name", cores=1, memory=10**9)
    }
    node.process.required_resources = required_resource
    node.process.status = Process.ACTIVE
    node.process.time_till_completion = 5
    node.execute_process(timestep=4)
    assert node.process.time_till_completion == 1
    assert node.process.status == Process.ACTIVE


def test_execution_larger_timestep():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    # Dummy allocation to satisfy allocation
    required_resource = ClassicalResource(memory=1000, num_cores=1)
    node.allocation = {
        required_resource: DeviceAllocation(name="name", cores=1, memory=10**9)
    }
    node.process.required_resources = required_resource
    node.process.status = Process.ACTIVE
    node.process.time_till_completion = 5

    with pytest.raises(
        AssertionError,
        match=f"{node} has negative time till completion of process execution",
    ):
        node.execute_process(timestep=6)


def test_execution_invalid_allocation():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    # Dummy allocation to satisfy allocation
    required_resource = ClassicalResource(memory=1000, num_cores=2)
    node.allocation = {
        required_resource: DeviceAllocation(name="name", cores=1, memory=10**9)
    }
    node.process.required_resources = required_resource
    node.process.status = Process.ACTIVE
    node.process.time_till_completion = 5
    with pytest.raises(
        AssertionError,
        match=re.escape(
            f"Node {node.id} cannot execute it's process with given allocation {node.allocation}"
        ),
    ):
        node.verify_allocation()


def test_map_results_to_edge():
    node = Node(id=None, process_model=MatrixMult)
    input_edge1 = DirectedEdge(
        data=(Data(MatrixType(2, 4, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )
    input_edge2 = DirectedEdge(
        data=(Data(MatrixType(4, 5, element_type=float), {"Usage": "Matrix"}),),
        source_node=None,
        dest_nodes=[node],
    )

    node.append_input_edge(input_edge1)
    node.append_input_edge(input_edge2)
    node.initialize()

    # Dummy allocation to satisfy allocation
    required_resource = ClassicalResource(memory=1000, num_cores=1)
    node.allocation = {
        required_resource: DeviceAllocation(name="name", cores=1, memory=10**9)
    }
    node.process.required_resources = required_resource
    node.process.status = Process.ACTIVE
    node.process.time_till_completion = 5
    node.execute_process(timestep=5)

    # Dummy deallocation to satisfy deallocation
    node.allocation = None
    node.process.update()
    node.complete()
    assert isinstance(node.output_edges[0].data[0].data, MatrixType)
    assert node.output_edges[0].data[0].data.rows == 2
    assert node.output_edges[0].data[0].data.cols == 5
