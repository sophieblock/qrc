import networkx as nx

import pytest
import warnings

from workflow.simulation.resources.quantum_device import (
    QuantumDevice,
    QuantumResource,
)
from workflow.simulation.quantum import *
from workflow.simulation.quantum_gates import *
from workflow.simulation.devices.quantum_devices import IBM_Boston
from workflow.simulation.resources.q_interop.transpilers import QiskitCompiler
import itertools


# ----------------------------------------------------------------
# Test Qiskit Compiled swap (i.e. QiskitCompiler swap decomposition)
# ----------------------------------------------------------------
BASIS = ("ECR", "I", "RZ", "SX", "X")


@pytest.fixture
def compiler():
    return QiskitCompiler(basis_gates=BASIS)


@pytest.fixture
def two_qubit_device(compiler):
    """Toy connectivity 0—1"""
    g = nx.Graph()
    g.add_edge(0, 1)
    return QuantumDevice("toy-2q", connectivity=g, compiler=compiler)


def gate_names(qc):
    return {inst.gate.name for inst in qc.instructions}


def make_swap_circuit(a, b, n_qubits=None):
    if n_qubits is None:
        n_qubits = max(a, b) + 1
    qc = QuantumCircuit(qubit_count=n_qubits)
    qc.add_instruction(QuantumInstruction(SWAP(), (a, b)))
    return qc


def test_swap_removed(two_qubit_device):
    qc_native = two_qubit_device.compiler.transpile(
        make_swap_circuit(0, 1), two_qubit_device
    )
    assert all(instr.gate.name != "SWAP" for instr in qc_native.instructions)


def test_only_basis_gates(two_qubit_device):
    native = two_qubit_device.compiler.transpile(
        make_swap_circuit(0, 1), two_qubit_device
    )
    assert gate_names(native).issubset({g.upper() for g in BASIS})


def test_depth_matches_property(two_qubit_device):
    """
    test Depth equals compiler.swap_duration
    """
    native = two_qubit_device.compiler.transpile(
        make_swap_circuit(0, 1), two_qubit_device
    )
    assert native.depth() == two_qubit_device.compiler.swap_duration


def test_relabelled_swap(compiler):
    #  Decomposition remaps cleanly to arbitrary physical indices
    g = nx.path_graph(5)
    dev = QuantumDevice("toy-5q", connectivity=g, compiler=compiler)

    native = compiler.transpile(make_swap_circuit(3, 4, 5), dev)
    touched = {q for inst in native.instructions for q in inst.gate_indices}
    assert touched == {3, 4}, "should touch only the requested physical qubits"


# ----------------------------------------------------------------
# Test QuantumDevice allocation/deallocation, etc.
# ----------------------------------------------------------------
def generate_quantum_adder():
    circuit = QuantumCircuit(qubit_count=4)
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(1, 2)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=S(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))

    return circuit


def generate_qubit_connectivity():
    connectivity = nx.Graph()
    connectivity.add_edge(0, 1)
    connectivity.add_edge(0, 2)
    connectivity.add_edge(1, 2)
    connectivity.add_edge(2, 3)
    connectivity.add_edge(2, 4)
    connectivity.add_edge(3, 4)

    return connectivity


def generate_quantum_device():
    device = QuantumDevice(
        device_name="test",
        connectivity=generate_qubit_connectivity(),
        # gate_set=(X, H, S, T, Tdg, CX),
        gate_set=("X", "H", "S", "T", "Tdg", "CX"),
    )

    return device


def test_add_instruction():
    circuit = generate_quantum_adder()
    assert len(circuit.instructions) == 23


def test_add_instruction_out_of_range():
    qc = QuantumCircuit(qubit_count=2)
    with pytest.raises(AssertionError):
        qc.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(3,)))


# ---------------------------------------------------------------------------
# transistion based = False tests (normal)
# ---------------------------------------------------------------------------


@pytest.mark.slow
@pytest.mark.xfail(
    reason="Ancilla-free hard-island mapping still under investigation. This will pass on occasion (i.e., device.max_available_connections is in (0,1) will always pass after allocation)",
    strict=False,
)
def test_allocate_normal():
    device = generate_quantum_device()
    circuit = generate_quantum_adder()
    quantum_resource = QuantumResource(
        quantum_circuit=circuit,
    )
    available_qubits = device.available_qubits

    assert device.max_available_connections == 5
    allocation = device.allocate(quantum_resource)
    allocated_qubit_idxs = allocation.allocated_qubit_idxs
    assert device.max_available_connections == 1
    assert sorted(list(device.available_qubits) + list(allocated_qubit_idxs)) == sorted(
        list(available_qubits)
    )
    assert all(qubit_idx in available_qubits for qubit_idx in allocated_qubit_idxs)


@pytest.mark.slow
@pytest.mark.xfail(
    reason="Ancilla-free hard-island mapping via CouplingMap not enforced yet",
    strict=False,
)
def test_deallocate_normal():
    device = generate_quantum_device()
    circuit = generate_quantum_adder()
    quantum_resource = QuantumResource(
        quantum_circuit=circuit,
    )
    available_qubits = device.available_qubits

    assert device.max_available_connections == 5
    allocation = device.allocate(quantum_resource)
    assert device.max_available_connections == 1
    device.deallocate(allocation)
    assert device.max_available_connections == 5
    assert sorted(device.available_qubits) == sorted(available_qubits)


def tail4_dev(connectivity, gate_set=("X", "H", "S", "T", "Tdg", "CX")):

    return QuantumDevice("tail4", connectivity=connectivity, gate_set=gate_set)


def touched_qubits(meta):
    return {q for instr in meta["compiled"].instructions for q in instr.gate_indices}


def test_allocate_transition_based():
    device = generate_quantum_device()
    circuit = generate_quantum_adder()
    quantum_resource = QuantumResource(quantum_circuit=circuit)
    available_qubits = device.available_qubits

    assert device.max_available_connections == 5
    allocation = device.allocate(quantum_resource)
    allocated_qubit_idxs = allocation.allocated_qubit_idxs
    assert device.max_available_connections == 1
    assert sorted(device.available_qubits + list(allocated_qubit_idxs)) == sorted(
        available_qubits
    )
    assert all(qubit_idx in available_qubits for qubit_idx in allocated_qubit_idxs)


def test_deallocate_transition_based():
    device = generate_quantum_device()
    circuit = generate_quantum_adder()
    quantum_resource = QuantumResource(quantum_circuit=circuit)
    available_qubits = device.available_qubits

    assert device.max_available_connections == 5
    allocation = device.allocate(quantum_resource)
    assert device.max_available_connections == 1
    device.deallocate(allocation)
    assert device.max_available_connections == 5
    assert sorted(device.available_qubits) == sorted(available_qubits)


def test_allocate_covers_transpiled_circuit_boston():
    """
    Every physical qubit that the *compiled* circuit touches must appear in
    QDeviceAllocation.allocated_qubit_idxs.  Today that list only contains the
    initial mapping, so qubits brought in by SWAPs (e.g. 14 on IBM Boston) are
    missing and the test rightly fails.
    """
    from workflow.simulation.resources.q_interop.qiskit_interop import (
        qiskit_to_quantum_circuit,
    )

    device = IBM_Boston()
    circuit = generate_quantum_adder()
    q_resource = QuantumResource(quantum_circuit=circuit, T_gates=None)
    allocation = device.allocate(q_resource)

    uncovered = set()
    transpiled_circuit = qiskit_to_quantum_circuit(allocation.transpiled_circuit)
    for instr in transpiled_circuit.instructions:
        for q in instr.gate_indices:
            if q not in allocation.allocated_qubit_idxs:
                uncovered.add(q)

    assert not uncovered, (
        "Transpiled circuit uses physical qubits "
        f"{sorted(uncovered)} that are *not* recorded in "
        f"allocation {allocation.allocated_qubit_idxs}"
    )


def test_allocate_T_gates():
    """
    Every physical qubit that the *compiled* circuit touches must appear in
    QDeviceAllocation.allocated_qubit_idxs.  Today that list only contains the
    initial mapping, so qubits brought in by SWAPs (e.g. 14 on IBM Boston) are
    missing and the test rightly fails.
    """
    device = IBM_Boston()
    q_resource = QuantumResource(quantum_circuit=None, T_gates=20, required_qubits=10)
    allocation = device.allocate(q_resource)

    assert device.max_available_connections == 146
    assert allocation.T_count == 20
    assert device.T_transpiled_counts[1] == 22
    assert device.T_transpiled_counts[2] == 5


def test_deallocate_T_gates():
    """
    Every physical qubit that the *compiled* circuit touches must appear in
    QDeviceAllocation.allocated_qubit_idxs.  Today that list only contains the
    initial mapping, so qubits brought in by SWAPs (e.g. 14 on IBM Boston) are
    missing and the test rightly fails.
    """

    q_resource = QuantumResource(quantum_circuit=None, T_gates=20, required_qubits=10)

    device = IBM_Boston()
    assert device.max_available_connections == 156
    allocation = device.allocate(q_resource)
    assert device.max_available_connections == 146
    device.deallocate(allocation)
    assert device.max_available_connections == 156
