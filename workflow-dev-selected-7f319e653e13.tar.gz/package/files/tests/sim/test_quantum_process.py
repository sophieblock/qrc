from workflow.simulation.data import Data
from workflow.simulation.graph import Node, Network

from workflow.simulation.broker import Broker
from workflow.simulation.resources.quantum_device import QuantumResource
from workflow.simulation.quantum import QuantumCircuit, QuantumInstruction

import qiskit as qsk
from workflow.simulation.devices.quantum_devices import *
from workflow.simulation.process import QuantumProcess
from workflow.simulation.quantum_gates import *

from typing import List


def test_device():
    device = IBM_Fez()

    qc = qsk.QuantumCircuit(3)
    qc.ccx(0, 1, 2)

    gate_set = [gate.lower() for gate in device.gate_set if gate != "I"]
    expected_gate_set = ["cz", "rx", "rz", "rzz", "sx", "x"]
    assert all(gate in expected_gate_set for gate in gate_set)
    assert len(gate_set) == len(expected_gate_set)
    transpiled_qc = qsk.transpile(qc, basis_gates=gate_set)

    single = 2
    double = 3
    single_fid = 0.99
    double_fid = 0.98
    gate_times = {idx: 0.0 for idx in range(3)}

    fidelity = 1.0
    for gate in transpiled_qc.data:
        num_qubits = gate.operation.num_qubits
        gate_idxs = [q._index for q in gate.qubits]

        if num_qubits == 1:
            gate_times[gate_idxs[0]] += single
            fidelity = fidelity * single_fid
        else:
            gate_times[gate_idxs[0]] += double
            gate_times[gate_idxs[1]] += double

            fidelity = fidelity * double_fid

    gate_time = max(list(gate_times.values()))
    assert np.allclose(fidelity, 0.724, 1e-3)
    assert gate_time == 30.0


def generate_quantum_adder():
    circuit = QuantumCircuit(qubit_count=4)
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(1, 2)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=S(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))

    return circuit


class QuantumAdder(QuantumProcess):
    def __init__(
        self,
        inputs=None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        shots=1,
    ):
        super().__init__(
            inputs=inputs,
            expected_input_properties=expected_input_properties,
            required_resources=required_resources,
            output_properties=output_properties,
            shots=shots,
        )

    def compute_circuit(self) -> QuantumCircuit:
        return generate_quantum_adder()

    def set_required_resources(self):
        """Sets the appropriate resources required to run the process. This method should update
        self.required_resources to be a list of Resources required for the Process to successfully run.
        Will be unique for each process.
        """

        self.required_resources = QuantumResource(
            quantum_circuit=self.compute_circuit(),
        )

    def set_expected_input_properties(self):
        """Sets the expected input properties of the Process to execute/update successfully.
        This method should update self.expected_input_properties to be a list of dictionaries, with each
        dictionary specifying the expected properties of an input Data instance. A Process that requires
        N inputs will require N such dictionaries specifying its properties. Will be unique to each Process.
        """

        self.expected_input_properties = [{"Data Type": int, "Usage": "Num Qubits"}]

    def set_output_properties(self):
        """Sets the expected properties of the generated outputs of the Process.
        This method should update self.output_properties to be a list of dictionaries,
        with each dictionary specifying the expected properties of each output Data
        """

        return None

    def validate_data(self) -> bool:
        """Process specific verification that ensures input data has
        correct specifications. Will be unique to each process
        """

        return True

    def update(self):
        self.fidelity = self.compute_fidelity()

    def compute_fidelity(self):
        return 1.0

    def generate_output(self) -> List[Data]:
        """After completing updates, the process will wrap its results
        and return a (unordered) set of Data states to be processed by Node.
        The expected output will be unique to the process.
        """

        return [Data(data=self.fidelity, properties={"Usage": "Fidelity"})]


def generate_quantum_broker():
    broker = Broker(
        quantum_devices=[
            IBM_Boston(),
        ]
    )
    return broker


def test_run_quantum_network_Boston():
    broker = Broker(quantum_devices=[IBM_Boston()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    results = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )

    assert results.raw.loc[0]["Circuit Depth"] == 29
    assert results.raw.loc[0]["Device Name"] == broker.quantum_devices[0].name
    assert np.allclose(results.raw.loc[0]["End Time [s]"], 1.252e-6)


def test_run_quantum_network_Boston_multishot():
    shots = np.random.randint(100, 1000)
    broker = Broker(quantum_devices=[IBM_Boston()])
    node = Node(process_model=QuantumAdder, shots=shots)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    results = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )

    assert results.raw.loc[0]["Circuit Depth"] == 29
    assert results.raw.loc[0]["Device Name"] == broker.quantum_devices[0].name
    assert np.allclose(results.raw.loc[0]["End Time [s]"], 1.252e-6 * shots)
