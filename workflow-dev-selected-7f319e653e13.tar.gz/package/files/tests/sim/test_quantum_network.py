import networkx as nx
from workflow.simulation.graph import Network, Node
from workflow.simulation.process import QuantumProcess
from workflow.simulation.quantum import QuantumCircuit
from workflow.simulation.broker import Broker
from workflow.simulation.resources.quantum_device import QuantumResource
from workflow.simulation.data import Data
from workflow.simulation.devices.quantum_devices import *
from workflow.simulation.quantum import *
from workflow.simulation.quantum_gates import *
from typing import List
import pytest


def tiny_swap_resource():

    qc = QuantumCircuit(qubit_count=2)
    qc.add_instruction(QuantumInstruction(X(), (0,)))
    qc.add_instruction(QuantumInstruction(CX(), (0, 1)))
    return QuantumResource(quantum_circuit=qc)


def singleton_Qdevice():

    g = nx.Graph([(0, 1)])
    dev = QuantumDevice("toy-2q-singleton", g, gate_set=("X", "CX"))
    dev._is_singleton = True  # triggers deepcopy inside Broker
    return dev


def test_broker_makes_fresh_copy_and_resets():

    device_singleton = singleton_Qdevice()
    resource = tiny_swap_resource()

    broker1 = Broker(quantum_devices=[device_singleton])
    alloc1 = broker1.request_allocation(resource)

    assert broker1.quantum_devices[0].available_qubits == []

    assert device_singleton.available_qubits == [0, 1]

    broker2 = Broker(quantum_devices=[device_singleton])

    # starts from a clean slate
    assert broker2.quantum_devices[0].available_qubits == [0, 1]

    alloc2 = broker2.request_allocation(resource)

    # again, broker2’s private copy is now depleted
    assert broker2.quantum_devices[0].available_qubits == []

    # original singleton still untouched
    assert device_singleton.available_qubits == [0, 1]


def test_broker_reset_even_without_singleton_flag():
    """
    If the device is not marked as a singleton (no deepcopy), the Broker
    still calls .reset() so every run starts from a clean state
    """
    g = nx.Graph([(0, 1)])
    dev = QuantumDevice("toy-2q", g, gate_set=("X", "CX"))
    res = tiny_swap_resource()

    broker1 = Broker(quantum_devices=[dev])
    broker1.request_allocation(res)
    assert broker1.quantum_devices[0].available_qubits == []

    broker2 = Broker(quantum_devices=[dev])
    assert broker2.quantum_devices[0].available_qubits == [0, 1]


def generate_quantum_adder():
    circuit = QuantumCircuit(qubit_count=4)
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=X(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(1, 2)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(0,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(1,)))
    circuit.add_instruction(QuantumInstruction(gate=Tdg(), qubit_indices=(2,)))
    circuit.add_instruction(QuantumInstruction(gate=T(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(0, 1)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(2, 3)))
    circuit.add_instruction(QuantumInstruction(gate=S(), qubit_indices=(3,)))
    circuit.add_instruction(QuantumInstruction(gate=CX(), qubit_indices=(3, 0)))
    circuit.add_instruction(QuantumInstruction(gate=H(), qubit_indices=(3,)))

    return circuit


class QuantumAdder(QuantumProcess):
    def __init__(
        self,
        inputs=None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        super().__init__(
            inputs=inputs,
            expected_input_properties=expected_input_properties,
            required_resources=required_resources,
            output_properties=output_properties,
        )

    def compute_circuit(self) -> QuantumCircuit:
        return generate_quantum_adder()

    def set_required_resources(self):
        """Sets the appropriate resources required to run the process. This method should update
        self.required_resources to be a list of Resources required for the Process to successfully run.
        Will be unique for each process.
        """

        self.required_resources = QuantumResource(
            quantum_circuit=self.compute_circuit(),
        )

    def set_expected_input_properties(self):
        """Sets the expected input properties of the Process to execute/update successfully.
        This method should update self.expected_input_properties to be a list of dictionaries, with each
        dictionary specifying the expected properties of an input Data instance. A Process that requires
        N inputs will require N such dictionaries specifying its properties. Will be unique to each Process.
        """

        self.expected_input_properties = [{"Data Type": int, "Usage": "Num Qubits"}]

    def set_output_properties(self):
        """Sets the expected properties of the generated outputs of the Process.
        This method should update self.output_properties to be a list of dictionaries,
        with each dictionary specifying the expected properties of each output Data
        """

        return None

    def validate_data(self) -> bool:
        """Process specific verification that ensures input data has
        correct specifications. Will be unique to each process
        """

        return True

    def update(self):
        self.fidelity = self.compute_fidelity()

    def compute_fidelity(self):
        return 1.0

    def generate_output(self) -> List[Data]:
        """After completing updates, the process will wrap its results
        and return a (unordered) set of Data states to be processed by Node.
        The expected output will be unique to the process.
        """

        return [Data(data=self.fidelity, properties={"Usage": "Fidelity"})]


def generate_quantum_broker():
    broker = Broker(
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ]
    )
    return broker


def test_run_quantum_network_Boston():
    broker = Broker(quantum_devices=[IBM_Boston()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )


def test_run_quantum_network_Miami():
    broker = Broker(quantum_devices=[IBM_Miami()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )


def test_run_quantum_network_Fez():
    broker = Broker(quantum_devices=[IBM_Fez()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )


def test_run_quantum_network_Kingston():
    broker = Broker(quantum_devices=[IBM_Kingston()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )


def test_run_quantum_network_Pittsburgh():
    broker = Broker(quantum_devices=[IBM_Pittsburgh()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )


def test_run_quantum_network_Marrakesh():
    broker = Broker(quantum_devices=[IBM_Marrakesh()])

    node = Node(process_model=QuantumAdder)
    network = Network(
        name="Quantum Adder",
        nodes=[node],
        input_nodes=[node],
        output_nodes=[],
        broker=broker,
    )
    df = network.run(
        network.input_nodes,
        starting_inputs=[(Data(data=5, properties={"Usage": "Num Qubits"}),)],
    )
