import scipy.integrate
import scipy.sparse

from workflow.simulation.data import Data
from workflow.simulation.graph import Node, Network
from workflow.simulation.resources.classical_device import ClassicalDevice

from workflow.simulation.Process_Library.LMI import *
from workflow.simulation.broker import Broker

import pytest
import scipy

nm = 1e-7
ns = 1e-9
nb0 = 1 / 4
lambda00 = 585 * nm
sigma00 = 1 * ns
N_sigma00 = 4

c00 = 299792458e2
k00 = 2 * np.pi / lambda00
omega00 = c00 * k00

NF = 5


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    broker = Broker(
        classical_devices=[supercomputer],
    )
    return broker


def test_init_pulse():
    starting_inputs = [
        Data(data=nb0, properties={"Usage": "Number of Photons"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=sigma00, properties={"Usage": "Pulse Width"}),
        Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
        Data(data=1, properties={"Usage": "Pulse Cross Section"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
    ]

    init_pulse = LMI_InitPulse(inputs=starting_inputs)

    init_pulse.update()

    output_data = init_pulse.generate_output()
    usage_properties = [data.properties["Usage"] for data in output_data]
    expected_properties = [
        "Mode Detunings",
        "Interaction Strengths",
        "Average Photons Per Mode",
        "Number of Partitions",
        "Scale",
    ]

    assert len(usage_properties) == len(expected_properties)
    assert all(property in expected_properties for property in usage_properties)


def test_init_pulse_network():
    starting_inputs = [
        Data(data=nb0, properties={"Usage": "Number of Photons"}),
        Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
        Data(data=sigma00, properties={"Usage": "Pulse Width"}),
        Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
        Data(data=1, properties={"Usage": "Pulse Cross Section"}),
        Data(data=NF, properties={"Usage": "Number of Partitions"}),
    ]

    init_pulse = Node(process_model=LMI_InitPulse)

    network = Network(
        nodes=[init_pulse],
        input_nodes=[init_pulse],
        output_nodes=[init_pulse],
        broker=gen_broker(),
    )

    network.run([init_pulse], starting_inputs=[starting_inputs])

    output_edges = network.output_nodes[0].output_edges

    properties_dict = {}
    for edge in output_edges:
        properties_dict[edge.data[0].properties["Usage"]] = edge.data[0].properties[
            "Data Type"
        ]

    expected_properties_dict = {
        "Mode Detunings": list,
        "Interaction Strengths": float,
        "Average Photons Per Mode": list,
        "Number of Partitions": int,
    }

    for prop, dtype in expected_properties_dict.items():
        assert properties_dict[prop] == dtype


def test_gen_hamiltonian_network():
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 5], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=5, properties={"Usage": "Total Photon Cutoff"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Interaction")

    init_pulse.insert_output_node(ham)

    network = Network(
        nodes=[init_pulse, ham],
        input_nodes=[init_pulse, ham],
        output_nodes=[ham],
        broker=gen_broker(),
    )

    network.run([init_pulse, ham], starting_inputs=starting_inputs)

    output_edges = network.output_nodes[0].output_edges

    assert output_edges[0].data[0].properties["Usage"] == "Sparse Hamiltonian"
    assert (
        output_edges[0].data[0].properties["Data Type"] == scipy.sparse._csr.csr_matrix
    )
    assert output_edges[0].data[0].properties["Framework"] == "Interaction"

    hamiltonian = output_edges[0].data[0].data

    assert hamiltonian.nnz == 1764
    assert hamiltonian.shape == (2 * 6**5, 2 * 6**5)


@pytest.fixture
def hamiltonian():
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 5], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=5, properties={"Usage": "Total Photon Cutoff"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Interaction")

    init_pulse.insert_output_node(ham)

    network = Network(
        nodes=[init_pulse, ham],
        input_nodes=[init_pulse, ham],
        output_nodes=[ham],
        broker=gen_broker(),
    )

    network.run([init_pulse, ham], starting_inputs=starting_inputs)
    output_edges = network.output_nodes[0].output_edges

    return output_edges[0].data[0].data


def test_solve_ODE(hamiltonian):
    left_proj_idxs = [
        ((0, 0, 0, 0, 1), 0),
        ((0, 0, 0, 1, 0), 0),
        ((0, 0, 1, 0, 0), 0),
        ((0, 1, 0, 0, 0), 0),
        ((1, 0, 0, 0, 0), 0),
        ((0, 0, 0, 0, 0), 1),
    ]
    solve_ode = LMI_SolveODE(
        inputs=[
            Data(data=left_proj_idxs, properties={"Usage": "Left Projection Idxs"}),
            Data(
                data=((0, 0, 0, 0, 1), 0),
                properties={"Usage": "Right Projection Idx", "Index": 0},
            ),
            Data(data=np.pi, properties={"Usage": "Scale"}),
            Data(data=5, properties={"Usage": "Mode Photon Limit"}),
            Data(data=5, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=5, properties={"Usage": "Number of Partitions"}),
            Data(
                data=hamiltonian,
                properties={"Usage": "Sparse Hamiltonian", "Framework": "Interaction"},
            ),
        ],
        index=0,
        quanta=1,
    )

    solve_ode.update()
    output_data = solve_ode.generate_output()
    ode_sols_dict = output_data[0].data

    for key, val in ode_sols_dict.items():
        assert key[0] == left_proj_idxs[val[1]]
        assert key[1] == ((0, 0, 0, 0, 1), 0)
        assert isinstance(val[0], scipy.integrate.OdeSolution)

    assert output_data[0].properties["Usage"] == "ODE Solutions Dict"
    assert output_data[0].properties["Quanta"] == 1
    assert output_data[0].properties["Index"] == 0


def test_init_ode_quanta_1(hamiltonian):
    proj_idxs = list(gen_valid_index_combins(5, 5, 5))
    starting_inputs = [
        Data(data=proj_idxs, properties={"Usage": "Photon Projection Idxs"}),
        Data(data=np.pi, properties={"Usage": "Scale"}),
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=5, properties={"Usage": "Total Photon Cutoff"}),
        Data(data=2, properties={"Usage": "Number of Energy Levels"}),
        Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
        Data(data=5, properties={"Usage": "Number of Partitions"}),
        Data(
            data=hamiltonian,
            properties={"Usage": "Sparse Hamiltonian", "Framework": "Interaction"},
        ),
    ]

    init_ode_1 = LMI_InitODEQuanta(inputs=starting_inputs, quanta=1)

    init_ode_1.update()
    outputs = init_ode_1.generate_output()

    expected_properties_dict = {
        "Left Projection Idxs": list,
        "Scale": float,
        "Mode Photon Limit": int,
        "Total Photon Cutoff": int,
        "Number of Energy Levels": int,
        "Normalized Time Limit": float,
        "Number of Partitions": int,
        "Sparse Hamiltonian": scipy.sparse._csr.csr_matrix,
    }

    idxs = list(range(6))
    for output in outputs:
        if output.properties["Usage"] == "Right Projection Idx":
            assert output.properties["Data Type"] == tuple
            assert output.properties["Index"] in idxs
            idxs.remove(output.properties["Index"])
        else:
            assert (
                expected_properties_dict[output.properties["Usage"]]
                == output.properties["Data Type"]
            )


def test_init_ode_quanta_1_network(hamiltonian):
    proj_idxs = list(gen_valid_index_combins(5, 5, 5))
    starting_inputs = [
        Data(data=proj_idxs, properties={"Usage": "Photon Projection Idxs"}),
        Data(data=np.pi, properties={"Usage": "Scale"}),
        Data(data=5, properties={"Usage": "Mode Photon Limit"}),
        Data(data=5, properties={"Usage": "Total Photon Cutoff"}),
        Data(data=2, properties={"Usage": "Number of Energy Levels"}),
        Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
        Data(data=5, properties={"Usage": "Number of Partitions"}),
        Data(
            data=hamiltonian,
            properties={"Usage": "Sparse Hamiltonian", "Framework": "Interaction"},
        ),
    ]

    init_ode_1 = Node(process_model=LMI_InitODEQuanta, quanta=1)

    network = Network(
        nodes=[init_ode_1],
        input_nodes=[init_ode_1],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run([init_ode_1], starting_inputs=[starting_inputs])

    for idx in range(6):
        for edge in network.output_nodes[idx].output_edges:
            assert edge.data[0].properties["Usage"] == "ODE Solutions Dict"
            assert edge.data[0].properties["Index"] == idx
            assert edge.data[0].properties["Quanta"] == 1


@pytest.mark.slow
def test_compute_unitary_trnsf():
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=3, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 3], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Interaction")

    init_pulse.insert_output_node(ham)

    network = Network(
        nodes=[init_pulse, ham],
        input_nodes=[init_pulse, ham],
        output_nodes=[ham],
        broker=gen_broker(),
    )

    network.run([init_pulse, ham], starting_inputs=starting_inputs)
    output_edges = network.output_nodes[0].output_edges

    hamiltonian = output_edges[0].data[0].data
    timesteps = 10
    starting_inputs = [
        Data(data=np.pi, properties={"Usage": "Scale"}),
        Data(data=3, properties={"Usage": "Mode Photon Limit"}),
        Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
        Data(data=2, properties={"Usage": "Number of Energy Levels"}),
        Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
        Data(data=3, properties={"Usage": "Number of Partitions"}),
        Data(
            data=hamiltonian,
            properties={"Usage": "Sparse Hamiltonian", "Framework": "Interaction"},
        ),
        Data(
            data=list(np.linspace(0, 1, timesteps)),
            properties={"Usage": "Evolution Times"},
        ),
    ]

    compute_uni_trns = Node(process_model=LMI_ComputeUnitaryTrnsfrm)

    network = Network(
        nodes=[compute_uni_trns],
        input_nodes=[compute_uni_trns],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run([compute_uni_trns], starting_inputs=[starting_inputs], simulate=False)

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Unitary Transformations"
            assert len(edge.data[0].data) == timesteps
            assert all(
                isinstance(uni_trnsfm, scipy.sparse.csr_matrix)
                for uni_trnsfm in edge.data[0].data
            )
            assert all(uni_trnsfm.nnz == 454 for uni_trnsfm in edge.data[0].data)


@pytest.mark.slow
def test_compute_unitary_trnsf_full_network():
    timesteps = 10
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=3, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 3], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
        ],
        [
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(
                data=list(np.linspace(0, 1, timesteps)),
                properties={"Usage": "Evolution Times"},
            ),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Interaction")
    compute_uni_trns = Node(process_model=LMI_ComputeUnitaryTrnsfrm)

    init_pulse.insert_output_node(ham)
    init_pulse.insert_output_node(compute_uni_trns)
    ham.insert_output_node(compute_uni_trns)

    network = Network(
        nodes=[init_pulse, ham, compute_uni_trns],
        input_nodes=[init_pulse, ham, compute_uni_trns],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, ham, compute_uni_trns],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Unitary Transformations"
            assert len(edge.data[0].data) == timesteps
            assert all(
                isinstance(uni_trnsfm, scipy.sparse.csr_matrix)
                for uni_trnsfm in edge.data[0].data
            )
            assert all(uni_trnsfm.nnz == 454 for uni_trnsfm in edge.data[0].data)


def test_init_state():
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=3, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    init_state = Node(process_model=LMI_InitState)

    init_pulse.insert_output_node(init_state)

    network = Network(
        nodes=[init_pulse, init_state],
        input_nodes=[init_pulse, init_state],
        output_nodes=[init_state],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, init_state],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes[0].output_edges) == 1
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Initial State"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, scipy.sparse.csr_matrix
    )
    assert network.output_nodes[0].output_edges[0].data[0].data.shape == (2 * 4**3, 1)


def test_krylov_arnoldi():
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=3, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 3], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    init_state = Node(process_model=LMI_InitState)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Schrodinger")
    krylov_arnoldi = Node(
        process_model=LMI_KrylovArnoldi,
        evolution_time=100,
        krylov_dims=10,
    )

    init_pulse.insert_output_node(init_state)
    init_pulse.insert_output_node(ham)
    init_state.insert_output_node(krylov_arnoldi)
    ham.insert_output_node(krylov_arnoldi)

    network = Network(
        nodes=[init_pulse, init_state, ham, krylov_arnoldi],
        input_nodes=[init_pulse, init_state, ham],
        output_nodes=[krylov_arnoldi],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, init_state, ham],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes[0].output_edges) == 1
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Evolved State"
    )
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Evolution Time"]
        == 100
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, scipy.sparse.csc_matrix
    )
    assert network.output_nodes[0].output_edges[0].data[0].data.shape == (2 * 4**3, 1)


def test_get_expectation_vals():
    NF = 5
    NT = 5
    NTM = 5
    timesteps = 4
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * NF], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
        ],
        [
            Data(
                data=list(np.linspace(0, 100, timesteps)),
                properties={"Usage": "Evolution Times"},
            ),
            Data(data=10, properties={"Usage": "Krylov Dimensions"}),
            Data(
                data=np.diag(list(range(NT + 1))),
                properties={"Usage": "Photon Observable"},
            ),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    init_state = Node(process_model=LMI_InitState)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Schrodinger")
    get_exp_vals = Node(process_model=LMI_GetExpectationVals)

    init_pulse.insert_output_node(init_state)
    init_pulse.insert_output_node(ham)
    init_state.insert_output_node(get_exp_vals)
    ham.insert_output_node(get_exp_vals)

    network = Network(
        nodes=[init_pulse, init_state, ham, get_exp_vals],
        input_nodes=[init_pulse, init_state, ham, get_exp_vals],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, init_state, ham, get_exp_vals],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes) == 20
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) == 1
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0, 100, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))


def test_get_expectation_vals_ODE():
    NF = 3
    NT = 3
    NTM = 3
    timesteps = 4
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=3, properties={"Usage": "Mode Photon Limit"}),
            Data(data=3, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
        ],
        [
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * 3], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
        ],
        [
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=1.0, properties={"Usage": "Normalized Time Limit"}),
            Data(
                data=list(np.linspace(0, 100, timesteps)),
                properties={"Usage": "Evolution Times"},
            ),
        ],
        [
            Data(
                data=list(np.linspace(0, 100, timesteps)),
                properties={"Usage": "Evolution Times"},
            ),
            Data(
                data=np.diag(list(range(NT + 1))),
                properties={"Usage": "Photon Observable"},
            ),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    init_state = Node(process_model=LMI_InitState)
    ham = Node(process_model=LMI_GenHamiltonian, framework="Interaction")
    compute_uni_trns = Node(process_model=LMI_ComputeUnitaryTrnsfrm)
    get_exp_vals = Node(process_model=LMI_GetExpectationVals, extend_dynamic=True)

    init_pulse.insert_output_node(init_state)
    init_pulse.insert_output_node(ham)
    init_pulse.insert_output_node(compute_uni_trns)
    ham.insert_output_node(compute_uni_trns)
    init_state.insert_output_node(get_exp_vals)
    compute_uni_trns.insert_output_node(get_exp_vals)

    network = Network(
        nodes=[init_pulse, init_state, ham, compute_uni_trns, get_exp_vals],
        input_nodes=[init_pulse, init_state, ham, compute_uni_trns, get_exp_vals],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, init_state, ham, compute_uni_trns, get_exp_vals],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) > 0
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0, 100, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))

    assert (
        sum(len(output_node.output_edges) for output_node in network.output_nodes)
        == timesteps * NF
    )


def test_full_network_sp():
    NF = 5
    NT = 5
    NTM = 5
    timesteps = 4
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data="Schrodinger", properties={"Usage": "Framework"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * NF], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Rabi Cycles"}),
            Data(data=timesteps, properties={"Usage": "Timesteps"}),
            Data(data=10, properties={"Usage": "Krylov Dimensions"}),
            Data(
                data=np.diag(list(range(NT + 1))),
                properties={"Usage": "Photon Observable"},
            ),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    sim_classical = Node(process_model=LMI_SimulateClassical)

    init_pulse.insert_output_node(sim_classical)

    network = Network(
        nodes=[init_pulse, sim_classical],
        input_nodes=[init_pulse, sim_classical],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, sim_classical],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(init_pulse.output_edges) > 0
    for output_edge in init_pulse.output_edges:
        if output_edge.data[0].properties["Usage"] == "Interaction Strengths":
            gamma = output_edge.data[0].data
            break

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) > 0
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0.0, 2 * np.pi / gamma, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))


def test_full_network_ip():
    NF = 3
    NT = 3
    NTM = 3
    timesteps = 4
    starting_inputs = [
        [
            Data(data=nb0, properties={"Usage": "Number of Photons"}),
            Data(data=omega00, properties={"Usage": "Central Angular Frequency"}),
            Data(data=sigma00, properties={"Usage": "Pulse Width"}),
            Data(data=N_sigma00, properties={"Usage": "Pulse Half Length"}),
            Data(data=1, properties={"Usage": "Pulse Cross Section"}),
            Data(data=NF, properties={"Usage": "Number of Partitions"}),
        ],
        [
            Data(data="Interaction", properties={"Usage": "Framework"}),
            Data(data=2, properties={"Usage": "Number of Energy Levels"}),
            Data(data=0.0, properties={"Usage": "Coherent Pulse Phase"}),
            Data(data=NT, properties={"Usage": "Mode Photon Limit"}),
            Data(data=NTM, properties={"Usage": "Total Photon Cutoff"}),
            Data(data=np.array([[0.0], [1.0]]), properties={"Usage": "Emitter State"}),
            Data(
                data=[-1 / 2, 1 / 2],
                properties={"Usage": "Normalized Emitter Energies"},
            ),
            Data(data=[[0.0] * NF], properties={"Usage": "Hamiltonian Phase"}),
            Data(data=1.0, properties={"Usage": "Rabi Cycles"}),
            Data(data=timesteps, properties={"Usage": "Timesteps"}),
            Data(
                data=np.diag(list(range(NT + 1))),
                properties={"Usage": "Photon Observable"},
            ),
        ],
    ]

    init_pulse = Node(process_model=LMI_InitPulse)
    sim_classical = Node(process_model=LMI_SimulateClassical)

    init_pulse.insert_output_node(sim_classical)

    network = Network(
        nodes=[init_pulse, sim_classical],
        input_nodes=[init_pulse, sim_classical],
        output_nodes=[],
        broker=gen_broker(),
    )

    network.run(
        [init_pulse, sim_classical],
        starting_inputs=starting_inputs,
        simulate=False,
    )

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) > 0
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0.0, 1.0, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))


def test_run_LMI_network_classical_sp():
    timesteps = 5
    framework = "Schrodinger"
    mode = "Classical"
    df, network = run_LMI_network(
        picture=framework, mode=mode, timesteps=timesteps, broker=gen_broker()
    )

    for node in network.nodes:
        if isinstance(node.process, LMI_InitPulse):
            for edge in node.output_edges:
                if edge.data[0].properties["Usage"] == "Interaction Strengths":
                    gamma = edge.data[0].data

    num_photon_modes = 3
    assert len(network.output_nodes) == timesteps * num_photon_modes
    assert all(
        isinstance(node.process, LMI_ComputeExpVal) for node in network.output_nodes
    )

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) > 0
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0.0, 2 * np.pi / gamma, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))


def test_run_LMI_network_classical_ip():
    timesteps = 5
    framework = "Interaction"
    mode = "Classical"

    df, network = run_LMI_network(
        picture=framework, mode=mode, timesteps=timesteps, broker=gen_broker()
    )

    num_photon_modes = 3
    assert len(network.output_nodes) == num_photon_modes * timesteps
    assert all(
        isinstance(node.process, LMI_ComputeExpVal) for node in network.output_nodes
    )

    assert len(network.output_nodes) > 0
    for output_node in network.output_nodes:
        assert len(output_node.output_edges) > 0
        for edge in output_node.output_edges:
            assert edge.data[0].properties["Usage"] == "Expectation Value"
            assert edge.data[0].properties["Evolved Time"] in list(
                np.linspace(0.0, 1.0, timesteps)
            )
            assert edge.data[0].properties["Photon Idx"] in list(range(NF))


def test_run_LMI_network_quantum_sp_order_1():
    timesteps = 5
    framework = "Schrodinger"
    mode = "Quantum"
    order = 1

    df, network = run_LMI_network(
        picture=framework,
        mode=mode,
        trotter_order=order,
        timesteps=timesteps,
        broker=gen_broker(),
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    assert len(final_circuit.instructions) == circuit_depth


def test_run_LMI_network_quantum_sp_order_2():
    timesteps = 5
    framework = "Schrodinger"
    mode = "Quantum"
    order = 2

    df, network = run_LMI_network(
        picture=framework,
        mode=mode,
        trotter_order=order,
        timesteps=timesteps,
        broker=gen_broker(),
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    assert len(final_circuit.instructions) == circuit_depth


def test_run_LMI_network_quantum_ip_order_1():
    timesteps = 5
    framework = "Interaction"
    mode = "Quantum"
    order = 1

    df, network = run_LMI_network(
        picture=framework,
        mode=mode,
        trotter_order=order,
        timesteps=timesteps,
        broker=gen_broker(),
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    qubits_per_photon = 2
    qubits_per_emitter = 1
    num_photon_modes = 3
    assert (
        len(final_circuit.instructions)
        == circuit_depth + num_photon_modes * qubits_per_photon + qubits_per_emitter
    )


def test_run_LMI_network_quantum_ip_order_2():
    timesteps = 5
    framework = "Interaction"
    mode = "Quantum"
    order = 2

    df, network = run_LMI_network(
        picture=framework,
        mode=mode,
        trotter_order=order,
        timesteps=timesteps,
        broker=gen_broker(),
    )

    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "eJCM Circuit"
    )
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, QuantumCircuit
    )

    circuit_depth = 0
    for node in network.nodes:
        if isinstance(node.process, LMI_ConstructTrotter):
            circuit: QuantumCircuit = node.output_edges[0].data[0].data
            circuit_depth = circuit_depth + len(circuit.instructions)

    final_circuit: QuantumCircuit = network.output_nodes[0].output_edges[0].data[0].data

    qubits_per_photon = 2
    qubits_per_emitter = 1
    num_photon_modes = 3
    assert (
        len(final_circuit.instructions)
        == circuit_depth + num_photon_modes * qubits_per_photon + qubits_per_emitter
    )
