from workflow.simulation.data import Data
from workflow.simulation.graph import DirectedEdge
from workflow.simulation.resources.classical_device import ClassicalDevice

from workflow.simulation.Process_Library.PDS_Comp import *

# from workflow.simulation.Process_Library.LUCJ_Comp import *
from workflow.simulation.Process_Library.PDS_dtypes import *
from workflow.simulation.broker import Broker
from workflow.simulation.devices.quantum_devices import *

import pytest
import itertools


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    HPC = ClassicalDevice(
        device_name="Boeing HPC Rigel: Node 0",
        processor_type="CPU",
        RAM=242 * 10**9,
        properties={"Cores": 64, "Clock Speed": 2.8 * 10**9},
    )

    broker = Broker(
        classical_devices=[supercomputer, HPC],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
    )
    return broker


def get_index(node, selection_nodes):
    for idx in range(len(selection_nodes)):
        if node in selection_nodes[idx]:
            return idx
    return -1


def test_reaction_selection():
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=5, properties={"Usage": "Number of Sites"}),
        ],
    ]

    network = PDS_reaction_selection()
    network.broker = gen_broker()

    network.run(network.input_nodes, starting_inputs=starting_inputs)

    assert len(network.output_nodes) == 3
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Material Selection"
    )
    assert (
        network.output_nodes[1].output_edges[0].data[0].properties["Usage"]
        == "Reactant Selection"
    )
    assert (
        network.output_nodes[2].output_edges[0].data[0].properties["Usage"]
        == "Set of Reactions"
    )
    assert len(network.output_nodes[2].output_edges[0].data[0].data) == 4


def test_schrodinger_geometries():
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=3, properties={"Usage": "Number of Sites"}),
        ],
    ]

    reaction_selection = PDS_reaction_selection()
    schrodinger_geometries = PDS_schrodinger_geometries()
    network = reaction_selection + schrodinger_geometries

    network.broker = gen_broker()
    network.run(network.input_nodes, starting_inputs=starting_inputs)

    assert isinstance(network.output_nodes[0].output_edges[0].data[0].data, Geometry)
    assert isinstance(network.output_nodes[1].output_edges[0].data[0].data, Geometry)
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Reactant Geometry"
    )
    assert (
        network.output_nodes[1].output_edges[0].data[0].properties["Usage"]
        == "Product Geometry"
    )


def test_geometry_optimization():
    num_images = 5
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()

    network = reaction_selection + geometry_optimization
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(network.input_nodes, starting_inputs=starting_inputs)

    assert len(network.output_nodes[0].output_edges) == num_images
    for idx in range(num_images):
        assert (
            network.output_nodes[0].output_edges[idx].data[0].properties["Usage"]
            == "Transition Geometry"
        )
        assert (
            network.output_nodes[0].output_edges[idx].data[0].properties["Image"]
            == idx + 1
        )


def test_hartree_fock():
    num_images = 1
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    hf_network = PDS_hartree_fock(num_images, iterations=3)
    hf_select_basis = hf_network.get_node(PDS_HFSelectBasis)[0]

    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + hf_network
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(network.input_nodes, starting_inputs=starting_inputs)

    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, HFMolOrbitals
    )
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Molecular Orbitals"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Image"] == 1


def test_hartree_fock_3_images():
    num_images = 3
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    hf_network = [
        PDS_hartree_fock(idx, iterations=3) for idx in range(1, num_images + 1)
    ]
    hf_network = functools.reduce(lambda a, b: a @ b, hf_network)

    hf_select_basis_nodes = hf_network.get_node(PDS_HFSelectBasis)
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]

    for node in hf_select_basis_nodes:
        define_reactions.extend(node)

    network = reaction_selection + geometry_optimization + hf_network
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(network.input_nodes, starting_inputs=starting_inputs)

    images = [1, 2, 3]
    assert len(network.output_nodes) == num_images
    for node in network.output_nodes:
        assert len(node.output_edges) == 1
        assert isinstance(node.output_edges[0].data[0].data, HFMolOrbitals)
        assert node.output_edges[0].data[0].properties["Usage"] == "Molecular Orbitals"
        images.remove(node.output_edges[0].data[0].properties["Image"])

    assert len(images) == 0


@pytest.mark.parametrize("select_idx", [i for i in range(4)])
def test_gse_preprocessing(select_idx):
    num_images = 1
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=3)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=[select_idx],
    )

    assert len(network.output_nodes) == 2
    assert isinstance(
        network.output_nodes[0].output_edges[0].data[0].data, FermionicHam
    )
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Active Space Fermionic Hamiltonian"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Image"] == 1
    assert isinstance(network.output_nodes[1].output_edges[0].data[0].data, MultiRefWF)
    assert (
        network.output_nodes[1].output_edges[0].data[0].properties["Usage"]
        == "Multi Reference Wavefunction"
    )
    assert network.output_nodes[1].output_edges[0].data[0].properties["Image"] == 1

    selection_nodes = network.selection_nodes[0]
    for node in network.nodes:
        if node in selection_nodes:
            if node == selection_nodes[select_idx]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"
        else:
            if isinstance(node.process, PDS_ComputeFermionicHam):
                assert node.process.status == "UNSTARTED"
            else:
                assert node.process.status == "COMPLETED"


def test_gse_preprocessing_no_active_space():
    num_images = 1
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=3)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=[None],
    )

    assert len(network.output_nodes) == 2
    assert all(
        isinstance(node.process, (PDS_ComputeASHamiltonian, PDS_ComputeMultiRefWF))
        for node in network.output_nodes
    )

    for node in network.nodes:
        if isinstance(
            node.process,
            (
                PDS_ActiveSpaceDD,
                PDS_ActiveSpaceAVAS,
                PDS_ActiveSpaceIAO,
                PDS_ActiveSpaceIBO,
                PDS_ComputeMultiRefWF,
                PDS_ComputeASHamiltonian,
                PDS_ComputeFermionicHam,
            ),
        ):
            assert node.process.status == "UNSTARTED"
        else:
            assert node.process.status == "COMPLETED"


@pytest.mark.parametrize(
    "select_idxs", list(itertools.combinations_with_replacement(range(4), 3))
)
def test_gse_processing_3_images(select_idxs):
    num_images = 3
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = [
        PDS_gse_preprocessing(idx, iterations=3) for idx in range(1, num_images + 1)
    ]
    gse_preprocessing = functools.reduce(lambda a, b: a @ b, gse_preprocessing)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    for node in hf_select_basis:
        define_reactions.extend(node)

    network = reaction_selection + geometry_optimization + gse_preprocessing
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes, starting_inputs=starting_inputs, selected_nodes=select_idxs
    )

    assert len(network.output_nodes) == num_images * 2
    for idx in range(num_images * 2):
        if idx % 2 == 0:
            assert isinstance(
                network.output_nodes[idx].output_edges[0].data[0].data, FermionicHam
            )
            assert (
                network.output_nodes[idx].output_edges[0].data[0].properties["Usage"]
                == "Active Space Fermionic Hamiltonian"
            )
        elif idx % 2 == 1:
            assert isinstance(
                network.output_nodes[idx].output_edges[0].data[0].data, MultiRefWF
            )
            assert (
                network.output_nodes[idx].output_edges[0].data[0].properties["Usage"]
                == "Multi Reference Wavefunction"
            )

        assert (
            network.output_nodes[idx].output_edges[0].data[0].properties["Image"]
            == idx // 2 + 1
        )

    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(node.process, PDS_ComputeFermionicHam):
                assert node.process.status == "UNSTARTED"
            else:
                assert (
                    node.process.status == "COMPLETED"
                ), f"Invalid status for node {node}"
        else:
            if node == selection_nodes[idx][select_idxs[idx]]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"


@pytest.mark.parametrize("select_idx", [[i, j] for i in range(4) for j in range(3)])
def test_gse_dmrg(select_idx):
    num_images = 1
    hf_iterations = 3
    dmrg_iterations = 4
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=hf_iterations)
    gse_dmrg = PDS_gse_dmrg(iterations=dmrg_iterations)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing + gse_dmrg
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    max_bond_input = Data(data=1024, properties={"Usage": "Max Bond Dimension"})

    for node in network.get_node(PDS_DMRGInitializeMPS):
        input_edge = DirectedEdge(
            data=(max_bond_input,),
            source_node=None,
            dest_nodes=[node],
        )
        node.append_input_edge(input_edge)

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=select_idx,
    )

    assert len(network.output_nodes) == 1
    assert isinstance(network.output_nodes[0].output_edges[0].data[0].data, MultiRefWF)
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ground State"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Image"] == 1
    assert isinstance(network.output_nodes[0].output_edges[1].data[0].data, GSE)
    assert network.output_nodes[0].output_edges[1].data[0].data.method == "DMRG"
    assert (
        network.output_nodes[0].output_edges[1].data[0].properties["Usage"]
        == "Ground State Energy"
    )
    assert network.output_nodes[0].output_edges[1].data[0].properties["Image"] == 1

    hf_check_convergence_nodes = network.get_node(PDS_HFCheckConvergence)
    assert len(hf_check_convergence_nodes) == hf_iterations
    dmrg_check_convergence_nodes = network.get_node(PDS_DMRGCheckConvergence)
    assert len(dmrg_check_convergence_nodes) == dmrg_iterations + 1

    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(node.process, PDS_ComputeFermionicHam):
                assert node.process.status == "UNSTARTED"
            else:
                assert (
                    node.process.status == "COMPLETED"
                ), f"Invalid status for node {node}"
        else:
            if node == selection_nodes[idx][select_idx[idx]]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"


@pytest.mark.parametrize("select_idx", [i for i in range(4)])
def test_gse_dmrg_no_selection(select_idx):
    num_images = 1
    hf_iterations = 3
    dmrg_iterations = 4
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=hf_iterations)
    gse_dmrg = PDS_gse_dmrg(iterations=dmrg_iterations)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing + gse_dmrg
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=[select_idx, None],
    )

    assert len(network.output_nodes) == 1
    assert isinstance(network.output_nodes[0].process, PDS_DMRGCheckConvergence)

    hf_check_convergence_nodes = network.get_node(PDS_HFCheckConvergence)
    assert len(hf_check_convergence_nodes) == hf_iterations
    dmrg_check_convergence_nodes = network.get_node(PDS_DMRGCheckConvergence)
    assert len(dmrg_check_convergence_nodes) == 1

    active_space_nodes = network.selection_nodes[0]
    for node in network.nodes:
        if node in active_space_nodes:
            if node == active_space_nodes[select_idx]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"
        else:
            if isinstance(
                node.process,
                (
                    PDS_BKMapping,
                    PDS_SCBKMapping,
                    PDS_JWMapping,
                    PDS_DMRGCanonizeMPS,
                    PDS_DMRGInitializeMPS,
                    PDS_DMRGHamiltonianMPO,
                    PDS_DMRGOptimizeSite,
                    PDS_DMRGCheckConvergence,
                    PDS_ComputeFermionicHam,
                ),
            ):
                assert node.process.status == "UNSTARTED"
            else:
                if isinstance(node.process, PDS_DFEncoding):
                    assert node.process.status == "UNSTARTED"
                else:
                    assert (
                        node.process.status == "COMPLETED"
                    ), f"Invalid status for node {node}"


@pytest.mark.parametrize("select_idx", [[i, j] for i in range(4) for j in range(3)])
def test_gse_vqe(select_idx):
    num_images = 1
    hf_iterations = 3
    vqe_iterations = 4
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=hf_iterations)
    gse_dmrg = PDS_gse_vqe(iterations=vqe_iterations)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing + gse_dmrg
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=select_idx,
    )

    assert len(network.output_nodes) == 1
    assert isinstance(network.output_nodes[0].output_edges[0].data[0].data, GSE)
    assert network.output_nodes[0].output_edges[0].data[0].data.method == "VQE"
    assert (
        network.output_nodes[0].output_edges[0].data[0].properties["Usage"]
        == "Ground State Energy"
    )
    assert network.output_nodes[0].output_edges[0].data[0].properties["Image"] == 1

    hf_check_convergence_nodes = network.get_node(PDS_HFCheckConvergence)
    assert len(hf_check_convergence_nodes) == hf_iterations
    vqe_check_convergence_nodes = network.get_node(PDS_VQECheckConvergence)
    assert len(vqe_check_convergence_nodes) == vqe_iterations + 1

    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(node.process, PDS_ComputeFermionicHam):
                assert node.process.status == "UNSTARTED"
            else:
                assert (
                    node.process.status == "COMPLETED"
                ), f"Invalid status for node {node}"
        else:
            if node == selection_nodes[idx][select_idx[idx]]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"


@pytest.mark.parametrize("select_idx", [i for i in range(4)])
def test_gse_vqe_no_selection(select_idx):
    num_images = 1
    hf_iterations = 3
    vqe_iterations = 4
    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=10, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=2, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    reaction_selection = PDS_reaction_selection()
    geometry_optimization = PDS_geometry_optimization()
    gse_preprocessing = PDS_gse_preprocessing(num_images, iterations=hf_iterations)
    gse_vqe = PDS_gse_vqe(iterations=vqe_iterations)

    hf_select_basis = gse_preprocessing.get_node(PDS_HFSelectBasis)[0]
    define_reactions = reaction_selection.get_node(PDS_DefineReactions)[0]
    define_reactions.extend(hf_select_basis)

    network = reaction_selection + geometry_optimization + gse_preprocessing + gse_vqe
    network.input_nodes.append(geometry_optimization.get_node(PDS_NudgedElasticBand)[0])

    network.broker = gen_broker()
    network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=[select_idx, None],
    )

    assert len(network.output_nodes) == 1
    assert isinstance(network.output_nodes[0].process, PDS_VQECheckConvergence)

    hf_check_convergence_nodes = network.get_node(PDS_HFCheckConvergence)
    assert len(hf_check_convergence_nodes) == hf_iterations
    vqe_check_convergence_nodes = network.get_node(PDS_VQECheckConvergence)
    assert len(vqe_check_convergence_nodes) == 1

    active_space_nodes = network.selection_nodes[0]
    for node in network.nodes:
        if node in active_space_nodes:
            if node == active_space_nodes[select_idx]:
                assert node.process.status == "COMPLETED"
            else:
                assert node.process.status == "UNSTARTED"
        else:
            if isinstance(
                node.process,
                (
                    PDS_BKMapping,
                    PDS_SCBKMapping,
                    PDS_JWMapping,
                    PDS_VQESetAnsatz,
                    PDS_VQEEvolveState,
                    PDS_VQEMeasureExpVal,
                    PDS_VQECheckConvergence,
                    PDS_ComputeFermionicHam,
                    PDS_DFEncoding,
                ),
            ):
                assert node.process.status == "UNSTARTED"
            else:
                assert (
                    node.process.status == "COMPLETED"
                ), f"Invalid status for node {node}"


@pytest.mark.parametrize(
    "active_space_method, encoding_method",
    [(a, b) for a in ["DD", "AVAS", "IAO", "IBO"] for b in ["SCBK", "JW", "BK"]],
)
def test_run_PDS_dmrg(active_space_method, encoding_method):
    df, network = run_PDS_comp_network(
        num_sites_slab=10,
        num_sites_reactant=2,
        num_images=3,
        hf_iterations=10,
        active_space_method=active_space_method,
        gse_method="DMRG",
        encoding_method=encoding_method,
        dmrg_iterations=4,
        broker=gen_broker(),
    )

    available_AS_methods = ["DD", "AVAS", "IAO", "IBO"]
    available_GSE_methods = ["DMRG", "QPE", "SQD", "VQE"]
    available_ham_encoding_methods = ["SCBK", "JW", "BK"]

    gse_idxs = [None] * len(available_GSE_methods)
    gse_idxs[available_GSE_methods.index("DMRG")] = (
        available_ham_encoding_methods.index(encoding_method)
    )

    selection_idxs = ([available_AS_methods.index(active_space_method)] + gse_idxs) * 3

    df_status = {"COMPLETED": 0, "UNSTARTED": 0}
    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(
                node.process,
                (PDS_ComputeFermionicHam, PDS_VQECheckConvergence, PDS_QPEComputeGSE),
            ):
                assert node.process.status == "UNSTARTED"
            elif isinstance(node.process, (PDS_DMRGCheckConvergence, PDS_MKM)):
                assert node.process.status == "COMPLETED"
            elif isinstance(node.process, PDS_DFEncoding):
                df_status[node.process.status] += 1
        else:
            try:
                if node == selection_nodes[idx][selection_idxs[idx]]:
                    assert node.process.status == "COMPLETED"
                else:
                    assert node.process.status == "UNSTARTED"
            except TypeError:
                assert selection_idxs[idx] is None

    dmrg_check_convergence_nodes = network.get_node(PDS_DMRGCheckConvergence)
    assert len(dmrg_check_convergence_nodes) == 4 * 3
    assert df_status["UNSTARTED"] == 9
    assert df_status["COMPLETED"] == 3


@pytest.mark.parametrize(
    "active_space_method, encoding_method",
    [(a, b) for a in ["DD", "AVAS", "IAO", "IBO"] for b in ["SCBK", "JW", "BK"]],
)
def test_run_PDS_vqe(active_space_method, encoding_method):
    df, network = run_PDS_comp_network(
        num_sites_slab=10,
        num_sites_reactant=2,
        num_images=3,
        hf_iterations=10,
        active_space_method=active_space_method,
        gse_method="VQE",
        encoding_method=encoding_method,
        dmrg_iterations=4,
        vqe_iterations=4,
        broker=gen_broker(),
    )

    available_AS_methods = ["DD", "AVAS", "IAO", "IBO"]
    available_GSE_methods = ["DMRG", "QPE", "SQD", "VQE"]
    available_ham_encoding_methods = ["SCBK", "JW", "BK"]

    gse_idxs = [None] * len(available_GSE_methods)
    gse_idxs[available_GSE_methods.index("VQE")] = available_ham_encoding_methods.index(
        encoding_method
    )

    selection_idxs = ([available_AS_methods.index(active_space_method)] + gse_idxs) * 3

    df_status = {"COMPLETED": 0, "UNSTARTED": 0}
    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(
                node.process,
                (PDS_ComputeFermionicHam, PDS_DMRGCheckConvergence, PDS_QPEComputeGSE),
            ):
                assert node.process.status == "UNSTARTED"
            elif isinstance(node.process, (PDS_VQECheckConvergence, PDS_MKM)):
                assert node.process.status == "COMPLETED"
            elif isinstance(node.process, PDS_DFEncoding):
                df_status[node.process.status] += 1
        else:
            try:
                if node == selection_nodes[idx][selection_idxs[idx]]:
                    assert node.process.status == "COMPLETED"
                else:
                    assert node.process.status == "UNSTARTED"
            except TypeError:
                assert selection_idxs[idx] is None

    vqe_check_convergence_nodes = network.get_node(PDS_VQECheckConvergence)
    assert len(vqe_check_convergence_nodes) == 5 * 3
    assert df_status["UNSTARTED"] == 9
    assert df_status["COMPLETED"] == 3


@pytest.mark.skip(
    reason="No devices under current broker can support the qubit requirements"
)
@pytest.mark.parametrize(
    "active_space_method, encoding_method",
    [(a, b) for a in ["DD", "AVAS", "IAO", "IBO"] for b in ["SCBK", "JW", "BK"]],
)
def test_run_PDS_qpe(active_space_method, encoding_method):
    df, network = run_PDS_comp_network(
        num_sites_slab=10,
        num_sites_reactant=2,
        num_images=3,
        hf_iterations=10,
        active_space_method=active_space_method,
        gse_method="QPE",
        encoding_method=encoding_method,
        dmrg_iterations=4,
        broker=gen_broker(),
    )

    available_AS_methods = ["DD", "AVAS", "IAO", "IBO"]
    available_GSE_methods = ["DMRG", "QPE", "SQD", "VQE"]
    available_ham_encoding_methods = ["SCBK", "JW", "BK"]

    gse_idxs = [None] * len(available_GSE_methods)
    gse_idxs[available_GSE_methods.index("QPE")] = available_ham_encoding_methods.index(
        encoding_method
    )

    selection_idxs = ([available_AS_methods.index(active_space_method)] + gse_idxs) * 3

    df_status = {"COMPLETED": 0, "UNSTARTED": 0}
    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(
                node.process,
                (
                    PDS_ComputeFermionicHam,
                    PDS_DMRGCheckConvergence,
                    PDS_VQECheckConvergence,
                ),
            ):
                assert node.process.status == "UNSTARTED"
            elif isinstance(node.process, (PDS_QPEComputeGSE, PDS_MKM)):
                assert node.process.status == "COMPLETED"
            elif isinstance(node.process, PDS_DFEncoding):
                df_status[node.process.status] += 1
        else:
            try:
                if node == selection_nodes[idx][selection_idxs[idx]]:
                    assert node.process.status == "COMPLETED"
                else:
                    assert node.process.status == "UNSTARTED"
            except TypeError:
                assert selection_idxs[idx] is None

    dmrg_check_convergence_nodes = network.get_node(PDS_QPEComputeGSE)
    assert len(dmrg_check_convergence_nodes) == 3
    assert df_status["UNSTARTED"] == 9
    assert df_status["COMPLETED"] == 3


@pytest.mark.parametrize(
    "active_space_method, encoding_method",
    [(a, b) for a in ["DD", "AVAS", "IAO", "IBO"] for b in ["SCBK", "JW", "BK"]],
)
def test_run_PDS_sqd(active_space_method, encoding_method):
    df, network = run_PDS_comp_network(
        num_sites_slab=10,
        num_sites_reactant=2,
        num_images=3,
        hf_iterations=10,
        active_space_method=active_space_method,
        gse_method="SQD",
        encoding_method=encoding_method,
        sqd_iterations=1,
        broker=gen_broker(),
    )

    available_AS_methods = ["DD", "AVAS", "IAO", "IBO"]
    available_GSE_methods = ["DMRG", "QPE", "SQD", "VQE"]
    available_ham_encoding_methods = ["SCBK", "JW", "BK"]

    gse_idxs = [None] * len(available_GSE_methods)
    gse_idxs[available_GSE_methods.index("SQD")] = available_ham_encoding_methods.index(
        encoding_method
    )

    selection_idxs = ([available_AS_methods.index(active_space_method)] + gse_idxs) * 3

    df_status = {"COMPLETED": 0, "UNSTARTED": 0}
    selection_nodes = network.selection_nodes
    for node in network.nodes:
        idx = get_index(node, selection_nodes)
        if idx == -1:
            if isinstance(
                node.process,
                (
                    PDS_ComputeFermionicHam,
                    PDS_DMRGCheckConvergence,
                    PDS_VQECheckConvergence,
                ),
            ):
                assert node.process.status == "UNSTARTED"
            elif isinstance(node.process, (PDS_SQDCheckConvergence, PDS_MKM)):
                assert node.process.status == "COMPLETED"
            elif isinstance(node.process, PDS_DFEncoding):
                df_status[node.process.status] += 1
        else:
            try:
                if node == selection_nodes[idx][selection_idxs[idx]]:
                    assert node.process.status == "COMPLETED"
                else:
                    assert node.process.status == "UNSTARTED"
            except TypeError:
                assert selection_idxs[idx] is None

    sqd_iters = len(network.get_node(PDS_SQDCheckConvergence))
    assert sqd_iters == 2 * 3
    assert df_status["UNSTARTED"] == 9
    assert df_status["COMPLETED"] == 3


@pytest.mark.skip(reason="For visualization")
def test_visualize():
    df, network = run_PDS_comp_network(
        num_sites_slab=10,
        num_sites_reactant=2,
        num_images=1,
        hf_iterations=1,
        dmrg_iterations=1,
        active_space_method="IAO",
        gse_method="SQD",
        encoding_method="SCBK",
        sqd_iterations=10,
        vqe_iterations=0,
        broker=gen_broker(),
    )

    # network.visualize(font_size=8)
    # network.generate_gantt_plot()
    # print(df.raw.to_string())
