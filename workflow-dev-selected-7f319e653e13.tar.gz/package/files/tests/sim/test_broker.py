from workflow.simulation.data import Data
from workflow.simulation.process import (
    ClassicalProcess,
    QuantumProcess,
    Task,
)

from workflow.simulation.resources.classical_device import (
    ClassicalDevice,
    DeviceAllocation,
    ClassicalResource,
)
from workflow.simulation.resources.quantum_device import (
    QDeviceAllocation,
    QuantumResource,
)
from workflow.simulation.resources.equipment import (
    Equipment,
    EquipmentAllocation,
    EquipmentResource,
)
from workflow.simulation.resources.personnel import (
    Personnel,
    PersonnelAllocation,
    PersonnelResource,
)

from workflow.simulation.resources.resources import Resource, Allocation
from workflow.simulation.broker import Broker
from workflow.simulation.devices.quantum_devices import *

from qiskit.circuit.random import random_circuit


def gen_broker():

    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        operational_cost=4.2,
        overhead_cost=10,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    HPC = ClassicalDevice(
        device_name="Boeing HPC Rigel: Node 0",
        processor_type="CPU",
        RAM=242 * 10**9,
        operational_cost=0.42,
        overhead_cost=100,
        properties={"Cores": 64, "Clock Speed": int(2.8 * 10**9)},
    )

    P1 = Personnel(
        title="Research Scientist",
        labor_cost=200000,
        overhead_cost=15000,
        clearance="Top Secret",
        skillset=["Research"],
        certifications=[],
    )

    P2 = Personnel(
        title="Mechanical Engineer",
        labor_cost=180000,
        overhead_cost=20000,
        clearance="Secret",
        skillset=["Engineering"],
        certifications=["Professonial Engineer License"],
    )

    P3 = Personnel(
        title="Lab Intern",
        labor_cost=40000,
        overhead_cost=2000,
        clearance=None,
        skillset=["Research"],
        certifications=[],
    )

    E1 = Equipment(
        name="Thermal Vacuum Chamber",
        operational_cost=50,
        overhead_cost=2000,
        capacity=4,
        serial_id="f424242",
    )

    E2 = Equipment(
        name="Universal Testing Machine",
        operational_cost=20,
        overhead_cost=1300,
        capacity=2,
        serial_id=None,
    )

    classical_devices = [supercomputer, HPC]
    quantum_devices = [
        IBM_Boston(),
        IBM_Miami(),
        IBM_Fez(),
        IBM_Kingston(),
        IBM_Pittsburgh(),
        IBM_Marrakesh(),
    ]
    personnel = [P1, P2, P3]
    equipment = [E1, E2]

    broker = Broker(
        classical_devices=classical_devices,
        quantum_devices=quantum_devices,
        personnel=personnel,
        equipment=equipment,
    )

    return broker


def verify_allocation(resource: Resource, allocation: Allocation) -> bool:

    verified_allocation = True
    if isinstance(resource, ClassicalResource):
        assert isinstance(
            allocation, DeviceAllocation
        ), f"Expected DeviceAllocation for ClassicalResource requirement but got {type(allocation)} instead"

        conditions = (
            resource.memory <= allocation.allocated_memory,
            resource.num_cores <= allocation.allocated_cores,
        )

    elif isinstance(resource, QuantumResource):
        assert isinstance(
            allocation, QDeviceAllocation
        ), f"Expected QDeviceAllocation for QuantumResource requirement but got {type(allocation)} instead"

        try:
            qubit_count = resource.circuit.qubit_count
        except:
            qubit_count = resource.circuit.num_qubits

        conditions = (qubit_count <= len(allocation.allocated_qubit_idxs),)

    elif isinstance(resource, EquipmentResource):
        assert isinstance(
            allocation, EquipmentAllocation
        ), f"Expected EquipmentAllocation for Equipment requirement but got {type(allocation)} instead"

        conditions = (
            resource.name == allocation.name,
            resource.slots <= allocation.slots,
        )

    elif isinstance(resource, PersonnelResource):
        assert isinstance(
            allocation, PersonnelAllocation
        ), f"Expected PersonnelAllocation for Personnel requirement but got {type(allocation)} instead"

        conditions = (
            resource.title == allocation.title or resource.title is None,
            Personnel.CLEARANCE[resource.clearance]
            <= Personnel.CLEARANCE[allocation.clearance],
            all(skill in allocation.skillset for skill in resource.skillset),
            all(cert in allocation.certs for cert in resource.certs),
        )

    else:
        raise TypeError(
            f"Invalid Resource type: {type(resource)}. Expected ClassicalResource, QuantumResource, EquipmentResource or PersonnelResource"
        )

    verified_allocation = verified_allocation and all(conditions)

    return verified_allocation


def test_init_broker():
    broker = gen_broker()


### CLASSICAL
def test_classical_resource_allocation():
    broker = gen_broker()

    requested_resource = ClassicalResource(memory=42e6, num_cores=16)
    allocations = broker.request_allocation(requested_resource)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource == requested_resource
        assert isinstance(allocation, DeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name == "Boeing HPC Rigel: Node 0"

    hpc = broker.classical_devices[1]
    assert hpc.cores["AVAILABLE"] == 64 - 16
    assert hpc.cores["ACTIVE"] == 16


def test_classical_resource_deallocation():
    broker = gen_broker()

    requested_resource = ClassicalResource(memory=42e6, num_cores=16)
    allocations = broker.request_allocation(requested_resource)
    (allocation,) = allocations.values()
    broker.request_deallocation(allocation)

    hpc = broker.classical_devices[1]
    assert hpc.cores["AVAILABLE"] == 64
    assert hpc.cores["ACTIVE"] == 0


def test_classical_resource_list_allocation():
    broker = gen_broker()

    requested_resources = [
        ClassicalResource(memory=42e6, num_cores=16),
        ClassicalResource(memory=42e6, num_cores=14),
    ]
    allocations = broker.request_allocation(requested_resources)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    for resource, allocation in allocations.items():
        assert resource in requested_resources
        assert isinstance(allocation, DeviceAllocation)
        assert verify_allocation(resource, allocation)

        if resource.num_cores > 15:
            assert allocation.name == "Boeing HPC Rigel: Node 0"
        else:
            assert allocation.name == "Supercomputer"

    supercomputer = broker.classical_devices[0]
    hpc = broker.classical_devices[1]
    assert supercomputer.cores["AVAILABLE"] == 15 - 14
    assert supercomputer.cores["ACTIVE"] == 14
    assert hpc.cores["AVAILABLE"] == 64 - 16
    assert hpc.cores["ACTIVE"] == 16


def test_classical_resource_list_deallocation():
    broker = gen_broker()

    requested_resources = [
        ClassicalResource(memory=42e6, num_cores=16),
        ClassicalResource(memory=42e6, num_cores=14),
    ]
    allocations = broker.request_allocation(requested_resources)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    supercomputer = broker.classical_devices[0]
    hpc = broker.classical_devices[1]
    assert supercomputer.cores["AVAILABLE"] == 15
    assert supercomputer.cores["ACTIVE"] == 0
    assert hpc.cores["AVAILABLE"] == 64
    assert hpc.cores["ACTIVE"] == 0


class DummyClassical(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        pass

    def set_required_resources(self):
        self.required_resources = [ClassicalResource(memory=42e6, num_cores=14)]

    def set_output_properties(self):
        pass

    def compute_flop_count(self):
        return 300e9

    def validate_data(self) -> bool:
        return True

    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        pass


def test_classical_process_allocation():
    broker = gen_broker()

    process = DummyClassical()
    process.set_required_resources()
    process.flops = process.compute_flop_count()
    allocations = broker.request_allocation(process)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource in process.required_resources
        assert isinstance(allocation, DeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name == "Supercomputer"

    supercomputer = broker.classical_devices[0]
    assert supercomputer.cores["AVAILABLE"] == 15 - 14
    assert supercomputer.cores["ACTIVE"] == 14

    # TODO: Move this test to test_process
    for device in broker.classical_devices:
        assert (
            process.get_process_duration(device)
            == process.flops / device.clock_frequency
        )


def test_classical_process_deallocation():
    broker = gen_broker()

    process = DummyClassical()
    process.set_required_resources()
    process.flops = process.compute_flop_count()

    allocations = broker.request_allocation(process)
    (allocation,) = allocations.values()
    broker.request_deallocation(allocation)

    supercomputer = broker.classical_devices[0]
    assert supercomputer.cores["AVAILABLE"] == 15
    assert supercomputer.cores["ACTIVE"] == 0


def test_classical_process_cost_optimization():
    broker = gen_broker()

    process = DummyClassical()
    process.set_required_resources()
    process.flops = process.compute_flop_count()

    allocations = broker.request_allocation(process, optimize="cost")

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource in process.required_resources
        assert isinstance(allocation, DeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name == "Boeing HPC Rigel: Node 0"

    hpc = broker.classical_devices[1]
    assert hpc.cores["AVAILABLE"] == 64 - 14
    assert hpc.cores["ACTIVE"] == 14


### QUANTUM
def test_quantum_resource_allocation():
    broker = gen_broker()
    quantum_device_names = [device.name for device in broker.quantum_devices]

    requested_resource = QuantumResource(quantum_circuit=random_circuit(50, 25, 2))
    allocations = broker.request_allocation(requested_resource)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource == requested_resource
        assert isinstance(allocation, QDeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name in quantum_device_names

    (allocation,) = allocations.values()
    allocation: QDeviceAllocation
    for device in broker.quantum_devices:
        if device.name == allocation.name:
            assert all(
                used_qubit not in device.available_qubits
                for used_qubit in allocation.allocated_qubit_idxs
            )
        else:
            assert device.available_qubits == list(range(device.num_qubits))


def test_quantum_resource_deallocation():
    broker = gen_broker()

    requested_resource = QuantumResource(quantum_circuit=random_circuit(50, 25, 2))
    allocations = broker.request_allocation(requested_resource)
    (allocation,) = allocations.values()

    broker.request_deallocation(allocation)

    for device in broker.quantum_devices:
        assert device.available_qubits == list(range(device.num_qubits))


def test_quantum_resource_list_allocation():
    broker = gen_broker()
    quantum_device_names = [device.name for device in broker.quantum_devices]

    requested_resource = [
        QuantumResource(quantum_circuit=random_circuit(50, 25, 2)),
        QuantumResource(quantum_circuit=random_circuit(50, 25, 2)),
    ]
    allocations = broker.request_allocation(requested_resource)

    assert isinstance(allocations, dict)
    (allocation1, allocation2) = allocations.values()
    allocation1: QDeviceAllocation
    allocation2: QDeviceAllocation

    assert (
        allocation1.name != allocation2.name
    )  # broker prioritizes assigning to quantum devices with more available qubits

    for resource, allocation in allocations.items():
        assert resource in requested_resource
        assert isinstance(allocation, QDeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name in quantum_device_names

    for device in broker.quantum_devices:
        if device.name == allocation1.name:
            assert all(
                used_qubit not in device.available_qubits
                for used_qubit in allocation1.allocated_qubit_idxs
            )
        elif device.name == allocation2.name:
            assert all(
                used_qubit not in device.available_qubits
                for used_qubit in allocation2.allocated_qubit_idxs
            )
        else:
            assert device.available_qubits == list(range(device.num_qubits))


def test_quantum_resource_list_deallocation():
    broker = gen_broker()

    requested_resource = [
        QuantumResource(quantum_circuit=random_circuit(50, 25, 2)),
        QuantumResource(quantum_circuit=random_circuit(50, 25, 2)),
    ]
    allocations = broker.request_allocation(requested_resource)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    broker.request_deallocation(allocation)

    for device in broker.quantum_devices:
        assert device.available_qubits == list(range(device.num_qubits))


class DummyQuantum(QuantumProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        shots=1e3,
    ):

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            shots=shots,
        )

    def set_expected_input_properties(self):
        pass

    def set_required_resources(self):
        self.required_resources = [
            QuantumResource(quantum_circuit=random_circuit(50, 25, 2))
        ]

    def set_output_properties(self):
        pass

    def validate_data(self) -> bool:
        return True

    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        pass


def test_quantum_process_allocation():
    broker = gen_broker()
    quantum_device_names = [device.name for device in broker.quantum_devices]

    process = DummyQuantum()
    process.set_required_resources()
    allocations = broker.request_allocation(process)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource in process.required_resources
        assert isinstance(allocation, QDeviceAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name in quantum_device_names

    (allocation,) = allocations.values()
    allocation: QDeviceAllocation
    for device in broker.quantum_devices:
        if device.name == allocation.name:
            assert all(
                used_qubit not in device.available_qubits
                for used_qubit in allocation.allocated_qubit_idxs
            )
        else:
            assert device.available_qubits == list(range(device.num_qubits))


def test_quantum_process_deallocation():
    broker = gen_broker()

    process = DummyQuantum()
    process.set_required_resources()
    allocations = broker.request_allocation(process)
    (allocation,) = allocations.values()
    broker.request_deallocation(allocation)

    for device in broker.quantum_devices:
        assert device.available_qubits == list(range(device.num_qubits))


### PERSONNEL
def test_personnel_resource_allocation():
    broker = gen_broker()

    requested_resource = PersonnelResource(title=None, clearance="Top Secret")
    allocations = broker.request_allocation(requested_resource)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource == requested_resource
        assert isinstance(allocation, PersonnelAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.title == "Research Scientist"

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.ACTIVE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.IDLE


def test_personnel_resource_deallocation():
    broker = gen_broker()

    requested_resource = PersonnelResource(title=None, clearance="Top Secret")
    allocations = broker.request_allocation(requested_resource)
    (allocation,) = allocations.values()
    broker.request_deallocation(allocation)

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.IDLE


def test_personnel_resource_list_allocation():
    broker = gen_broker()

    requested_resources = [
        PersonnelResource(title=None, clearance="Top Secret"),
        PersonnelResource(title="Lab Intern"),
    ]
    allocations = broker.request_allocation(requested_resources)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    for resource, allocation in allocations.items():
        assert resource in requested_resources
        assert isinstance(allocation, PersonnelAllocation)
        assert verify_allocation(resource, allocation)

        assert allocation.title in ["Research Scientist", "Lab Intern"]

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.ACTIVE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.ACTIVE


def test_personnel_resource_list_deallocation():
    broker = gen_broker()

    requested_resources = [
        PersonnelResource(title=None, clearance="Top Secret"),
        PersonnelResource(title="Lab Intern"),
    ]
    allocations = broker.request_allocation(requested_resources)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.IDLE


class DummyPersonnelTask(Task):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        pass

    def set_required_resources(self):
        self.required_resources = [
            PersonnelResource(
                clearance="Confidential",
                certifications=["Professonial Engineer License"],
            ),
            PersonnelResource(skillset=["Research"]),
        ]

    def set_output_properties(self):
        pass

    def compute_task_duration(self) -> float:
        """Computes the number of required flops for this process to complete given
        valid inputs from self.inputs. Will be unique to each Process.
        """
        return 300

    def validate_data(self) -> bool:
        return True

    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        pass


def test_personnel_process_allocation():
    broker = gen_broker()

    process = DummyPersonnelTask()
    process.set_required_resources()
    process.duration = process.compute_task_duration()
    allocations = broker.request_allocation(process)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    for resource, allocation in allocations.items():
        assert resource in process.required_resources
        assert isinstance(allocation, PersonnelAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.title in ["Mechanical Engineer", "Lab Intern"]

    assert process.get_process_duration() == 300

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.ACTIVE
    assert lab_intern.status == Personnel.ACTIVE


def test_personnel_process_deallocation():
    broker = gen_broker()

    process = DummyPersonnelTask()
    process.set_required_resources()
    process.duration = process.compute_task_duration()

    allocations = broker.request_allocation(process)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.IDLE


### EQUIPMENT
def test_equipment_resource_allocation():
    broker = gen_broker()

    requested_resource = EquipmentResource(
        name="Universal Testing Machine", required_slots=2
    )
    allocations = broker.request_allocation(requested_resource)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 1

    for resource, allocation in allocations.items():
        assert resource == requested_resource
        assert isinstance(allocation, EquipmentAllocation)
        assert verify_allocation(resource, allocation)
        assert allocation.name == "Universal Testing Machine"

    UTM = broker.equipment[1]
    assert UTM.slots["AVAILABLE"] == 2 - 2
    assert UTM.slots["ACTIVE"] == 2


def test_equipment_resource_deallocation():
    broker = gen_broker()

    requested_resource = EquipmentResource(
        name="Universal Testing Machine", required_slots=2
    )
    allocations = broker.request_allocation(requested_resource)
    (allocation,) = allocations.values()
    broker.request_deallocation(allocation)

    UTM = broker.equipment[1]
    assert UTM.slots["AVAILABLE"] == UTM.capacity
    assert UTM.slots["ACTIVE"] == 0


def test_equipment_resource_list_allocation():
    broker = gen_broker()

    requested_resources = [
        EquipmentResource(name="Universal Testing Machine", required_slots=2),
        EquipmentResource(
            name="Thermal Vacuum Chamber", required_slots=3, serial_id="f424242"
        ),
    ]
    allocations = broker.request_allocation(requested_resources)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    for resource, allocation in allocations.items():
        assert resource in requested_resources
        assert isinstance(allocation, EquipmentAllocation)
        assert verify_allocation(resource, allocation)

        assert allocation.name in [
            "Universal Testing Machine",
            "Thermal Vacuum Chamber",
        ]

    TVC = broker.equipment[0]
    UTM = broker.equipment[1]
    assert TVC.slots["AVAILABLE"] == TVC.capacity - 3
    assert TVC.slots["ACTIVE"] == 3
    assert UTM.slots["AVAILABLE"] == 2 - 2
    assert UTM.slots["ACTIVE"] == 2


def test_equipment_resource_list_deallocation():
    broker = gen_broker()

    requested_resources = [
        EquipmentResource(name="Universal Testing Machine", required_slots=2),
        EquipmentResource(
            name="Thermal Vacuum Chamber", required_slots=3, serial_id="f424242"
        ),
    ]
    allocations = broker.request_allocation(requested_resources)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    TVC = broker.equipment[0]
    UTM = broker.equipment[1]
    assert TVC.slots["AVAILABLE"] == TVC.capacity
    assert TVC.slots["ACTIVE"] == 0
    assert UTM.slots["AVAILABLE"] == UTM.capacity
    assert UTM.slots["ACTIVE"] == 0


class DummyEquipmentTask(Task):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        pass

    def set_required_resources(self):
        self.required_resources = [
            PersonnelResource(
                clearance="Confidential",
                certifications=["Professonial Engineer License"],
            ),
            EquipmentResource(
                name="Thermal Vacuum Chamber", required_slots=3, serial_id="f424242"
            ),
        ]

    def set_output_properties(self):
        pass

    def compute_task_duration(self) -> float:
        """Computes the number of required flops for this process to complete given
        valid inputs from self.inputs. Will be unique to each Process.
        """
        return 3600

    def validate_data(self) -> bool:
        return True

    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        pass


def test_equipment_process_allocation():
    broker = gen_broker()

    process = DummyEquipmentTask()
    process.set_required_resources()
    process.duration = process.compute_task_duration()
    allocations = broker.request_allocation(process)

    assert isinstance(allocations, dict)
    assert len(allocations.values()) == 2

    for resource, allocation in allocations.items():
        assert resource in process.required_resources
        assert isinstance(allocation, (EquipmentAllocation, PersonnelAllocation))
        assert verify_allocation(resource, allocation)

        if isinstance(allocation, PersonnelAllocation):
            assert allocation.title == "Mechanical Engineer"
        elif isinstance(allocation, EquipmentAllocation):
            assert allocation.name == "Thermal Vacuum Chamber"
        else:
            raise ValueError(
                f"Got unexpected allocation. Expected one PersonnelAllocation and one EquipmentAllocation"
            )

    assert process.compute_task_duration() == 3600

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.ACTIVE
    assert lab_intern.status == Personnel.IDLE

    TVC = broker.equipment[0]
    UTM = broker.equipment[1]
    assert TVC.slots["AVAILABLE"] == TVC.capacity - 3
    assert TVC.slots["ACTIVE"] == 3
    assert UTM.slots["AVAILABLE"] == UTM.capacity
    assert UTM.slots["ACTIVE"] == 0


def test_equipment_process_deallocation():
    broker = gen_broker()

    process = DummyEquipmentTask()
    process.set_required_resources()
    process.duration = process.compute_task_duration()

    allocations = broker.request_allocation(process)
    for _, allocation in allocations.items():
        broker.request_deallocation(allocation)

    research_scientist = broker.personnel[0]
    mech_engineer = broker.personnel[1]
    lab_intern = broker.personnel[2]
    assert research_scientist.status == Personnel.IDLE
    assert mech_engineer.status == Personnel.IDLE
    assert lab_intern.status == Personnel.IDLE

    TVC = broker.equipment[0]
    UTM = broker.equipment[1]
    assert TVC.slots["AVAILABLE"] == TVC.capacity
    assert TVC.slots["ACTIVE"] == 0
    assert UTM.slots["AVAILABLE"] == UTM.capacity
    assert UTM.slots["ACTIVE"] == 0
