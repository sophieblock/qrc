"""
Unit test file containing stuff for the EOY Demo 2025.

This file contains unit tests specifically tailored for the EOY Demo
in 2025, to be presented in Charleston, SC.

Authors:
    Joel Thompson (richard.j.thompson3@boeing.com)

"""

import logging

logger: logging.Logger = logging.getLogger(__name__)

# from workflow.optimize.library.pds import generate_pds_network
from workflow.simulation.devices.quantum_devices import *
from workflow.simulation.graph import Network, Node
from workflow.simulation.broker import Broker
from workflow.simulation.resources.classical_device import (
    ClassicalResource,
    ClassicalDevice,
)

import networkx as nx
import pytest

from typing import Iterable


def generate_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    broker = Broker(
        classical_devices=[supercomputer],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
    )
    return broker


@pytest.mark.skip("Missing optimize.library.pds")
def test_create_network():

    materials: Iterable[str] = ["AA7075", "AA7050"]
    coatings: Iterable[str] = ["Bare"]
    tempers: Iterable[str] = ["T6"]

    nodes: Iterable[Node]
    input_nodes: Iterable[Node]
    output_ndoes: Iterable[Node]
    network: Network

    nodes, input_nodes, output_nodes, network = generate_pds_network(
        materials=materials,
        coatings=coatings,
        tempers=tempers,
        broker=generate_broker(),
    )

    network.run(nodes, input_nodes, output_nodes)

    network.visualize(show=True)  # Uncomment to debug
    # graph = network.to_networkx()
    # pos = nx.spring_layout(graph)
    # nx.draw_networkx(graph, pos=pos)
