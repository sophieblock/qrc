"""
Tests Light/matter interactions (LMI) network optimization.

This file contains unit tests that specifically try out the resource
estimation network optimizer on the Light/matter interactions (LMI)
network problem.

Authors:
    Joel Thompson (richard.j.thompson3@boeing.com)

"""

import logging

logger: logging.Logger = logging.getLogger(__name__)

from workflow.simulation.Process_Library.LMI import run_LMI_network, gen_LMI_network
from workflow.simulation.devices.quantum_devices import *
from workflow.simulation.broker import Broker
from workflow.simulation.resources.classical_device import (
    ClassicalResource,
    ClassicalDevice,
)


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    broker = Broker(
        classical_devices=[supercomputer],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
    )
    return broker


def test_gen_LMI_network(caplog):
    """Just tests that we can successfully generate the LMI network."""

    caplog.set_level(logging.DEBUG)
    logger.debug("Trying to generate LMI network...")

    gen_LMI_network(broker=gen_broker())

    logger.debug("Successfully generated the LMI network.")


def test_run_LMI_network(caplog):
    """Just tests that we can successfully run the LMI network."""

    caplog.set_level(logging.DEBUG)
    logger.debug("Trying to run the LMI network...")

    picture: str = "Schrodinger"
    mode: str = "Classical"

    df, network = run_LMI_network(
        picture=picture,
        mode=mode,
        broker=gen_broker(),
    )

    logger.debug("Successfully ran the LMI network.")
