from workflow.simulation.data import Data
from workflow.simulation.graph import DirectedEdge
from workflow.simulation.resources.classical_device import ClassicalDevice

from workflow.simulation.Process_Library.PDS_Comp import *
from workflow.simulation.Process_Library.LUCJ_Comp import *
from workflow.simulation.Process_Library.PDS_dtypes import *
from workflow.simulation.broker import Broker
from workflow.simulation.devices.quantum_devices import *

import pytest
import itertools


def gen_broker():
    supercomputer = ClassicalDevice(
        device_name="Supercomputer",
        processor_type="CPU",
        RAM=100 * 10**9,
        properties={"Cores": 15, "Clock Speed": 3 * 10**9},
    )

    HPC = ClassicalDevice(
        device_name="Boeing HPC Rigel: Node 0",
        processor_type="CPU",
        RAM=242 * 10**9,
        properties={"Cores": 64, "Clock Speed": int(2.8 * 10**9)},
    )

    broker = Broker(
        classical_devices=[supercomputer, HPC],
        quantum_devices=[
            IBM_Boston(),
            IBM_Miami(),
            IBM_Fez(),
            IBM_Kingston(),
            IBM_Pittsburgh(),
            IBM_Marrakesh(),
        ],
    )
    return broker


def get_index(node, selection_nodes):
    for idx in range(len(selection_nodes)):
        if node in selection_nodes[idx]:
            return idx
    return -1


def test_run_LUCJ_sqd():
    df, network = run_LUCJ_comp_network(
        basis_length_slab=13,  # what does this mean in the PDS context
        basis_length_react=13,  # what does this mean in the PDS context
        slab_species="Mg",  # substrate material.  Is this what the slab is made of?
        reactant_species="H2O",  # reactant
        num_images=1,  # why images?  Why?
        hf_iterations=1,
        active_space_method="IBO",  # Ben L.
        gse_method="SQD",
        encoding_method="JW",  # proxy for now get from ben L. or paper EF-LUCJ EF reduces qubit count not depth "JW"
        sqd_iterations=1,
        sqd_bitstrings_per_subspace=5e3,
        broker=gen_broker(),  # gets resource set from broker
    )

    assert len(df.columns) == 13
    assert df.shape[0] > 0
