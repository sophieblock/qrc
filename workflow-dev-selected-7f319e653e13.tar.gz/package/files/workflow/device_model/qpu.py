"""Quantum Processing Unit (QPU) device implementation.

This module provides a concrete Device implementation for quantum
hardware, supporting various quantum computing architectures:
Superconducting, Trapped Ion, Neutral Atom, Photonic, and Annealer.


Authors:
    Sophie Block (sophie.block@boeing.com)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, FrozenSet, Mapping, Optional, Tuple

from .architectures import (
    Architecture,
    ArchitectureProfile,
    ErrorSchema,
    TimingSchema,
    get_architecture_profile,
    get_standard_gate_set,
)
from .base import Capability, Cost, Device, Limits, OpSig

if TYPE_CHECKING:
    from workflow.core.ir import CallSite


# Standard quantum operations
QUANTUM_OPS: FrozenSet[str] = frozenset(
    {
        # Single-qubit gates
        "I",
        "X",
        "Y",
        "Z",
        "H",
        "S",
        "Sdg",
        "T",
        "Tdg",
        "SX",
        "SXdg",
        "RX",
        "RY",
        "RZ",
        "U1",
        "U2",
        "U3",
        "P",
        # Two-qubit gates
        "CX",
        "CNOT",
        "CY",
        "CZ",
        "CH",
        "SWAP",
        "ISWAP",
        "ECR",
        "CRX",
        "CRY",
        "CRZ",
        "CP",
        "RXX",
        "RYY",
        "RZZ",
        "XX",
        # Three-qubit gates
        "CCX",
        "CCNOT",
        "TOFFOLI",
        "CSWAP",
        "FREDKIN",
        # Measurement
        "MEASURE",
        "RESET",
        # Barrier (for circuit structure)
        "BARRIER",
    }
)

# Quantum data types (qubit representations)
QUANTUM_DTYPES: FrozenSet[str] = frozenset(
    {
        "qubit",
        "cbit",  # Classical bit for measurement results
        "qreg",  # Quantum register
        "creg",  # Classical register
    }
)


@dataclass(frozen=True)
class QPUDevice:
    """A Quantum Processing Unit device.

    Attributes:
        name: Device identifier (e.g., "ibm_fez")
        arch: Quantum architecture type
        n_qubits: Number of physical qubits
        profile: Architecture profile with timing/error characteristics
        connectivity: Connectivity pattern ("all-to-all", "linear", "grid", "heavy-hex")
        native_gates: Set of natively supported gates (overrides profile if provided)
    """

    name: str
    arch: Architecture
    n_qubits: int
    profile: Optional[ArchitectureProfile] = None
    connectivity: str = "heavy-hex"
    native_gates: Optional[FrozenSet[str]] = None

    def __post_init__(self) -> None:
        # Ensure profile is set if not provided
        if self.profile is None:
            object.__setattr__(self, "profile", get_architecture_profile(self.arch))

    @property
    def cap(self) -> Capability:
        """QPU capabilities."""
        gate_set = self.native_gates or (
            self.profile.gate_set if self.profile else get_standard_gate_set(self.arch)
        )
        return Capability(
            ops=gate_set | {"MEASURE", "RESET", "BARRIER"},
            dtypes=QUANTUM_DTYPES,
            max_shape=(self.n_qubits,),  # Max shape is qubit count
        )

    @property
    def lim(self) -> Limits:
        """QPU resource limits."""
        return Limits(
            memory_bytes=None,  # Not applicable for quantum
            parallel_units=self.n_qubits,
            bandwidth_Bps=None,  # Not applicable
        )

    def can_execute(self, op_sig: OpSig) -> bool:
        """Check if QPU supports the operation.

        For quantum devices, we check:
        1. Operation is a valid quantum gate/measurement
        2. Number of qubits doesn't exceed device capacity
        """
        cap = self.cap
        # Check operation name (case-insensitive for gate names)
        if op_sig.name.upper() not in {op.upper() for op in cap.ops}:
            return False
        # Check qubit count
        if op_sig.n_qubits is not None and op_sig.n_qubits > self.n_qubits:
            return False
        return True

    def estimate(
        self,
        op_sig: OpSig,
        shape: Tuple[int, ...],
        meta: Mapping[str, Any],
    ) -> Cost:
        """Estimate cost for a quantum operation.

        Uses the architecture profile for timing and error estimation.
        """
        profile = self.profile or get_architecture_profile(self.arch)
        timing = profile.timing
        errors = profile.errors

        # Determine gate type and timing
        op_upper = op_sig.name.upper()
        n_qubits_gate = op_sig.n_qubits or 1

        # Determine gate duration and error rate
        if n_qubits_gate == 1:
            duration_ns = timing.single_qubit_gate_ns
            gate_error = errors.single_qubit_error
        elif n_qubits_gate == 2:
            duration_ns = timing.two_qubit_gate_ns
            gate_error = errors.two_qubit_error
        else:
            # Multi-qubit gates (3+ qubits) require decomposition into 2-qubit gates.
            # This is a simplified linear estimate; actual decomposition depends on
            # the specific gate and connectivity. For example:
            # - Toffoli (CCX) typically decomposes to ~6-15 two-qubit gates
            # - Multi-controlled gates scale roughly as O(n) 2-qubit gates
            # This heuristic uses 2*n_qubits as a reasonable lower bound.
            # For accurate estimates, provide a custom decomposition or use a
            # circuit optimizer to get actual gate counts.
            n_two_qubit_gates = n_qubits_gate * 2  # Heuristic approximation
            duration_ns = timing.two_qubit_gate_ns * n_two_qubit_gates
            # Error accumulates multiplicatively
            gate_error = 1 - (1 - errors.two_qubit_error) ** n_two_qubit_gates

        # Handle measurement
        if op_upper in {"MEASURE", "RESET"}:
            duration_ns = (
                timing.readout_ns if op_upper == "MEASURE" else timing.reset_ns
            )
            gate_error = errors.readout_error if op_upper == "MEASURE" else 0.0

        latency_s = duration_ns * 1e-9

        # Fidelity is 1 - error
        fidelity = 1.0 - gate_error

        # Number of shots (from meta or default)
        shots = meta.get("shots", 1024)

        # Cloud QPU cost estimate (vendor-agnostic default: ~$0.0003 per shot)
        # Actual pricing varies by vendor and should be overridden via meta or device config
        dollars_per_shot = meta.get("dollars_per_shot", 0.0003)
        dollars = shots * dollars_per_shot

        # Energy is negligible for individual gates (milliwatts)
        # but significant for cooling (included in cloud cost)
        energy_j = 0.0

        return Cost(
            latency_s=latency_s,
            dollars=dollars,
            energy_J=energy_j,
            fidelity=fidelity,
            notes={
                "shots": shots,
                "gate_error": gate_error,
                "duration_ns": duration_ns,
                "arch": self.arch.value,
            },
        )

    def emit(self, ir_node: "CallSite", target: str) -> Any:
        """Emit target-specific code.

        Args:
            ir_node: IR node to emit
            target: Target format ("openqasm" or "qir")

        Returns:
            Target-specific representation
        """
        if target == "openqasm":
            # Return OpenQASM 3.0 style representation
            gate = ir_node.op_type.lower()
            params = ir_node.params
            qubits = params.get("qubits", [0])
            if isinstance(qubits, int):
                qubits = [qubits]
            qubit_str = ", ".join(f"q[{q}]" for q in qubits)

            # Handle parametric gates
            if gate in {"rx", "ry", "rz", "p", "u1"}:
                angle = params.get("angle", 0.0)
                return f"{gate}({angle}) {qubit_str};"
            else:
                return f"{gate} {qubit_str};"

        elif target == "qir":
            # Return QIR-style representation (placeholder)
            return {
                "type": "qir_instruction",
                "gate": ir_node.op_type,
                "params": dict(ir_node.params),
                "arch": self.arch.value,
            }
        else:
            raise ValueError(f"Unsupported target: {target}")


# Re-export Architecture from architectures module
__all__ = [
    "QPUDevice",
    "Architecture",
    "QUANTUM_OPS",
    "QUANTUM_DTYPES",
    "make_superconducting_qpu",
    "make_trapped_ion_qpu",
    "make_neutral_atom_qpu",
]


# Convenience factories for architecture-based QPU configurations (vendor-agnostic)
def make_superconducting_qpu(
    name: str = "superconducting_qpu",
    n_qubits: int = 127,
    gate_set: Optional[FrozenSet[str]] = None,
    connectivity: str = "heavy-hex",
) -> QPUDevice:
    """Create a superconducting QPU with typical characteristics.

    This factory creates a vendor-agnostic superconducting QPU with
    reasonable defaults. Use the device registry or vendor loaders
    for specific hardware configurations.

    Args:
        name: Device identifier
        n_qubits: Number of qubits
        gate_set: Native gate set (default: architecture standard)
        connectivity: Connectivity pattern (default: "heavy-hex")

    Returns:
        Configured QPUDevice
    """
    from .architectures import SUPERCONDUCTING_PROFILE, SUPERCONDUCTING_GATE_SET

    return QPUDevice(
        name=name,
        arch=Architecture.SUPERCONDUCTING,
        n_qubits=n_qubits,
        profile=SUPERCONDUCTING_PROFILE,
        connectivity=connectivity,
        native_gates=gate_set or SUPERCONDUCTING_GATE_SET,
    )


def make_trapped_ion_qpu(
    name: str = "trapped_ion_qpu",
    n_qubits: int = 32,
    gate_set: Optional[FrozenSet[str]] = None,
) -> QPUDevice:
    """Create a trapped ion QPU with typical characteristics.

    Args:
        name: Device identifier
        n_qubits: Number of qubits

    Returns:
        Configured QPUDevice
    """
    from .architectures import TRAPPED_ION_GATE_SET, TRAPPED_ION_PROFILE

    return QPUDevice(
        name=name,
        arch=Architecture.TRAPPED_ION,
        n_qubits=n_qubits,
        profile=TRAPPED_ION_PROFILE,
        connectivity="all-to-all",
        native_gates=gate_set or TRAPPED_ION_GATE_SET,
    )


def make_neutral_atom_qpu(
    name: str = "neutral_atom_qpu",
    n_qubits: int = 256,
    gate_set: Optional[FrozenSet[str]] = None,
) -> QPUDevice:
    """Create a neutral atom QPU with typical characteristics.

    Args:
        name: Device identifier
        n_qubits: Number of qubits (atoms)

    Returns:
        Configured QPUDevice
    """
    from .architectures import NEUTRAL_ATOM_PROFILE, NEUTRAL_ATOM_GATE_SET

    return QPUDevice(
        name=name,
        arch=Architecture.NEUTRAL_ATOM,
        n_qubits=n_qubits,
        profile=NEUTRAL_ATOM_PROFILE,
        connectivity="grid",
        native_gates=gate_set or NEUTRAL_ATOM_GATE_SET,
    )


# Backward-compatible aliases (deprecated - prefer architecture-based names)
def make_ibm_qpu(
    name: str = "ibm_qpu",
    n_qubits: int = 127,
    gate_set: Optional[FrozenSet[str]] = None,
) -> QPUDevice:
    """Create an IBM-style superconducting QPU.

    DEPRECATED: Use make_superconducting_qpu() for vendor-agnostic code.
    For actual IBM device configuration, use the vendor loader.
    """
    return make_superconducting_qpu(name=name, n_qubits=n_qubits, gate_set=gate_set)


def make_ionq_qpu(
    name: str = "ionq_qpu",
    n_qubits: int = 32,
) -> QPUDevice:
    """Create an IonQ-style trapped ion QPU.

    DEPRECATED: Use make_trapped_ion_qpu() for vendor-agnostic code.
    For actual IonQ device configuration, use the vendor loader.
    """
    return make_trapped_ion_qpu(name=name, n_qubits=n_qubits)
