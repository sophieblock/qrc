"""IBM Quantum device loader

This module provides functions to load IBM Quantum device configurations
from CSV files or the Qiskit Runtime Service. It wraps the existing
workflow/simulation/devices/ibm_calibration.py functionality and
returns QPUDevice instances.

Usage:
    from workflow.device_model.loaders.ibm import load_ibm_device

    # Load from CSV data
    fez = load_ibm_device("ibm_fez")

    # Load with custom gate set
    custom_qpu = load_ibm_device("ibm_fez", gate_set=("CZ", "I", "RZ", "SX", "X"))

Authors:
    Sophie Block (sophie.block@boeing.com)
"""

from __future__ import annotations

from pathlib import Path
from typing import FrozenSet, Optional, Tuple

from ..qpu import QPUDevice
from ..architectures import (
    Architecture,
    ArchitectureProfile,
    TimingSchema,
    ErrorSchema,
    SUPERCONDUCTING_GATE_SET,
)

# Default IBM gate sets
IBM_STANDARD_GATE_SET: FrozenSet[str] = frozenset({"CZ", "I", "RX", "RZ", "RZZ", "SX", "X"})
IBM_CZ_GATE_SET: FrozenSet[str] = frozenset({"CZ", "I", "RX", "RZ", "SX", "X"})

# Known IBM device configurations (static fallbacks)
_IBM_DEVICES = {
    "ibm_boston": {"n_qubits": 156, "gate_set": IBM_STANDARD_GATE_SET},
    "ibm_miami": {"n_qubits": 120, "gate_set": IBM_CZ_GATE_SET},
    "ibm_fez": {"n_qubits": 156, "gate_set": IBM_STANDARD_GATE_SET},
    "ibm_kingston": {"n_qubits": 156, "gate_set": IBM_STANDARD_GATE_SET},
    "ibm_pittsburgh": {"n_qubits": 156, "gate_set": IBM_STANDARD_GATE_SET},
    "ibm_marrakesh": {"n_qubits": 156, "gate_set": IBM_STANDARD_GATE_SET},
}


def load_ibm_device(
    device_name: str,
    *,
    gate_set: Optional[Tuple[str, ...]] = None,
    use_calibration_data: bool = True,
) -> QPUDevice:
    """Load an IBM Quantum device as a QPUDevice.

    This function attempts to load device calibration data from the
    existing simulation/devices infrastructure. If calibration data
    is not available, it falls back to typical IBM device characteristics.

    Args:
        device_name: IBM device name (e.g., "ibm_fez")
        gate_set: Override native gate set (tuple of gate names)
        use_calibration_data: If True, try to load from CSV files

    Returns:
        Configured QPUDevice for the IBM device

    Example:
        >>> qpu = load_ibm_device("ibm_fez")
        >>> qpu.n_qubits
        127
    """
    # Normalize device name
    device_name_lower = device_name.lower().replace("-", "_")

    # Get known device info or use defaults
    device_info = _IBM_DEVICES.get(
        device_name_lower,
        {
            "n_qubits": 127,
            "gate_set": IBM_STANDARD_GATE_SET,
        },
    )

    n_qubits = device_info["n_qubits"]
    native_gates = frozenset(gate_set) if gate_set else device_info["gate_set"]

    # Build timing/error profiles
    # These are typical IBM superconducting values
    timing = TimingSchema(
        t1_us=100.0,
        t2_us=80.0,
        single_qubit_gate_ns=20.0,
        two_qubit_gate_ns=200.0,
        readout_ns=500.0,
        reset_ns=1000.0,
    )

    errors = ErrorSchema(
        single_qubit_error=1e-4,
        two_qubit_error=1e-3,
        readout_error=1e-2,
        idle_error_per_us=1e-5,
    )

    # Try to load calibration data from existing infrastructure
    if use_calibration_data:
        try:
            timing, errors = _load_calibration_from_csv(device_name_lower)
        except Exception:
            # Fall back to defaults if calibration data not available
            pass

    profile = ArchitectureProfile(
        arch=Architecture.SUPERCONDUCTING,
        gate_set=native_gates,
        timing=timing,
        errors=errors,
        connectivity="heavy-hex",
    )

    return QPUDevice(
        name=device_name,
        arch=Architecture.SUPERCONDUCTING,
        n_qubits=n_qubits,
        profile=profile,
        connectivity="heavy-hex",
        native_gates=native_gates,
    )


def _load_calibration_from_csv(device_name: str) -> Tuple[TimingSchema, ErrorSchema]:
    """Load timing and error data from existing CSV infrastructure.

    This function interfaces with the existing IBM device parser
    to extract calibration data.

    Note: This is a placeholder for future implementation. Currently
    returns default values as the CSV calibration extraction requires
    additional work to parse the connectivity graph data.
    """
    # Try to import and use existing parser
    try:
        from workflow.simulation.devices.ibm_calibration import LoadQuantumDeviceData

        csv_name = f"{device_name}.csv"
        loader = LoadQuantumDeviceData(csv_name)

        # The existing parser provides connectivity graph with node/edge data
        # We could extract timing/error info from there
        # For now, return defaults (parser integration requires more work)
        # TODO: Parse timing/error data from the connectivity graph nodes/edges
        raise NotImplementedError(
            f"CSV calibration extraction for {device_name} not yet implemented. "
            "Using default superconducting values."
        )

    except ImportError:
        raise ImportError("Could not import IBM device parser")


def list_ibm_devices() -> list[str]:
    """List known IBM device names."""
    return list(_IBM_DEVICES.keys())
