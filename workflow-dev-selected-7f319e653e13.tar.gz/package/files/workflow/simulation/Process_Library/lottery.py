import os
from typing import List
from types import NoneType
import numpy as np
import math
import functools
import random
from qiskit import qpy

from workflow.simulation.data import Data
from workflow.simulation.process import ClassicalProcess, QuantumProcess, selection
from workflow.simulation.graph import Node, Network, DirectedEdge
from workflow.simulation.utilities import compute_resources
from workflow.simulation.resources.classical_device import ClassicalResource
from workflow.simulation.resources.quantum_device import QuantumResource


def matching_ticket(ticket1: tuple, ticket2: tuple):
    if ticket1[-1] == ticket2[-1] and sorted(ticket1[:-1]) == sorted(ticket2[:-1]):
        return True
    return False


def generate_ticket():
    ticket = random.sample(range(1, 31), 5) + random.sample(range(1, 21), 1)
    return tuple(ticket)


class DrawTicket(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        description = "Draw a lottery ticket"
        label = "Draw Ticket"

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = []

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=64 * 6,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": tuple, "Usage": "Lottery Ticket"},
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = generate_ticket()

    def generate_output(self) -> list[Data]:
        return (Data(data=self.result, properties={"Usage": "Lottery Ticket"}),)


class CheckDuplicates(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            self.input_data["Lottery Tickets"] = []
            for data in inputs:
                if data.properties["Usage"] == "Lottery Ticket":
                    self.input_data["Lottery Tickets"].append(data.data)
                else:
                    self.input_data[data.properties["Usage"]] = data.data

        description = "Check lottery draws for duplicates. Redraw if necessary."
        label = "Check Duplicates"

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": tuple, "Usage": "Lottery Ticket"},
                {"Data Type": tuple, "Usage": "Lottery Ticket"},
                {"Data Type": int, "Usage": "Remaining Draws"},
            ],
            [
                {"Data Type": list, "Usage": "Current Tickets"},
                {"Data Type": tuple, "Usage": "Lottery Ticket"},
                {"Data Type": int, "Usage": "Remaining Draws"},
            ],
        ]

    def set_required_resources(self):
        if "Current Tickets" in self.input_data:
            num_tickets = len(self.input_data["Current Tickets"]) + len(
                self.input_data["Lottery Tickets"]
            )
        else:
            num_tickets = len(self.input_data["Lottery Tickets"])

        self.required_resources = ClassicalResource(
            memory=64
            * 6
            * num_tickets,  # 64 bits per int, 6 ints per ticket, num_ticket tickets
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": list, "Usage": "Current Tickets"},
            {"Data Type": int, "Usage": "Remaining Draws"},
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        # Check if num tickets is correct
        return True

    @compute_resources
    def update(self):
        recent_draws = self.input_data["Lottery Tickets"]

        if "Current Tickets" in self.input_data:
            ticket = self.input_data["Lottery Tickets"][0]
            if any(
                matching_ticket(ticket, curr_ticket)
                for curr_ticket in self.input_data["Current Tickets"]
            ):
                self.result = self.input_data["Current Tickets"]
                self.remaining_draws = self.input_data["Remaining Draws"]
            else:
                self.result = (
                    self.input_data["Current Tickets"]
                    + self.input_data["Lottery Tickets"]
                )
                self.remaining_draws = self.input_data["Remaining Draws"] - 1
        else:
            ticket1, ticket2 = recent_draws
            if matching_ticket(ticket1, ticket2):
                self.result = [recent_draws[0]]
                self.remaining_draws = self.input_data["Remaining Draws"]
            else:
                self.result = recent_draws
                self.remaining_draws = self.input_data["Remaining Draws"] - 1

        if self.remaining_draws > -1:
            self.dynamic = True

    def generate_output(self) -> list[Data]:
        if self.remaining_draws > -1:
            return (
                Data(data=self.result, properties={"Usage": "Current Tickets"}),
                Data(
                    data=self.remaining_draws,
                    properties={"Usage": "Remaining Draws"},
                ),
            )
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Current Tickets", "Completed": True},
                ),
            )

    def extend_network(self) -> Network:

        draw_ticket = Node(process_model=DrawTicket)
        check_duplicate = Node(process_model=CheckDuplicates)

        draw_ticket.extend(check_duplicate)

        return Network(
            nodes=[draw_ticket, check_duplicate],
            input_nodes=[draw_ticket, check_duplicate],
            output_nodes=[check_duplicate],
        )


class CheckWinning(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                if data.properties["Usage"] == "Lottery Ticket":
                    self.input_data["Current Tickets"] = [data.data]
                self.input_data[data.properties["Usage"]] = data.data

        description = "Draw a lottery ticket"
        label = "Draw Ticket"

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
            dynamic=True,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": list, "Usage": "Current Tickets", "Completed": True},
                {"Data Type": tuple, "Usage": "Winning Ticket"},
            ],
            [
                {"Data Type": tuple, "Usage": "Lottery Ticket"},
                {"Data Type": tuple, "Usage": "Winning Ticket"},
            ],
        ]

    def set_required_resources(self):
        self.required_resources = None

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": tuple, "Usage": "Lottery Ticket"},
            {"Data Type": tuple, "Usage": "Winning Ticket"},
        ]

    def compute_flop_count(self):
        return 0

    def validate_data(self) -> bool:
        if len(self.input_data["Current Tickets"]) == 1:
            return True
        else:
            return len(self.input_data["Current Tickets"]) == len(
                set(self.input_data["Current Tickets"])
            )

    @compute_resources
    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        output = [
            Data(
                data=self.input_data["Current Tickets"][idx],
                properties={"Usage": "Lottery Ticket", "Ticket No.": idx},
            )
            for idx in range(len(self.input_data["Current Tickets"]))
        ]
        return tuple(
            output
            + [
                Data(
                    data=self.input_data["Winning Ticket"],
                    properties={"Usage": "Winning Ticket"},
                )
            ]
        )

    def extend_network(self) -> Network:
        ticket_count = len(self.input_data["Current Tickets"])

        check_tickets = [
            Node(process_model=CheckTicket, ticket_num=idx)
            for idx in range(ticket_count)
        ]
        lottery_result = Node(process_model=LotteryResult, draw_num=ticket_count)

        for node in check_tickets:
            node.extend(lottery_result)

        return Network(
            nodes=check_tickets + [lottery_result],
            input_nodes=check_tickets,
            output_nodes=[lottery_result],
        )


class CheckTicket(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        ticket_num=None,
    ):
        description = "Draw a lottery ticket"
        label = "Draw Ticket"

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        self.ticket_num = ticket_num

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {
                "Data Type": tuple,
                "Usage": "Lottery Ticket",
                "Ticket No.": self.ticket_num,
            },
            {"Data Type": tuple, "Usage": "Winning Ticket"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=2 * 6 * 64,  # 2tickets x 6 ints per ticket x 64 bits per int
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": [tuple, NoneType], "Usage": "Match Result"},
        ]

    def compute_flop_count(self):
        return 1

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        ticket = self.input_data["Lottery Ticket"]
        winning_ticket = self.input_data["Winning Ticket"]
        self.result = matching_ticket(ticket, winning_ticket)

    def generate_output(self) -> list[Data]:
        if self.result:
            return (
                Data(
                    data=self.input_data["Winning Ticket"],
                    properties={"Usage": "Match Result", "Match": self.result},
                ),
            )
        else:
            return (
                Data(
                    data=None,
                    properties={"Usage": "Match Result", "Match": self.result},
                ),
            )


class LotteryResult(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        draw_num=None,
    ):
        description = "Draw a lottery ticket"
        label = "Draw Ticket"

        if inputs != None:
            self.winning_numbers = None
            for data in inputs:
                if isinstance(data.data, tuple):
                    self.winning_numbers = data.data

        self.draw_num = draw_num

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": [NoneType, tuple], "Usage": "Match Result"}
        ] * self.draw_num

    def set_required_resources(self):
        self.required_resources = None

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": str, "Usage": "Lottery Result"},
        ]

    def compute_flop_count(self):
        return 0

    def validate_data(self) -> bool:
        for data in self.inputs:
            if isinstance(data.data, tuple) and not data.properties["Match"]:
                return False
            elif isinstance(data.data, NoneType) and data.properties["Match"]:
                return False

        return True

    @compute_resources
    def update(self):
        pass

    def generate_output(self) -> list[Data]:
        if self.winning_numbers is None:
            return (
                Data(
                    data=f"Sorry, not a winner. No matching ticket in {self.draw_num} draw(s).",
                    properties={"Usage": "Lottery Result"},
                ),
            )
        else:
            return (
                Data(
                    data=f"Congratulations! Out of {self.draw_num} draw(s), {self.winning_numbers} is a winning ticket!",
                    properties={"Usage": "Lottery Result"},
                ),
            )


def generate_lottery_network(num_draws: int = 1, broker=None) -> Network:
    """Generate a basic network modelling the process of drawing lottery tickets,
    checking for duplicates and redrawing if necessary and comparing in parallel to a
    winning ticket. Can modify the behavior of the lottery drawing process in the
    generate_ticket() function.

    Args:
        num_draws (int, optional): Number of lottery draws. Defaults to 1.
        broker (Broker, optional): Network Broker to allocate devices. Defaults to None.

    Returns:
        Network: The lottery ticket Network
    """
    assert (
        num_draws > 0
    ), f"Please enter a positive integer for the number of tickets to draw."

    if num_draws < 2:
        ticket1 = Node(process_model=DrawTicket)
        check_win = Node(process_model=CheckWinning, extend_dynamic=True)
        ticket1.extend(check_win)

        return Network(
            name="lottery",
            nodes=[ticket1, check_win],
            input_nodes=[ticket1, check_win],
            output_nodes=[check_win],
            broker=broker,
        )

    else:
        ticket1 = Node(process_model=DrawTicket)
        ticket2 = Node(process_model=DrawTicket)
        check_duplicates = Node(process_model=CheckDuplicates)
        check_win = Node(process_model=CheckWinning, extend_dynamic=True)

        ticket1.extend(check_duplicates)
        ticket2.extend(check_duplicates)
        check_duplicates.extend(check_win)

        return Network(
            name="lottery",
            nodes=[ticket1, ticket2, check_duplicates, check_win],
            input_nodes=[ticket1, ticket2, check_duplicates, check_win],
            output_nodes=[check_win],
            broker=broker,
        )


def run_lottery_network(num_draws: int = 1, winning_ticket: tuple = None, broker=None):
    """Runs the lottery ticket Network.

    Args:
        num_draws (int, optional): Number of lottery draws. Defaults to 1.
        winning_ticket (tuple, optional): The winning ticket numbers as a tuple of 6 integers. Defaults to None.
        broker (Broker, optional): Network Broker to allocate devices. Defaults to None.

    Returns:
        SimulationResults, Network: Returns the SimulationResults dataframe wrapper and original Network.
    """
    network = generate_lottery_network(num_draws, broker)

    if winning_ticket is None:
        winning_ticket = generate_ticket()

    if num_draws < 2:
        starting_inputs = [
            [],
            [Data(data=winning_ticket, properties={"Usage": "Winning Ticket"})],
        ]
    else:
        starting_inputs = [
            [],
            [],
            [
                Data(data=num_draws - 2, properties={"Usage": "Remaining Draws"}),
            ],
            [Data(data=winning_ticket, properties={"Usage": "Winning Ticket"})],
        ]

    sim_result = network.run(
        starting_nodes=network.input_nodes, starting_inputs=starting_inputs
    )
    return sim_result, network
