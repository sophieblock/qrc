import math
import scipy
import scipy.sparse
import scipy.sparse.linalg
import copy
import functools
import random
import itertools as it
import numpy as np
from typing import List
from qiskit import qpy
from scipy.integrate import solve_ivp

from workflow.simulation.data import Data
from workflow.simulation.process import ClassicalProcess, QuantumProcess, selection
from workflow.simulation.graph import Node, Network, DirectedEdge
from workflow.simulation.utilities import compute_resources
from workflow.simulation.resources.classical_device import ClassicalResource
from workflow.simulation.resources.quantum_device import QuantumResource
from workflow.simulation.quantum import QuantumCircuit
from workflow.simulation.Process_Library.PDS_dtypes import (
    FermionicHam,
    Geometry,
    HFBasisSet,
    HFIntegral,
    HFMatrix,
    HFMolOrbitals,
    SingleRefWF,
    ASMolOrbitals,
    MultiRefWF,
    ActiveSpace,
    FermionicHam,
    SpinHam,
    DFHam,
    SQDParams,
    SQDCorrections,
    SQDSamples,
    SQDSubspace,
    SQDDiagResults,
    VQEParams,
    VQEAnsatz,
    ActivationEnergies,
    PCurve,
    MPO,
    QubitizedHam,
    MPS,
    GSE,
)

from workflow.simulation.quantum_gates import X, H, CZPow, CX, RX, RZ

# perhaps we should only keep
# run_LUCJ_comp_network, LUCJ_SelectMaterial, LUCJ_SelectReactant, LUCJ_DefineReactions, LUCJ_ComputeReactantGeom, LUCJ_ComputeProductGeom, LUCJ_NudgedElasticBand, LUCJ_HFSelectBasis, LUCJ_HFComputeHIntegral, LUCJ_HFComputeJIntegral, LUCJ_HFComputeKIntegral, LUCJ_HFComputeSIntegral, LUCJ_HFComputeDensityMat, LUCJ_HFComputeFockMat, LUCJ_HFSolveHFREqns, LUCJ_HFCheckConvergence, LUCJ_ComputeSingleRefWF, LUCJ_ComputeFermionicHam, LUCJ_ActiveSpaceDD, LUCJ_ActiveSpaceAVAS, LUCJ_ActiveSpaceIAO, LUCJ_ActiveSpaceIBO, LUCJ_ComputeASHamiltonian, LUCJ_ComputeMultiRefWF, LUCJ_DFEncoding, LUCJ_SCBKMapping, LUCJ_JWMapping, LUCJ_BKMapping, LUCJ_SQDPrepareCircuit, LUCJ_SQDSampleCircuit, LUCJ_SQDPartitionSubspace, LUCJ_SQDDiagonalize, LUCJ_SQDCheckConvergence, LUCJ_SQDConfigRecovery, LUCJ_SQDOptimizeParams, LUCJ_ComputeActivationEnergies, LUCJ_MKM

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LUCJ_PATH = os.path.join(BASE_DIR, "LUCJ")


proc_rate_hz = 2.8e9
basis_length = 110
basis_length_instance = 70
basis_length_instance_tot = 375
near_one = 1.0
near_small = 0.0075
near_mo_one_atom = 6
duration = 5.324e6


class LUCJ_SelectMaterial(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        description = "Select slab material for testing"
        label = "Select Material"

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": str, "Usage": "Material"},
            {"Data Type": int, "Usage": "Number of Sites"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": str, "Usage": "Material Selection"},
            {"Data Type": int, "Usage": "Number of Sites"},
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = self.input_data["Material"]

    def generate_output(self) -> list[Data]:
        return (
            Data(data=self.result, properties={"Usage": "Material Selection"}),
            Data(
                data=self.input_data["Number of Sites"],
                properties={"Usage": "Number of Sites", "Material": "Slab"},
            ),
        )


class LUCJ_SelectReactant(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        description = "Select reactant to interact with slab material"
        label = "Select Reactant"

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            description=description,
            label=label,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": str, "Usage": "Reactant"},
            {"Data Type": int, "Usage": "Number of Sites"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": str, "Usage": "Reactant Selection"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = self.input_data["Reactant"]

    def generate_output(self) -> list[Data]:
        return (
            Data(data=self.result, properties={"Usage": "Reactant Selection"}),
            Data(
                data=self.input_data["Number of Sites"],
                properties={"Usage": "Number of Sites", "Material": "Reactant"},
            ),
        )


class LUCJ_DefineReactions(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": str, "Usage": "Material Selection"},
            {"Data Type": str, "Usage": "Reactant Selection"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": list, "Usage": "Set of Reactions"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = [
            "H20 Adsorption",
            "H2 Evolution",
            "OH Desorption",
            "Mg Dissolution",
        ]

    def generate_output(self) -> list[Data]:
        return (Data(data=self.result, properties={"Usage": "Set of Reactions"}),)


class LUCJ_ComputeReactantGeom(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                if data.properties["Usage"] == "Number of Sites":
                    self.input_data[data.properties["Material"]] = data.data
                else:
                    self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": str, "Usage": "Material Selection"},
            {"Data Type": int, "Usage": "Number of Sites", "Material": "Slab"},
            {"Data Type": int, "Usage": "Number of Sites", "Material": "Reactant"},
            {"Data Type": str, "Usage": "Reactant Selection"},
            {"Data Type": list, "Usage": "Set of Reactions"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=240 * 1e9,
            num_cores=64,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": Geometry, "Usage": "Reactant Geometry"}]

    def compute_flop_count(self):
        basis_length_subst = self.input_data["Slab"]
        basis_length_react = self.input_data["Reactant"]
        slab_species = self.input_data["Material Selection"]
        reactant_species = self.input_data["Reactant Selection"]
        basis_length = basis_length_subst + basis_length_react
        num_reactions = len(self.input_data["Set of Reactions"])
        return (
            basis_length**3
            * num_reactions
            * basis_length_instance
            * 60
            * proc_rate_hz
            / duration
        )  # RJM ?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        basis_length_subst = self.input_data["Slab"]
        basis_length_react = self.input_data["Reactant"]
        slab_species = self.input_data["Material Selection"]
        reactant_species = self.input_data["Reactant Selection"]
        basis_length = basis_length_subst + basis_length_react  # RJM What are 6 and 7?
        self.result = Geometry(
            slab_material=self.input_data["Material Selection"],
            reactant=self.input_data["Reactant Selection"],
            basis_length=basis_length_subst + basis_length_react,
        )

    def generate_output(self) -> list[Data]:
        return (Data(data=self.result, properties={"Usage": "Reactant Geometry"}),)


class LUCJ_ComputeProductGeom(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                if data.properties["Usage"] == "Number of Sites":
                    self.input_data[data.properties["Material"]] = data.data
                else:
                    self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": str, "Usage": "Material Selection"},
            {"Data Type": int, "Usage": "Number of Sites", "Material": "Slab"},
            {"Data Type": int, "Usage": "Number of Sites", "Material": "Reactant"},
            {"Data Type": str, "Usage": "Reactant Selection"},
            {"Data Type": list, "Usage": "Set of Reactions"},
            {"Data Type": Geometry, "Usage": "Reactant Geometry"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=240 * 1e9,
            num_cores=64,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": Geometry, "Usage": "Product Geometry"}]

    def compute_flop_count(self):
        basis_length_subst = self.input_data["Slab"]
        basis_length_react = self.input_data["Reactant"]
        slab_species = self.input_data["Material Selection"]
        reactant_species = self.input_data["Reactant Selection"]
        basis_length = basis_length_subst + basis_length_react  # RJM What are 6 and 7?
        num_reactions = len(self.input_data["Set of Reactions"])
        return (
            basis_length**3
            * num_reactions
            * basis_length_instance
            * 60
            * proc_rate_hz
            / duration
        )  # RJM

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        basis_length_subst = self.input_data["Slab"]
        basis_length_react = self.input_data["Reactant"]
        slab_species = self.input_data["Material Selection"]
        reactant_species = self.input_data["Reactant Selection"]
        basis_length = basis_length_subst + 7 * basis_length_react
        self.result = Geometry(
            slab_material=self.input_data["Material Selection"],
            reactant=self.input_data["Reactant Selection"],
            basis_length=basis_length_subst + basis_length_react,
        )

    def generate_output(self) -> list[Data]:
        return (Data(data=self.result, properties={"Usage": "Product Geometry"}),)


class LUCJ_NudgedElasticBand(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": list, "Usage": "Set of Reactions"},
            {"Data Type": int, "Usage": "Number of Images"},
            {"Data Type": Geometry, "Usage": "Reactant Geometry"},
            {"Data Type": Geometry, "Usage": "Product Geometry"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=240 * 10**9,
            num_cores=64,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": Geometry, "Usage": "Transition Geometry"}
        ]

    def compute_flop_count(self):
        geometry: Geometry = self.input_data["Product Geometry"]
        reactions = self.input_data["Set of Reactions"]
        basis_length = geometry.basis_length
        num_reactions = len(reactions)
        num_images = self.input_data["Number of Images"]
        return (
            basis_length**3
            * num_reactions
            * num_images
            * basis_length_instance_tot  # RJM What are these numbers?
            * 60
            * proc_rate_hz
            / 5.324e7
        )

    def validate_data(self) -> bool:
        conditions = (
            self.__same_material(),
            self.__same_reactant(),
            self.__same_site_count(),
        )
        return all(conditions)

    def __same_material(self):
        reactant_geom: Geometry = self.input_data["Reactant Geometry"]
        product_geom: Geometry = self.input_data["Product Geometry"]

        return reactant_geom.slab_material == product_geom.slab_material

    def __same_reactant(self):
        reactant_geom: Geometry = self.input_data["Reactant Geometry"]
        product_geom: Geometry = self.input_data["Product Geometry"]

        return reactant_geom.reactant == product_geom.reactant

    def __same_site_count(self):
        reactant_geom: Geometry = self.input_data["Reactant Geometry"]
        product_geom: Geometry = self.input_data["Product Geometry"]

        return reactant_geom.basis_length == product_geom.basis_length

    @compute_resources
    def update(self):
        num_images = self.input_data["Number of Images"]
        reactant_geom: Geometry = self.input_data["Reactant Geometry"]
        slab_material = reactant_geom.slab_material
        reactant = reactant_geom.reactant
        basis_length = reactant_geom.basis_length

        self.result = [
            Geometry(
                slab_material=slab_material,
                reactant=reactant,
                basis_length=basis_length,
            )
            for _ in range(num_images)
        ]

    def generate_output(self) -> list[Data]:
        num_images = self.input_data["Number of Images"]
        return tuple(
            Data(
                data=self.result[idx],
                properties={"Usage": "Transition Geometry", "Image": idx + 1},
            )
            for idx in range(num_images)
        )


class LUCJ_HFSelectBasis(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        image_num=None,
    ):
        self.image_num = image_num
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.image_num is None:
            self.expected_input_properties = [
                {"Data Type": Geometry, "Usage": "Transition Geometry"},
                {"Data Type": list, "Usage": "Set of Reactions"},
            ]
        else:
            assert isinstance(
                self.image_num, (int, float)
            ), f"image_num parameter must be an integer"
            self.expected_input_properties = [
                {
                    "Data Type": Geometry,
                    "Usage": "Transition Geometry",
                    "Image": int(self.image_num),
                },
                {"Data Type": list, "Usage": "Set of Reactions"},
            ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": HFBasisSet, "Usage": "Basis Functions"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = HFBasisSet()

    def generate_output(self) -> list[Data]:
        if self.image_num is None:
            return (Data(data=self.result, properties={"Usage": "Basis Functions"}),)
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Basis Functions", "Image": self.image_num},
                ),
            )


class LUCJ_HFComputeHIntegral(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        image_num=None,
    ):
        self.image_num = image_num
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.image_num is None:
            self.expected_input_properties = [
                {"Data Type": Geometry, "Usage": "Transition Geometry"},
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]
        else:
            assert isinstance(
                self.image_num, (int, float)
            ), f"image_num parameter must be an integer"
            self.expected_input_properties = [
                {
                    "Data Type": Geometry,
                    "Usage": "Transition Geometry",
                    "Image": int(self.image_num),
                },
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]

    def set_required_resources(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.required_resources = ClassicalResource(
            memory=basis_length**2 * 2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": HFIntegral, "Usage": "Core Integral"}]

    def compute_flop_count(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        return (
            basis_length**2 * 70 * proc_rate_hz / basis_length**2
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.result = HFIntegral(type="Core", basis_length=basis_length)

    def generate_output(self) -> list[Data]:
        if self.image_num is None:
            return (Data(data=self.result, properties={"Usage": "Core Integral"}),)
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Core Integral", "Image": self.image_num},
                ),
            )


class LUCJ_HFComputeJIntegral(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        image_num=None,
    ):
        self.image_num = image_num
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.image_num is None:
            self.expected_input_properties = [
                {"Data Type": Geometry, "Usage": "Transition Geometry"},
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]
        else:
            assert isinstance(
                self.image_num, (int, float)
            ), f"image_num parameter must be an integer"
            self.expected_input_properties = [
                {
                    "Data Type": Geometry,
                    "Usage": "Transition Geometry",
                    "Image": int(self.image_num),
                },
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]

    def set_required_resources(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.required_resources = ClassicalResource(
            memory=basis_length**4 * near_one,  # RJM what are these numbers?
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFIntegral, "Usage": "Coulomb Integral"}
        ]

    def compute_flop_count(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        return (
            basis_length**4 * 6 * 60 * proc_rate_hz / (basis_length**4)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.result = HFIntegral(type="Coulomb", basis_length=basis_length)

    def generate_output(self) -> list[Data]:
        if self.image_num is None:
            return (Data(data=self.result, properties={"Usage": "Coulomb Integral"}),)
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Coulomb Integral", "Image": self.image_num},
                ),
            )


class LUCJ_HFComputeKIntegral(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        image_num=None,
    ):
        self.image_num = image_num
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.image_num is None:
            self.expected_input_properties = [
                {"Data Type": Geometry, "Usage": "Transition Geometry"},
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]
        else:
            assert isinstance(
                self.image_num, (int, float)
            ), f"image_num parameter must be an integer"
            self.expected_input_properties = [
                {
                    "Data Type": Geometry,
                    "Usage": "Transition Geometry",
                    "Image": int(self.image_num),
                },
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]

    def set_required_resources(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.required_resources = ClassicalResource(
            memory=basis_length**4 * near_one,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFIntegral, "Usage": "Exchange Integral"}
        ]

    def compute_flop_count(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        return (
            basis_length**4 * near_mo_one_atom * 60 * proc_rate_hz / (basis_length**4)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.result = HFIntegral(type="Exchange", basis_length=basis_length)

    def generate_output(self) -> list[Data]:
        if self.image_num is None:
            return (Data(data=self.result, properties={"Usage": "Exchange Integral"}),)
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Exchange Integral", "Image": self.image_num},
                ),
            )


class LUCJ_HFComputeSIntegral(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        image_num=None,
    ):
        self.image_num = image_num
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.image_num is None:
            self.expected_input_properties = [
                {"Data Type": Geometry, "Usage": "Transition Geometry"},
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]
        else:
            assert isinstance(
                self.image_num, (int, float)
            ), f"image_num parameter must be an integer"
            self.expected_input_properties = [
                {
                    "Data Type": Geometry,
                    "Usage": "Transition Geometry",
                    "Image": int(self.image_num),
                },
                {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            ]

    def set_required_resources(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.required_resources = ClassicalResource(
            memory=basis_length**2 * 2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFIntegral, "Usage": "Overlap Integral"}
        ]

    def compute_flop_count(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        return (
            basis_length**2 * 70 * proc_rate_hz / basis_length**2
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        geometry = self.input_data["Transition Geometry"]
        basis_length = geometry.basis_length
        self.result = HFIntegral(type="Overlap", basis_length=basis_length)

    def generate_output(self) -> list[Data]:
        if self.image_num is None:
            return (Data(data=self.result, properties={"Usage": "Overlap Integral"}),)
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Overlap Integral", "Image": self.image_num},
                ),
            )


class LUCJ_HFComputeDensityMat(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {"Image": None}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data
                try:
                    image_num = data.properties["Image"]
                    if self.input_data["Image"] is None:
                        self.input_data["Image"] = image_num
                    assert self.input_data["Image"] == image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFBasisSet, "Usage": "Basis Functions"},
            {"Data Type": HFIntegral, "Usage": "Core Integral"},
            {"Data Type": HFIntegral, "Usage": "Coulomb Integral"},
            {"Data Type": HFIntegral, "Usage": "Exchange Integral"},
            {"Data Type": HFIntegral, "Usage": "Overlap Integral"},
        ]

    def set_required_resources(self):
        basis_length = self.input_data["Core Integral"].basis_length
        self.required_resources = ClassicalResource(
            memory=4 * basis_length**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFMatrix, "Usage": "Initial Density Matrix"}
        ]

    def compute_flop_count(self):
        basis_length = self.input_data["Core Integral"].basis_length
        return basis_length**3 * 7 * proc_rate_hz / (basis_length**3)

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        basis_length = self.input_data["Core Integral"].basis_length
        self.result = HFMatrix(
            type="Initial Density Matrix",
            dtype=np.complex128,
            num_rows=basis_length,
            num_cols=basis_length,
        )

    def generate_output(self) -> list[Data]:
        if self.input_data["Image"] is None:
            return (
                Data(data=self.result, properties={"Usage": "Initial Density Matrix"}),
            )
        else:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Initial Density Matrix",
                        "Image": self.input_data["Image"],
                    },
                ),
            )


class LUCJ_HFComputeFockMat(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": HFMatrix, "Usage": "Initial Density Matrix"},
            ],
            [
                {"Data Type": HFMatrix, "Usage": "Current Density Matrix"},
            ],
        ]

    def set_required_resources(self):
        try:
            density_matrix = self.input_data["Initial Density Matrix"]
        except:
            density_matrix = self.input_data["Current Density Matrix"]
        basis_length = density_matrix.num_rows
        self.required_resources = ClassicalResource(
            memory=basis_length**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": HFMatrix, "Usage": "Fock Matrix"}]

    def compute_flop_count(self):
        try:
            density_matrix = self.input_data["Initial Density Matrix"]
        except:
            density_matrix = self.input_data["Current Density Matrix"]
        basis_length = density_matrix.num_rows
        return (
            basis_length**4 * 60 * proc_rate_hz / (basis_length**4)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        try:
            density_mat: HFMatrix = self.input_data["Initial Density Matrix"]
        except KeyError:
            density_mat: HFMatrix = self.input_data["Current Density Matrix"]

        self.result = HFMatrix(
            type="Fock Matrix",
            dtype=np.complex128,
            num_rows=density_mat.num_rows,
            num_cols=density_mat.num_cols,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Fock Matrix",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (Data(data=self.result, properties={"Usage": "Fock Matrix"}),)


class LUCJ_HFSolveHFREqns(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMatrix, "Usage": "Fock Matrix"},
        ]

    def set_required_resources(self):
        fock_matrix = self.input_data["Fock Matrix"]
        basis_length = fock_matrix.num_rows
        self.required_resources = ClassicalResource(
            memory=6 * basis_length**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFMatrix, "Usage": "Updated Density Matrix"}
        ]

    def compute_flop_count(self):
        fock_matrix = self.input_data["Fock Matrix"]
        basis_length = fock_matrix.num_rows
        return (
            basis_length**3 * 60 * proc_rate_hz / (basis_length**3)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        fock_matrix: HFMatrix = self.input_data["Fock Matrix"]
        self.result = HFMatrix(
            type="Density Matrix",
            dtype=np.complex128,
            num_rows=fock_matrix.num_rows,
            num_cols=fock_matrix.num_cols,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Updated Density Matrix",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(data=self.result, properties={"Usage": "Updated Density Matrix"}),
            )


class LUCJ_HFCheckConvergence(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        remaining_itrs=None,
    ):
        self.remaining_itrs = 0 if remaining_itrs is None else remaining_itrs
        assert isinstance(self.remaining_itrs, int)
        if inputs != None:
            self.input_data = {"Image": None}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    if self.input_data["Image"] is None:
                        self.input_data["Image"] = image_num
                    assert self.input_data["Image"] == image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            dynamic=True if self.remaining_itrs > 0 else False,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": HFMatrix, "Usage": "Updated Density Matrix"},
                {"Data Type": HFMatrix, "Usage": "Initial Density Matrix"},
            ],
            [
                {"Data Type": HFMatrix, "Usage": "Updated Density Matrix"},
                {"Data Type": HFMatrix, "Usage": "Current Density Matrix"},
            ],
        ]

    def set_required_resources(self):
        basis_length = self.input_data["Updated Density Matrix"].num_rows
        self.required_resources = ClassicalResource(
            memory=2 * basis_length**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"}
        ]

    def compute_flop_count(self):
        basis_length = self.input_data["Updated Density Matrix"].num_rows
        return (
            basis_length**2 * near_small * 2e9 / (basis_length**2)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        if self.remaining_itrs == 0:
            basis_length = self.input_data["Updated Density Matrix"].num_rows
            self.result = HFMolOrbitals(num_orbitals=basis_length)
        else:
            self.result = self.input_data["Updated Density Matrix"]

    def generate_output(self) -> list[Data]:
        if self.remaining_itrs == 0:
            if self.input_data["Image"] is None:
                return (
                    Data(
                        data=self.result,
                        properties={"Usage": "Molecular Orbitals"},
                    ),
                )
            else:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "Molecular Orbitals",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )
        else:
            if self.input_data["Image"] is None:
                return (
                    Data(
                        data=self.result, properties={"Usage": "Current Density Matrix"}
                    ),
                )
            else:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "Current Density Matrix",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )

    def extend_network(self) -> Network:
        remaining_itrs = self.remaining_itrs - 1

        compute_fock: Node = Node(process_model=LUCJ_HFComputeFockMat)
        solve_hfr_eqns: Node = Node(process_model=LUCJ_HFSolveHFREqns)
        hf_check_convergence: Node = Node(
            process_model=LUCJ_HFCheckConvergence, remaining_itrs=remaining_itrs
        )

        compute_fock.extend(solve_hfr_eqns)
        solve_hfr_eqns.extend(hf_check_convergence)

        network = Network(
            nodes=[compute_fock, solve_hfr_eqns, hf_check_convergence],
            input_nodes=[compute_fock, hf_check_convergence],
            output_nodes=[hf_check_convergence],
        )
        return network


class LUCJ_ComputeSingleRefWF(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=(2 * num_orbitals**2 + num_orbitals) * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": SingleRefWF, "Usage": "Single Reference Wavefunction"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        return (
            num_orbitals**2 * near_small * 2e9 / (basis_length**2)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        """you recover the orbitals by diagonalizing the converged Fock matrix,
        and these orbitals (represented by their coefficients, C) then construct the density matrix
        """
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.result = SingleRefWF(num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Single Reference Wavefunction",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Single Reference Wavefunction"},
                ),
            )


@selection
class LUCJ_ComputeFermionicHam(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
            {"Data Type": HFIntegral, "Usage": "Core Integral"},
            {"Data Type": HFIntegral, "Usage": "Coulomb Integral"},
            {"Data Type": HFIntegral, "Usage": "Exchange Integral"},
            {"Data Type": HFIntegral, "Usage": "Overlap Integral"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": FermionicHam, "Usage": "Fermionic Hamiltonian"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.result = FermionicHam(active_space=False, num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Fermionic Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Fermionic Hamiltonian"},
                ),
            )


@selection
class LUCJ_ActiveSpaceDD(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=3 * num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        return (
            num_orbitals**2 * 15 * proc_rate_hz / (basis_length**2)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        num_active = min(
            12, num_orbitals
        )  # This is typically 8-14 but not greater than num_orbitals
        self.result = ASMolOrbitals(num_orbitals=num_orbitals, num_active=num_active)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Active Space Orbitals",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(data=self.result, properties={"Usage": "Active Space Orbitals"}),
            )


@selection
class LUCJ_ActiveSpaceAVAS(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=3 * num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        return num_orbitals**2 * 30 * proc_rate_hz / (basis_length**2)

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        num_active = min(
            12, num_orbitals
        )  # This is typically 8-14 but not greater than num_orbitals
        self.result = ASMolOrbitals(num_orbitals=num_orbitals, num_active=num_active)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Active Space Orbitals",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(data=self.result, properties={"Usage": "Active Space Orbitals"}),
            )


@selection
class LUCJ_ActiveSpaceIAO(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=3 * num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        return (
            num_orbitals**2 * 80 * proc_rate_hz / (basis_length**2)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        num_active = min(
            12, num_orbitals
        )  # This is typically 8-14 but not greater than num_orbitals
        self.result = ASMolOrbitals(num_orbitals=num_orbitals, num_active=num_active)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Active Space Orbitals",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(data=self.result, properties={"Usage": "Active Space Orbitals"}),
            )


@selection
class LUCJ_ActiveSpaceIBO(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": HFMolOrbitals, "Usage": "Molecular Orbitals"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=3 * num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        return (
            num_orbitals**3 * 80 * proc_rate_hz / (basis_length**2)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Molecular Orbitals"].num_orbitals
        num_active = min(
            12, num_orbitals
        )  # This is typically 8-14 but not greater than num_orbitals
        self.result = ASMolOrbitals(num_orbitals=num_orbitals, num_active=num_active)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Active Space Orbitals",
                        "Image": self.input_data["Image"],
                    },
                ),
            )
        else:
            return (
                Data(data=self.result, properties={"Usage": "Active Space Orbitals"}),
            )


@selection
class LUCJ_ComputeASHamiltonian(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data
                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"},
            {"Data Type": HFIntegral, "Usage": "Core Integral"},
            {"Data Type": HFIntegral, "Usage": "Coulomb Integral"},
            {"Data Type": HFIntegral, "Usage": "Exchange Integral"},
            {"Data Type": HFIntegral, "Usage": "Overlap Integral"},
        ]

    def set_required_resources(self):
        num_active_orbitals = self.input_data["Active Space Orbitals"].num_active
        self.required_resources = ClassicalResource(
            memory=num_active_orbitals**2 * (num_active_orbitals + 1) ** 2 * 2,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": FermionicHam, "Usage": "Active Space Fermionic Hamiltonian"}
        ]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Active Space Orbitals"].num_orbitals
        return (
            num_orbitals**4 * 15 * 60 * proc_rate_hz / (basis_length**4)
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Active Space Orbitals"].num_orbitals
        num_active = self.input_data["Active Space Orbitals"].num_active
        self.result = FermionicHam(
            active_space=True, num_orbitals=num_orbitals, num_active=num_active
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Active Space Fermionic Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Active Space Fermionic Hamiltonian"},
                ),
            )


class LUCJ_ComputeMultiRefWF(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {"Image": None}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    if self.input_data["Image"] is None:
                        self.input_data["Image"] = image_num
                    assert self.input_data["Image"] == image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": FermionicHam, "Usage": "Active Space Fermionic Hamiltonian"},
            {"Data Type": ASMolOrbitals, "Usage": "Active Space Orbitals"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Active Space Orbitals"].num_orbitals
        num_active = self.input_data["Active Space Orbitals"].num_active
        self.result = MultiRefWF(num_orbitals=num_orbitals, num_active=num_active)

    def generate_output(self) -> list[Data]:
        if self.input_data["Image"] is None:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Multi Reference Wavefunction"},
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Multi Reference Wavefunction",
                        "Image": self.input_data["Image"],
                    },
                ),
            )


### Encode Fermionic Hamiltonian to Spin
@selection
class LUCJ_DFEncoding(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {
                    "Data Type": FermionicHam,
                    "Usage": "Active Space Fermionic Hamiltonian",
                },
            ],
            [
                {"Data Type": FermionicHam, "Usage": "Fermionic Hamiltonian"},
            ],
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": DFHam, "Usage": "Double Factorized Hamiltonian"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        try:
            num_orbitals = self.input_data[
                "Active Space Fermionic Hamiltonian"
            ].num_active
        except KeyError:
            num_orbitals = self.input_data["Fermionic Hamiltonian"].num_active
        self.result = DFHam(num_orbitals=num_orbitals, num_pauli=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Double Factorized Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Double Factorized Hamiltonian"},
                ),
            )


@selection
class LUCJ_SCBKMapping(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": DFHam, "Usage": "Double Factorized Hamiltonian"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=num_orbitals**4 * np.log2(num_orbitals) * 8 / 10,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": SpinHam, "Usage": "Spin Hamiltonian"}]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        return num_orbitals**4 * np.log2(num_orbitals)

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals

        self.result = SpinHam(encoding_scheme="SCBK", num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Spin Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Spin Hamiltonian"},
                ),
            )


@selection
class LUCJ_JWMapping(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": DFHam, "Usage": "Double Factorized Hamiltonian"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=num_orbitals**5 * 8 / 10,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": SpinHam, "Usage": "Spin Hamiltonian"}]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        return num_orbitals**5

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        self.result = SpinHam(encoding_scheme="JW", num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Spin Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Spin Hamiltonian"},
                ),
            )


@selection
class LUCJ_BKMapping(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": DFHam, "Usage": "Double Factorized Hamiltonian"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        self.required_resources = ClassicalResource(
            memory=num_orbitals**4 * np.log2(num_orbitals) * 8 / 10,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": SpinHam, "Usage": "Spin Hamiltonian"}]

    def compute_flop_count(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        return num_orbitals**4 * np.log2(num_orbitals)

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Double Factorized Hamiltonian"].num_orbitals
        self.result = SpinHam(encoding_scheme="BK", num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Spin Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Spin Hamiltonian"},
                ),
            )


### DMRG (MR WF)
@selection
class LUCJ_DMRGInitializeMPS(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
            {"Data Type": int, "Usage": "Max Bond Dimension"},
        ]

    def set_required_resources(self):
        num_active = self.input_data["Multi Reference Wavefunction"].num_active
        max_bond = self.input_data["Max Bond Dimension"]
        self.required_resources = ClassicalResource(
            memory=4 * num_active * max_bond**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": MPS, "Usage": "DMRG Initial MPS"}]

    def compute_flop_count(self):
        num_active = self.input_data["Multi Reference Wavefunction"].num_active
        max_bond = self.input_data["Max Bond Dimension"]
        return num_active * max_bond**3 * near_one  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_active = self.input_data["Multi Reference Wavefunction"].num_active
        max_bond = self.input_data["Max Bond Dimension"]

        self.result = MPS(
            basis_length=num_active,
            canonicalization=None,
            current_ortho_site=0,
            max_bond=max_bond,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "DMRG Initial MPS",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "DMRG Initial MPS"},
                ),
            )


class LUCJ_DMRGCanonizeMPS(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MPS, "Usage": "DMRG Initial MPS"},
        ]

    def set_required_resources(self):
        mps: MPS = self.input_data["DMRG Initial MPS"]
        sites = mps.basis_length
        max_bond = mps.max_bond
        self.required_resources = ClassicalResource(
            memory=4 * sites * max_bond**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": MPS, "Usage": "DMRG MPS"}]

    def compute_flop_count(self):
        mps: MPS = self.input_data["DMRG Initial MPS"]
        sites = mps.basis_length
        max_bond = mps.max_bond
        return sites * max_bond**3 * near_one  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        initial_mps = self.input_data["DMRG Initial MPS"]
        self.result = MPS(
            basis_length=initial_mps.basis_length,
            canonicalization="right",
            current_ortho_site=0,
            max_bond=initial_mps.max_bond,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "DMRG MPS",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "DMRG MPS"},
                ),
            )


class LUCJ_DMRGHamiltonianMPO(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
        ]

    def set_required_resources(self):
        ham: SpinHam = self.input_data["Spin Hamiltonian"]
        sites = ham.num_orbitals
        self.required_resources = ClassicalResource(
            memory=16 * sites**5 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": MPO, "Usage": "DMRG MPO"}]

    def compute_flop_count(self):
        ham: SpinHam = self.input_data["Spin Hamiltonian"]
        sites = ham.num_orbitals
        return (
            16 * (1 + 4 * sites + 2 * sites**2) ** 3 * near_one
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Spin Hamiltonian"].num_orbitals
        self.result = MPO(basis_length=num_orbitals, max_bond=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "DMRG MPO",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "DMRG MPO"},
                ),
            )


class LUCJ_DMRGOptimizeSite(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        set_dynamic=True,
    ):

        if inputs != None:
            self.input_data = {"Image": None}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    if self.input_data["Image"] is None:
                        self.input_data["Image"] = image_num
                    assert self.input_data["Image"] == image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            dynamic=set_dynamic,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MPS, "Usage": "DMRG MPS"},
            {"Data Type": MPO, "Usage": "DMRG MPO"},
        ]

    def set_required_resources(self):
        mps: MPS = self.input_data["DMRG MPS"]
        basis_length = mps.basis_length
        max_bond = mps.max_bond
        curr_site = min(
            mps.current_ortho_site + 1, basis_length - mps.current_ortho_site
        )
        site_dim = min(max_bond, 4**curr_site)
        self.required_resources = ClassicalResource(
            memory=3 * site_dim**2 * basis_length**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": MPS, "Usage": "DMRG MPS"},
            {"Data Type": MPO, "Usage": "DMRG MPO"},
        ]

    def compute_flop_count(self):
        mps: MPS = self.input_data["DMRG MPS"]
        basis_length = mps.basis_length
        max_bond = mps.max_bond
        curr_site = min(
            mps.current_ortho_site + 1, basis_length - mps.current_ortho_site
        )
        site_dim = min(max_bond, 4**curr_site)
        return (
            (basis_length**4 * site_dim**2) * near_one / 5
        )  # RJM what are these numbers?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        current_mps = self.input_data["DMRG MPS"]
        canonicalization = current_mps.canonicalization
        curr_site = current_mps.current_ortho_site
        basis_length = current_mps.basis_length
        max_bond = current_mps.max_bond

        if canonicalization == "right":
            if curr_site < basis_length - 2:
                updated_mps = MPS(
                    basis_length=current_mps.basis_length,
                    canonicalization=canonicalization,
                    current_ortho_site=curr_site + 1,
                    max_bond=max_bond,
                )
            elif curr_site == basis_length - 2:
                updated_mps = MPS(
                    basis_length=current_mps.basis_length,
                    canonicalization="left",
                    current_ortho_site=curr_site + 1,
                    max_bond=max_bond,
                )
            else:
                raise ValueError(f"Something unexpected occured")
        elif canonicalization == "left":
            if curr_site > 1:
                updated_mps = MPS(
                    basis_length=current_mps.basis_length,
                    canonicalization=canonicalization,
                    current_ortho_site=curr_site - 1,
                    max_bond=max_bond,
                )
            elif curr_site == 1:
                updated_mps = MPS(
                    basis_length=current_mps.basis_length,
                    canonicalization="right",
                    current_ortho_site=curr_site - 1,
                    max_bond=max_bond,
                )
        else:
            raise ValueError(
                f"Expected left or right for canonicalization, but got {canonicalization} instead"
            )

        self.result = updated_mps

    def generate_output(self) -> list[Data]:
        if self.input_data["Image"] is None:
            return (
                Data(
                    data=self.input_data["DMRG MPO"],
                    properties={"Usage": "DMRG MPO"},
                ),
                Data(
                    data=self.result,
                    properties={"Usage": "DMRG MPS"},
                ),
            )

        else:
            return (
                Data(
                    data=self.input_data["DMRG MPO"],
                    properties={
                        "Usage": "DMRG MPO",
                        "Image": self.input_data["Image"],
                    },
                ),
                Data(
                    data=self.result,
                    properties={
                        "Usage": "DMRG MPS",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

    def extend_network(self) -> Node:
        current_mps = self.input_data["DMRG MPS"]
        canonicalization = current_mps.canonicalization
        curr_site = current_mps.current_ortho_site
        basis_length = current_mps.basis_length

        if canonicalization == "right" and curr_site == basis_length - 2:
            return Node(process_model=LUCJ_DMRGOptimizeSite, set_dynamic=False)
        elif canonicalization == "left" and curr_site == 1:
            return Node(process_model=LUCJ_DMRGOptimizeSite, set_dynamic=False)

        return Node(process_model=LUCJ_DMRGOptimizeSite, set_dynamic=True)


class LUCJ_DMRGCheckConvergence(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        remaining_itrs=None,
    ):
        self.remaining_itrs = 0 if remaining_itrs is None else remaining_itrs
        set_dynamic = True if self.remaining_itrs > 0 else False
        if inputs != None:
            self.input_data = {"Image": None}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    if self.input_data["Image"] is None:
                        self.input_data["Image"] = image_num
                    assert self.input_data["Image"] == image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            dynamic=set_dynamic,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MPS, "Usage": "DMRG MPS"},
            {"Data Type": MPO, "Usage": "DMRG MPO"},
        ]

    def set_required_resources(self):
        mps: MPS = self.input_data["DMRG MPS"]
        basis_length = mps.basis_length
        max_bond = mps.max_bond
        self.required_resources = ClassicalResource(
            memory=max_bond**2 * 8 + basis_length**2 * max_bond**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": MultiRefWF, "Usage": "Ground State"},
            {"Data Type": GSE, "Usage": "Ground State Energy"},
        ]

    def compute_flop_count(self):
        mps: MPS = self.input_data["DMRG MPS"]
        basis_length = mps.basis_length
        max_bond = mps.max_bond
        return (
            basis_length * max_bond**3 + basis_length**3 * max_bond**2 * 4**3
        ) * near_one  # RJM what are these numbers? ** was ^

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        basis_length = self.input_data["DMRG MPS"].basis_length
        self.ground_state = MultiRefWF(num_orbitals=basis_length)
        self.ground_state_energy = GSE(energy=None, uncertainty=None, method="DMRG")

    def generate_output(self) -> list[Data]:
        if self.remaining_itrs > 0:
            if self.input_data["Image"] is None:
                return (
                    Data(
                        data=self.input_data["DMRG MPO"],
                        properties={"Usage": "DMRG MPO"},
                    ),
                    Data(
                        data=self.result,
                        properties={"Usage": "DMRG MPS"},
                    ),
                )

            else:
                return (
                    Data(
                        data=self.input_data["DMRG MPO"],
                        properties={
                            "Usage": "DMRG MPO",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.input_data["DMRG MPS"],
                        properties={
                            "Usage": "DMRG MPS",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )
        else:
            if self.input_data["Image"] is None:
                return (
                    Data(
                        data=self.ground_state,
                        properties={"Usage": "Ground State"},
                    ),
                    Data(
                        data=self.ground_state_energy,
                        properties={"Usage": "Ground State Energy"},
                    ),
                )

            else:
                return (
                    Data(
                        data=self.ground_state,
                        properties={
                            "Usage": "Ground State",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.ground_state_energy,
                        properties={
                            "Usage": "Ground State Energy",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )

    def extend_network(self) -> Network:
        optimize_site: Node = Node(
            process_model=LUCJ_DMRGOptimizeSite, set_dynamic=True
        )
        check_convergence: Node = Node(
            process_model=LUCJ_DMRGCheckConvergence,
            extend_dynamic=True,
            remaining_itrs=self.remaining_itrs - 1,
        )

        optimize_site.extend(check_convergence)
        network = Network(
            nodes=[optimize_site, check_convergence],
            input_nodes=[optimize_site],
            output_nodes=[check_convergence],
        )
        return network


## QPE (MR WF)
class LUCJ_QPEQubitizeHam(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        basis_length=10,
    ):
        self.basis_length = basis_length
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": QubitizedHam, "Usage": "Qubitized Hamiltonian"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Spin Hamiltonian"].num_orbitals
        self.result = QubitizedHam(num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Qubitized Hamiltonian",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Qubitized Hamiltonian"},
                ),
            )


@selection
class LUCJ_QPEInitState(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        basis_length=10,
    ):
        self.basis_length = basis_length
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": QuantumCircuit, "Usage": "QPE Initial State Circuit"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["Multi Reference Wavefunction"].num_orbitals
        self.result = QuantumCircuit(
            qubit_count=num_orbitals, gate_set=None, instructions=None
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "QPE Initial State Circuit",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "QPE Initial State Circuit"},
                ),
            )


class LUCJ_QPEEvolveState(QuantumProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        basis_length=10,
    ):
        self.basis_length = basis_length
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            shots=100,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": QuantumCircuit, "Usage": "QPE Initial State Circuit"},
            {"Data Type": QubitizedHam, "Usage": "Qubitized Hamiltonian"},
            {"Data Type": int, "Usage": "Number of Ancillas"},
            {"Data Type": float, "Usage": "QPE Epsilon"},
        ]

    def set_required_resources(self):
        epsilon = self.input_data["QPE Epsilon"]
        num_orbitals = self.input_data["Qubitized Hamiltonian"].num_orbitals
        # RJM Some sort of fit.  Reference?
        if epsilon == 0.1:
            num_qubits = int(
                -4.84e2
                + 1.04e2 * num_orbitals
                - 3.43 * num_orbitals**2
                + 4.5455e-2 * num_orbitals**3
            )
            num_T = int(
                2854153.0
                - 722546.32 * num_orbitals
                + 73635.89 * num_orbitals**2
                - 1215.15 * num_orbitals**3
                + 33.95 * num_orbitals**4
            )
        elif epsilon == 0.01:
            num_qubits = int(
                -4.8474e2
                + 1.0549e2 * num_orbitals
                - 3.4881 * num_orbitals**2
                + 4.6323e-2 * num_orbitals**3
            )
            num_T = int(
                28315676.78
                - 7173131.23 * num_orbitals
                + 732128.39 * num_orbitals**2
                - 13013.88 * num_orbitals**3
                + 337.90 * num_orbitals**4
            )
        elif epsilon == 0.0016:
            num_qubits = int(
                -4.7212e2
                + 1.0429e2 * num_orbitals
                - 3.4301 * num_orbitals**2
                + 5.5455e-2 * num_orbitals**3
            )
            num_T = int(
                1.76862937e8
                - 4.4803542e7 * num_orbitals
                + 4.573241e6 * num_orbitals**2
                - 8.1247e4 * num_orbitals**3
                + 2.8e3 * num_orbitals**4  # RJM Fix this
            )
        else:
            assert False

        self.required_resources = QuantumResource(
            quantum_circuit=QuantumCircuit(qubit_count=num_qubits),
            T_gates=num_T,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": QuantumCircuit, "Usage": "QPE Circuit"}]

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        epsilon = self.input_data["QPE Epsilon"]
        num_orbitals = self.input_data["Qubitized Hamiltonian"].num_orbitals
        # rjm some sort of fit.  Reference?
        if epsilon == 0.1:
            num_qubits = int(
                -4.84e2
                + 1.04e2 * num_orbitals
                - 3.43 * num_orbitals**2
                + 4.5455e-2 * num_orbitals**3
            )
        elif epsilon == 0.01:
            num_qubits = int(
                -4.8474e2
                + 1.0549e2 * num_orbitals
                - 3.4881 * num_orbitals**2
                + 4.6323e-2 * num_orbitals**3
            )
        elif epsilon == 0.0016:
            num_qubits = int(
                -4.7212e2
                + 1.0429e2 * num_orbitals
                - 3.4301 * num_orbitals**2
                + 5.5455e-2 * num_orbitals**3
            )

        if num_qubits is None:
            num_qubits = 0
        self.result = QuantumCircuit(
            qubit_count=num_qubits, gate_set=None, instructions=None
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "QPE Circuit",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "QPE Circuit"},
                ),
            )


class LUCJ_QPEComputeGSE(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        basis_length=10,
    ):
        self.basis_length = basis_length
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": QuantumCircuit, "Usage": "QPE Circuit"},
        ]

    def set_required_resources(self):
        shots = 100
        num_qubits = self.input_data["QPE Circuit"].qubit_count
        self.required_resources = ClassicalResource(
            memory=shots * num_qubits,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": GSE, "Usage": "Ground State Energy"}]

    def compute_flop_count(self):
        shots = 100
        num_qubits = self.input_data["QPE Circuit"].qubit_count
        return shots * num_qubits + shots * np.log(shots)

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = GSE(energy=None, uncertainty=None, method="QPE")

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "Ground State Energy",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "Ground State Energy"},
                ),
            )


### SQD (MR WF)
@selection
class LUCJ_SQDPrepareCircuit(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
            ],
            [
                {"Data Type": SQDCorrections, "Usage": "SQD Bitstring Corrections"},
                {"Data Type": SQDParams, "Usage": "SQD Optimized Parameters"},
            ],
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": QuantumCircuit, "Usage": "SQD Circuit"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        if "Multi Reference Wavefunction" in self.input_data:
            num_qubits = self.input_data["Multi Reference Wavefunction"].num_active
        else:
            num_qubits = self.input_data["SQD Bitstring Corrections"].num_orbitals
        self.result = QuantumCircuit(
            qubit_count=num_qubits, gate_set=None, instructions=None
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Circuit",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "SQD Circuit"},
                ),
            )


class LUCJ_SQDSampleCircuit(QuantumProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        shots=1e6,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            shots=shots,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": QuantumCircuit, "Usage": "SQD Circuit"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["SQD Circuit"].qubit_count
        accepted_orbitals = [
            8,
            16,
            32,
        ]  # RJM reference to file - we could create more references or fit
        orbs = str(min(accepted_orbitals, key=lambda x: abs(x - num_orbitals)))
        orbs = "8"
        with open(LUCJ_PATH + "/lucj_K" + orbs + "_L1.qpy", "rb") as f:
            loaded_circs = qpy.load(f)

        circuit = loaded_circs[0]
        self.required_resources = QuantumResource(
            quantum_circuit=circuit,
            optimization_level=2,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": SQDSamples, "Usage": "SQD Samples"}]

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_qubits = self.input_data["SQD Circuit"].qubit_count
        self.result = SQDSamples(
            num_samples=self.shots, num_qubits=num_qubits, samples=None
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Samples",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "SQD Samples"},
                ),
            )


class LUCJ_SQDPartitionSubspace(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        bitstrings_per_subspace=None,
    ):
        self.bs_per_ss = bitstrings_per_subspace

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": SQDSamples, "Usage": "SQD Samples"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": SQDSubspace, "Usage": "SQD Subspace"}]

    def compute_flop_count(self):
        return 1000

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        samples: SQDSamples = self.input_data["SQD Samples"]
        num_samples = samples.num_samples
        num_qubits = samples.num_qubits
        significant_bitstrings = (
            5000
            * num_qubits
            / 20
            * np.log10(num_samples)  # rjm where do these come from?
        )
        num_subspaces = math.ceil(significant_bitstrings / self.bs_per_ss)
        self.result = SQDSubspace(
            dimension=round(significant_bitstrings / num_subspaces),
            num_subspaces=num_subspaces,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Subspace",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "SQD Subspace"},
                ),
            )


class LUCJ_SQDDiagonalize(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": SQDSubspace, "Usage": "SQD Subspace"},
            {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
        ]

    def set_required_resources(self):
        num_subspaces = self.input_data["SQD Subspace"].num_subspaces
        dimension = self.input_data["SQD Subspace"].dimension
        self.required_resources = ClassicalResource(
            memory=num_subspaces * dimension**2 * 8,
            num_cores=num_subspaces,
        )

    def set_output_properties(self):
        self.output_properties = [
            {
                "Data Type": SQDDiagResults,
                "Usage": "SQD Diagonalization Results",
                "Status": "Current",
            }
        ]

    def compute_flop_count(self):
        dimension = self.input_data["SQD Subspace"].dimension
        low = -20.6666 + 0.019477 * dimension - 4.98015e-6 * dimension**2
        high = 31.5 - 0.06712 * dimension + 3.54464e-5 * dimension**2

        return (low * 1.5 + high / 1.5) / 2 * proc_rate_hz  # RJM what is going on here?

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_subspaces = self.input_data["SQD Subspace"].num_subspaces
        subspace_dim = self.input_data["SQD Subspace"].dimension
        num_orbitals = self.input_data["Spin Hamiltonian"].num_orbitals
        self.result = SQDDiagResults(
            eigenstates=None,
            eigenvalues=None,
            avg_orbital_occs=None,
            subspace_dim=subspace_dim,
            num_orbitals=num_orbitals,
            num_subspaces=num_subspaces,
        )

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Diagonalization Results",
                        "Status": "Current",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Diagonalization Results",
                        "Status": "Current",
                    },
                ),
            )


class LUCJ_SQDCheckConvergence(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        remaining_itrs=None,
    ):
        self.remaining_itrs = 0 if remaining_itrs is None else remaining_itrs
        set_dynamic = True if self.remaining_itrs > 0 else False

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            dynamic=set_dynamic,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {
                "Data Type": SQDDiagResults,
                "Usage": "SQD Diagonalization Results",
                "Status": "Current",
            },
            {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": GSE, "Usage": "Ground State Energy"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        if self.remaining_itrs == 0:
            self.result = GSE(energy=None, uncertainty=None, method="SQD")
        else:
            self.result = self.input_data["SQD Diagonalization Results"]

    def generate_output(self) -> list[Data]:
        if self.remaining_itrs == 0:
            if "Image" in self.input_data:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "Ground State Energy",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )
            else:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "Ground State Energy",
                        },
                    ),
                )
        else:
            if "Image" in self.input_data:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "SQD Diagonalization Results",
                            "Status": "Old",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.input_data["Spin Hamiltonian"],
                        properties={
                            "Usage": "Spin Hamiltonian",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )
            else:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "SQD Diagonalization Results",
                            "Status": "Old",
                        },
                    ),
                    Data(
                        data=self.input_data["Spin Hamiltonian"],
                        properties={
                            "Usage": "Spin Hamiltonian",
                        },
                    ),
                )

    def extend_network(self) -> Network:
        subspace_dim = self.input_data["SQD Diagonalization Results"].subspace_dim
        config_recovery: Node = Node(process_model=LUCJ_SQDConfigRecovery)
        optimize_params: Node = Node(process_model=LUCJ_SQDOptimizeParams)
        prepare_circ: Node = Node(process_model=LUCJ_SQDPrepareCircuit)
        sample_circ: Node = Node(process_model=LUCJ_SQDSampleCircuit)
        partition_subspace: Node = Node(
            process_model=LUCJ_SQDPartitionSubspace,
            bitstrings_per_subspace=math.ceil(subspace_dim / 1000) * 1000,
        )
        diagonalize: Node = Node(process_model=LUCJ_SQDDiagonalize)
        check_convergence: Node = Node(
            process_model=LUCJ_SQDCheckConvergence,
            remaining_itrs=self.remaining_itrs - 1,
        )

        prepare_circ.process.selected = True

        config_recovery.extend(prepare_circ)
        optimize_params.extend(prepare_circ)
        prepare_circ.extend(sample_circ)
        sample_circ.extend(partition_subspace)
        partition_subspace.extend(diagonalize)
        diagonalize.extend(check_convergence)

        return Network(
            nodes=[
                config_recovery,
                optimize_params,
                prepare_circ,
                sample_circ,
                partition_subspace,
                diagonalize,
                check_convergence,
            ],
            input_nodes=[
                config_recovery,
                optimize_params,
                diagonalize,
                check_convergence,
            ],
            output_nodes=[check_convergence],
        )


class LUCJ_SQDConfigRecovery(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {
                "Data Type": SQDDiagResults,
                "Usage": "SQD Diagonalization Results",
                "Status": "Old",
            },
        ]

    def set_required_resources(self):
        diag_results = self.input_data["SQD Diagonalization Results"]
        subspace_dim = diag_results.subspace_dim
        num_orbitals = diag_results.num_orbitals
        num_subspaces = diag_results.num_subspaces
        self.required_resources = ClassicalResource(
            memory=subspace_dim * num_subspaces * num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": SQDCorrections, "Usage": "SQD Bitstring Corrections"}
        ]

    def compute_flop_count(self):
        diag_results = self.input_data["SQD Diagonalization Results"]
        subspace_dim = diag_results.subspace_dim
        num_orbitals = diag_results.num_orbitals
        num_subspaces = diag_results.num_subspaces
        return (
            num_subspaces * subspace_dim * num_orbitals**2 * near_one
        )  # RJM rand int again

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        num_orbitals = self.input_data["SQD Diagonalization Results"].num_orbitals
        self.result = SQDCorrections(num_orbitals=num_orbitals)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Bitstring Corrections",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Bitstring Corrections",
                    },
                ),
            )


class LUCJ_SQDOptimizeParams(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {
                "Data Type": SQDDiagResults,
                "Usage": "SQD Diagonalization Results",
                "Status": "Old",
            },
        ]

    def set_required_resources(self):
        diag_results = self.input_data["SQD Diagonalization Results"]
        num_orbitals = diag_results.num_orbitals
        self.required_resources = ClassicalResource(
            memory=num_orbitals**2 * 8,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": SQDParams, "Usage": "SQD Optimized Parameters"}
        ]

    def compute_flop_count(self):
        diag_results = self.input_data["SQD Diagonalization Results"]
        num_orbitals = diag_results.num_orbitals
        return num_orbitals**2 * near_one  # RJM rand uniform again

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = SQDParams(params=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Optimized Parameters",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "SQD Optimized Parameters",
                    },
                ),
            )


### VQE (MR WF)
@selection  # nothing
class LUCJ_VQESetAnsatz(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
            ],
            [
                {"Data Type": VQEParams, "Usage": "VQE Variational Parameters"},
                {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Old"},
            ],
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Current"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = VQEAnsatz(ansatz=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "VQE Ansatz",
                        "Status": "Current",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "VQE Ansatz", "Status": "Current"},
                ),
            )


# trotter of ham ~O(N^4)*num_itrs (Ham has N^4 terms) N^4 gates
@selection
class LUCJ_VQEEvolveState(QuantumProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            shots=1e6,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
            {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Current"},
        ]

    def set_required_resources(self):
        num_orbitals = self.input_data["Multi Reference Wavefunction"].num_active
        accepted_orbitals = [
            8,
            16,
            32,
        ]  # RJM we could make a less sparse fit ie more files or use a model
        orbs = str(min(accepted_orbitals, key=lambda x: abs(x - num_orbitals)))
        #        orbs = "8"
        with open(LUCJ_PATH + "/lucj_K" + orbs + "_L1.qpy", "rb") as f:
            loaded_circs = qpy.load(f)

        circuit = loaded_circs[0]
        self.required_resources = QuantumResource(
            quantum_circuit=circuit,
            optimization_level=2,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": QuantumCircuit, "Usage": "VQE Quantum Circuit"}
        ]

    # def compute_flop_count(self):
    #     return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = QuantumCircuit(qubit_count=None, gate_set=None, instructions=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "VQE Quantum Circuit",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "VQE Quantum Circuit"},
                ),
            )


# N^4/eps^2
@selection
class LUCJ_VQEMeasureExpVal(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
            {"Data Type": QuantumCircuit, "Usage": "VQE Quantum Circuit"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": float, "Usage": "VQE Expectation Value", "Status": "Current"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = 42.0

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "VQE Expectation Value",
                        "Status": "Current",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "VQE Expectation Value", "Status": "Current"},
                ),
            )


@selection
class LUCJ_VQECheckConvergence(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        remaining_itrs=0,
    ):
        self.remaining_itrs = remaining_itrs
        set_dynamic = True if self.remaining_itrs > 0 else False
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                if "Status" in data.properties:
                    self.input_data[
                        f"{data.properties['Status'] } {data.properties['Usage']}"
                    ] = data.data
                else:
                    self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
            dynamic=set_dynamic,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            [
                {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
                {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Current"},
                {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
                {
                    "Data Type": float,
                    "Usage": "VQE Expectation Value",
                    "Status": "Current",
                },
            ],
            [
                {"Data Type": MultiRefWF, "Usage": "Multi Reference Wavefunction"},
                {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Current"},
                {"Data Type": SpinHam, "Usage": "Spin Hamiltonian"},
                {
                    "Data Type": float,
                    "Usage": "VQE Expectation Value",
                    "Status": "Current",
                },
                {"Data Type": float, "Usage": "VQE Expectation Value", "Status": "Old"},
            ],
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": GSE, "Usage": "Ground State Energy"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        if self.remaining_itrs > 0:
            self.result = self.input_data["Current VQE Expectation Value"]
        else:
            energy = self.input_data["Current VQE Expectation Value"]
            self.result = GSE(energy=energy, uncertainty=None, method="VQE")

    def generate_output(self) -> list[Data]:
        if self.remaining_itrs > 0:
            if "Image" in self.input_data:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "VQE Expectation Value",
                            "Status": "Old",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.input_data["Multi Reference Wavefunction"],
                        properties={
                            "Usage": "Multi Reference Wavefunction",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.input_data["Current VQE Ansatz"],
                        properties={
                            "Usage": "VQE Ansatz",
                            "Status": "Old",
                            "Image": self.input_data["Image"],
                        },
                    ),
                    Data(
                        data=self.input_data["Spin Hamiltonian"],
                        properties={
                            "Usage": "Spin Hamiltonian",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )

            else:
                return (
                    Data(
                        data=self.result,
                        properties={"Usage": "VQE Expectation Value", "Status": "Old"},
                    ),
                    Data(
                        data=self.input_data["Multi Reference Wavefunction"],
                        properties={"Usage": "Multi Reference Wavefunction"},
                    ),
                    Data(
                        data=self.input_data["Current VQE Ansatz"],
                        properties={"Usage": "VQE Ansatz", "Status": "Old"},
                    ),
                    Data(
                        data=self.input_data["Spin Hamiltonian"],
                        properties={"Usage": "Spin Hamiltonian"},
                    ),
                )
        else:
            if "Image" in self.input_data:
                return (
                    Data(
                        data=self.result,
                        properties={
                            "Usage": "Ground State Energy",
                            "Image": self.input_data["Image"],
                        },
                    ),
                )

            else:
                return (
                    Data(
                        data=self.result,
                        properties={"Usage": "Ground State Energy"},
                    ),
                )

    def extend_network(self) -> Network:
        optimize_params = Node(process_model=LUCJ_VQEOptimizeParams)
        set_ansatz = Node(process_model=LUCJ_VQESetAnsatz)
        evolve_state = Node(process_model=LUCJ_VQEEvolveState)
        measure_exp_val = Node(process_model=LUCJ_VQEMeasureExpVal)
        check_convergence = Node(
            process_model=LUCJ_VQECheckConvergence,
            remaining_itrs=self.remaining_itrs - 1,
        )

        set_ansatz.process.selected = True
        evolve_state.process.selected = True
        measure_exp_val.process.selected = True
        check_convergence.process.selected = True

        optimize_params.extend(set_ansatz)
        set_ansatz.extend(evolve_state)
        set_ansatz.extend(check_convergence)
        evolve_state.extend(measure_exp_val)
        measure_exp_val.extend(check_convergence)

        network = Network(
            nodes=[
                optimize_params,
                set_ansatz,
                evolve_state,
                measure_exp_val,
                check_convergence,
            ],
            input_nodes=[
                optimize_params,
                evolve_state,
                measure_exp_val,
                check_convergence,
            ],
            output_nodes=[check_convergence],
        )
        return network


# num_parameters scale with num terms N^4
class LUCJ_VQEOptimizeParams(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": float, "Usage": "VQE Expectation Value", "Status": "Old"},
            {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Old"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": VQEParams, "Usage": "VQE Variational Parameters"},
            {"Data Type": VQEAnsatz, "Usage": "VQE Ansatz", "Status": "Old"},
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = VQEParams(params=None)

    def generate_output(self) -> list[Data]:
        if "Image" in self.input_data:
            return (
                Data(
                    data=self.result,
                    properties={
                        "Usage": "VQE Variational Parameters",
                        "Image": self.input_data["Image"],
                    },
                ),
                Data(
                    data=self.input_data["VQE Ansatz"],
                    properties={
                        "Usage": "VQE Ansatz",
                        "Status": "Old",
                        "Image": self.input_data["Image"],
                    },
                ),
            )

        else:
            return (
                Data(
                    data=self.result,
                    properties={"Usage": "VQE Variational Parameters"},
                ),
                Data(
                    data=self.input_data["VQE Ansatz"],
                    properties={"Usage": "VQE Ansatz", "Status": "Old"},
                ),
            )


### Post Processing
class LUCJ_ComputeActivationEnergies(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        num_images=1,
    ):
        self.num_images = num_images
        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        if self.num_images == 1:
            self.expected_input_properties = [
                {"Data Type": GSE, "Usage": "Ground State Energy"},
            ]
        else:
            self.expected_input_properties = [
                {"Data Type": GSE, "Usage": "Ground State Energy", "Image": idx}
                for idx in range(1, self.num_images + 1)
            ]

        self.expected_input_properties.append(
            {"Data Type": list, "Usage": "Set of Reactions"}
        )

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [
            {"Data Type": ActivationEnergies, "Usage": "Activation Energies"}
        ]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = ActivationEnergies(energies=None, uncertainty=None)

    def generate_output(self) -> list[Data]:
        return (
            Data(
                data=self.result,
                properties={"Usage": "Activation Energies"},
            ),
        )


class LUCJ_MKM(ClassicalProcess):
    def __init__(
        self,
        inputs: list[Data] = None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
    ):

        if inputs != None:
            self.input_data = {}
            for data in inputs:
                self.input_data[data.properties["Usage"]] = data.data

                try:
                    image_num = data.properties["Image"]
                    self.input_data["Image"] = image_num
                except KeyError:
                    continue

        super().__init__(
            inputs,
            expected_input_properties,
            required_resources,
            output_properties,
        )

    def set_expected_input_properties(self):
        self.expected_input_properties = [
            {"Data Type": ActivationEnergies, "Usage": "Activation Energies"},
            {"Data Type": list, "Usage": "Set of Reactions"},
        ]

    def set_required_resources(self):
        self.required_resources = ClassicalResource(
            memory=42,
            num_cores=1,
        )

    def set_output_properties(self):
        self.output_properties = [{"Data Type": PCurve, "Usage": "Polarization Curve"}]

    def compute_flop_count(self):
        return 10

    def validate_data(self) -> bool:
        return True

    @compute_resources
    def update(self):
        self.result = PCurve(curve_data=None)

    def generate_output(self) -> list[Data]:
        return (
            Data(
                data=self.result,
                properties={"Usage": "Polarization Curve"},
            ),
        )


"""Selection nodes:
branch 1: solve GSE: (DMRG, VQE, SQD, QPE)
branch 2: active space selection: (DD, AVAS, IAO, IBO), solve GSE: (DFT, CCSD)

"""


def LUCJ_computational_network(
    image_number: int = 1,
    HF_iterations: int = 10,
    dmrg_iterations: int = 1,
    sqd_iterations: int = 30,
    sqd_bitstrings_per_subspace: int = 5e3,
    vqe_iterations: int = 1,
    broker=None,
):
    reaction_selection: Network = LUCJ_reaction_selection()
    geometry_optimization: Network = (
        LUCJ_geometry_optimization()
    )  # NEB as one of input nodes to set number of images N

    ### Make N copies of GSE networks distinguished by image number
    if image_number > 1:
        gse_network = [
            LUCJ_gse_network(
                image,
                HF_iterations,
                dmrg_iterations,
                sqd_iterations,
                sqd_bitstrings_per_subspace,
                vqe_iterations,
            )
            for image in range(1, image_number + 1)
        ]
        gse_network: Network = functools.reduce(lambda x, y: x @ y, gse_network)
    else:
        gse_network = LUCJ_gse_network(
            1,
            HF_iterations,
            dmrg_iterations,
            sqd_iterations,
            sqd_bitstrings_per_subspace,
            vqe_iterations,
        )

    compute_activation_energies: Node = Node(
        process_model=LUCJ_ComputeActivationEnergies,
        num_images=image_number,
        extend_dynamic=True,
    )
    microkinetic_modeling: Node = Node(process_model=LUCJ_MKM)

    ### Nodes that require set of reactions
    define_reactions: Node = reaction_selection.get_node(LUCJ_DefineReactions)[0]
    hf_select_basis: Node = gse_network.get_node(LUCJ_HFSelectBasis)
    for node in hf_select_basis:
        define_reactions.extend(node)
    define_reactions.extend(compute_activation_energies)
    define_reactions.extend(microkinetic_modeling)

    network = reaction_selection + geometry_optimization
    network = network + gse_network
    network = network + compute_activation_energies
    network = network + microkinetic_modeling

    network.input_nodes.append(
        geometry_optimization.get_node(LUCJ_NudgedElasticBand)[0]
    )

    network.name = "Computational LUCJ"
    network.description = (
        "Complete workflow for computational polarization curve generation"
    )
    network.broker = broker

    return network


def LUCJ_reaction_selection():
    select_material: Node = Node(process_model=LUCJ_SelectMaterial)
    select_reactant: Node = Node(process_model=LUCJ_SelectReactant)
    define_reactions: Node = Node(process_model=LUCJ_DefineReactions)

    # select_material.extend(select_reactant)
    select_material.extend(define_reactions)
    select_reactant.extend(define_reactions)

    description = "Select materials, reactants and reactions of interest"
    network = Network(
        name="LUCJ Reaction Selection",
        description=description,
        nodes=[select_material, select_reactant, define_reactions],
        input_nodes=[select_material, select_reactant],
        output_nodes=[select_material, select_reactant, define_reactions],
    )
    return network


def LUCJ_geometry_optimization():
    schrodinger_get_geometries: Network = LUCJ_schrodinger_geometries()
    nudge_elastic_band: Node = Node(process_model=LUCJ_NudgedElasticBand)

    network = schrodinger_get_geometries + nudge_elastic_band
    network.input_nodes.append(nudge_elastic_band)
    network.name = "LUCJ Geometry Optimization"
    network.description = (
        "Generate transition state geometries given set of reactions and structure"
    )
    return network


def LUCJ_schrodinger_geometries() -> Network:
    compute_reactant_geometry: Node = Node(process_model=LUCJ_ComputeReactantGeom)
    compute_product_geometry: Node = Node(process_model=LUCJ_ComputeProductGeom)

    compute_reactant_geometry.extend(compute_product_geometry)

    description = (
        "Use Schrodinger software to compute optimized reactant and product geometries"
    )
    network = Network(
        name="LUCJ Schrodinger Geometries",
        description=description,
        nodes=[compute_reactant_geometry, compute_product_geometry],
        input_nodes=[compute_reactant_geometry, compute_product_geometry],
        output_nodes=[compute_reactant_geometry, compute_product_geometry],
    )
    return network


def LUCJ_gse_network(
    image_number,
    hf_iterations,
    dmrg_iterations,
    sqd_iterations,
    sqd_bitstrings_per_subspace,
    vqe_iterations,
):
    gse_preprocessing: Network = LUCJ_gse_preprocessing(image_number, hf_iterations)
    solve_gse: Network = LUCJ_solve_gse(
        dmrg_iterations,
        sqd_iterations,
        sqd_bitstrings_per_subspace,
        vqe_iterations,
    )
    # nevpt2_correction: Network = LUCJ_nevpt2()

    network = gse_preprocessing + solve_gse
    # network = gse_preprocessing + solve_gse + nevpt2_correction

    network.name = "LUCJ GSE Network"
    network.description = "Network to compute single-reference WF and solve GSE, optional image number to connect with NEB"
    return network


def LUCJ_gse_preprocessing(image_num: int, iterations: int) -> Network:
    hartree_fock: Network = LUCJ_hartree_fock(image_num, iterations)  # SR wavefunction
    to_mr_wf: Network = LUCJ_to_multi_ref()
    # compute_single_ref_wf: Node = Node(
    #     process_model=LUCJ_ComputeSingleRefWF, extend_dynamic=True
    # )
    # compute_ferm_ham: Node = Node(
    #     process_model=LUCJ_ComputeFermionicHam, extend_dynamic=True
    # )

    compute_integrals = hartree_fock.get_nodes(
        LUCJ_HFComputeHIntegral,
        LUCJ_HFComputeJIntegral,
        LUCJ_HFComputeKIntegral,
        LUCJ_HFComputeSIntegral,
    )
    hartree_fock.output_nodes.extend(compute_integrals)

    # mol_orbitals_to_wf = to_mr_wf @ compute_single_ref_wf @ compute_ferm_ham
    network = hartree_fock + to_mr_wf

    network.name = "LUCJ GSE Preprocessing"
    network.description = "Generate single-reference wavefunction using Hartree Fock and optionally select active space for multi-reference wavefunction"
    return network


def LUCJ_hartree_fock(image_num: int, iterations: int) -> Network:
    select_basis_set: Node = Node(process_model=LUCJ_HFSelectBasis, image_num=image_num)
    compute_integrals: Network = LUCJ_hf_compute_integrals(image_num)
    compute_initial_density_matrix: Node = Node(process_model=LUCJ_HFComputeDensityMat)
    hf_iteration: Network = LUCJ_hf_iteration(iterations=iterations)

    network = select_basis_set + compute_integrals
    network.input_nodes.extend(compute_integrals.input_nodes)
    network.output_nodes.append(select_basis_set)

    network = network + compute_initial_density_matrix
    network = network + hf_iteration
    network.name = "LUCJ Hartree Fock"
    network.description = f"Complete Hartree Fock workflow for {iterations} iterations"

    return network


def LUCJ_hf_compute_integrals(image_num: int = None):
    compute_core_integral: Node = Node(
        process_model=LUCJ_HFComputeHIntegral, image_num=image_num
    )
    compute_coulomb_integral: Node = Node(
        process_model=LUCJ_HFComputeJIntegral, image_num=image_num
    )
    compute_exchange_integral: Node = Node(
        process_model=LUCJ_HFComputeKIntegral, image_num=image_num
    )
    compute_overlap_integral: Node = Node(
        process_model=LUCJ_HFComputeSIntegral, image_num=image_num
    )

    description = "Compute necessary one and two electron integrals for Hartree Fock"
    network = Network(
        name="LUCJ HF Compute Integrals",
        description=description,
        nodes=[
            compute_core_integral,
            compute_coulomb_integral,
            compute_exchange_integral,
            compute_overlap_integral,
        ],
        input_nodes=[
            compute_core_integral,
            compute_coulomb_integral,
            compute_exchange_integral,
            compute_overlap_integral,
        ],
        output_nodes=[
            compute_core_integral,
            compute_coulomb_integral,
            compute_exchange_integral,
            compute_overlap_integral,
        ],
    )
    return network


def LUCJ_hf_iteration(iterations: int = 64) -> Network:  # 64 or until converged
    compute_fock_matrix: Node = Node(process_model=LUCJ_HFComputeFockMat)
    solve_hfr_equations: Node = Node(process_model=LUCJ_HFSolveHFREqns)
    check_convergence: Node = Node(
        process_model=LUCJ_HFCheckConvergence, remaining_itrs=iterations - 1
    )

    compute_fock_matrix.extend(solve_hfr_equations)
    solve_hfr_equations.extend(check_convergence)

    description = "Hartree Fock iteration for optimizing Fock matrix"
    network = Network(
        name="LUCJ HF Iteration",
        description=description,
        nodes=[compute_fock_matrix, solve_hfr_equations, check_convergence],
        input_nodes=[compute_fock_matrix, check_convergence],
        output_nodes=[check_convergence],
    )
    return network


def LUCJ_to_multi_ref() -> Network:
    active_space_selection: Network = LUCJ_select_active_space()
    compute_as_ferm_ham: Node = Node(process_model=LUCJ_ComputeASHamiltonian)
    compute_multiref_wf: Node = Node(process_model=LUCJ_ComputeMultiRefWF)

    compute_as_ferm_ham.extend(compute_multiref_wf)
    combined: Network = compute_as_ferm_ham @ compute_multiref_wf

    grouping = {node: [compute_as_ferm_ham] for node in active_space_selection.nodes}

    network = active_space_selection + combined
    network.input_nodes.extend([compute_multiref_wf, compute_as_ferm_ham])
    network.name = "LUCJ SR to MR"
    network.description = (
        "Select active space and convert to multi-reference wavefunction"
    )
    network.groupings = grouping
    return network


def LUCJ_select_active_space() -> Network:
    density_difference: Node = Node(
        process_model=LUCJ_ActiveSpaceDD, extend_dynamic=True
    )
    atomic_valence_active_space: Node = Node(
        process_model=LUCJ_ActiveSpaceAVAS, extend_dynamic=True
    )
    intrinsic_atomic_orbital: Node = Node(
        process_model=LUCJ_ActiveSpaceIAO, extend_dynamic=True
    )
    intrinsic_bond_orbital: Node = Node(
        process_model=LUCJ_ActiveSpaceIBO, extend_dynamic=True
    )

    description = "Select active space given single reference wavefunction"
    network = Network(
        name="LUCJ Active Space Selection",
        description=description,
        nodes=[
            density_difference,
            atomic_valence_active_space,
            intrinsic_atomic_orbital,
            intrinsic_bond_orbital,
        ],
        input_nodes=[
            density_difference,
            atomic_valence_active_space,
            intrinsic_atomic_orbital,
            intrinsic_bond_orbital,
        ],
        output_nodes=[
            density_difference,
            atomic_valence_active_space,
            intrinsic_atomic_orbital,
            intrinsic_bond_orbital,
        ],
        selection_nodes=[
            (
                density_difference,
                atomic_valence_active_space,
                intrinsic_atomic_orbital,
                intrinsic_bond_orbital,
            )
        ],
    )
    return network


def LUCJ_solve_gse(
    dmrg_itrs, sqd_itrs, sqd_bitstrings_per_subspace, vqe_itrs
) -> Network:
    gse_dmrg: Network = LUCJ_gse_dmrg(dmrg_itrs - 1)  # MR
    # gse_ccsd: Network = LUCJ_gse_ccsd()  # SR
    # gse_dft: Network = LUCJ_gse_dft()  # SR
    gse_qpe: Network = LUCJ_gse_qpe(1)  # MR
    gse_sqd: Network = LUCJ_gse_sqd(
        iterations=sqd_itrs, bitstrings_per_subspace=sqd_bitstrings_per_subspace
    )  # MR
    gse_vqe: Network = LUCJ_gse_vqe(vqe_itrs)  # MR

    network = gse_dmrg @ gse_qpe @ gse_sqd @ gse_vqe
    network.name = "LUCJ Solve GSE"
    network.description = "Network of GSE methods including (classical: DMRG, CCSD, DFT) and (quantum: QPE, SQD, VQE)"
    return network


def LUCJ_encode_hamiltonian() -> Network:
    DF_encoding: Node = Node(process_model=LUCJ_DFEncoding)
    SCBK_mapping: Node = Node(process_model=LUCJ_SCBKMapping)
    JW_mapping: Node = Node(process_model=LUCJ_JWMapping)
    BK_mapping: Node = Node(process_model=LUCJ_BKMapping)

    DF_encoding.extend(SCBK_mapping)
    DF_encoding.extend(JW_mapping)
    DF_encoding.extend(BK_mapping)

    description = "Transform Fermionic Hamiltonian to spin Hamiltonian using chosen encoding scheme"
    network = Network(
        name="LUCJ Encode Hamiltonian",
        description=description,
        nodes=[SCBK_mapping, JW_mapping, BK_mapping, DF_encoding],
        input_nodes=[DF_encoding],
        output_nodes=[SCBK_mapping, JW_mapping, BK_mapping],
        selection_nodes=[(SCBK_mapping, JW_mapping, BK_mapping)],
    )
    return network


def LUCJ_gse_dmrg(iterations: int = None):
    encode_hamiltonian: Network = LUCJ_encode_hamiltonian()
    hamiltonian_to_mpo: Node = Node(process_model=LUCJ_DMRGHamiltonianMPO)
    wavefunction_to_mps: Node = Node(
        process_model=LUCJ_DMRGInitializeMPS
    )  ## Series of SVDs (longer, but reveal singular values -> truncation)
    canonicalize_mps: Node = Node(process_model=LUCJ_DMRGCanonizeMPS)
    dmrg_iteration: Network = LUCJ_dmrg_iteration(iterations)

    prepare_mpo = encode_hamiltonian + hamiltonian_to_mpo
    prepare_mps = wavefunction_to_mps + canonicalize_mps

    df_encoding: Node = encode_hamiltonian.get_node(LUCJ_DFEncoding)[0]
    grouping = {
        node: [wavefunction_to_mps, df_encoding]
        for node in encode_hamiltonian.output_nodes
    }

    network = prepare_mpo @ prepare_mps
    network = network + dmrg_iteration
    network.name = "LUCJ GSE: DMRG"
    network.description = (
        f"Compute the ground state energy using DMRG with {iterations} iterations"
    )
    network.groupings = grouping
    return network


def LUCJ_dmrg_iteration(iterations: int) -> Network:
    optimize_site: list[Node] = Node(
        process_model=LUCJ_DMRGOptimizeSite
    )  ## compute L(or R) expression, solve eigenproblem for site, normalize site, prepare next site, compute R(or L)
    dmrg_check_convergence: Node = Node(
        process_model=LUCJ_DMRGCheckConvergence,
        remaining_itrs=iterations,
        extend_dynamic=True,
    )

    optimize_site.extend(dmrg_check_convergence)

    description = "DMRG iteration to optimize MPS and ground state energy"
    network = Network(
        name="LUCJ DMRG Iteration",
        description=description,
        nodes=[optimize_site, dmrg_check_convergence],
        input_nodes=[optimize_site],
        output_nodes=[dmrg_check_convergence],
    )
    return network


def LUCJ_gse_qpe(num_ancillas: int = 1):
    encode_hamiltonian: Network = LUCJ_encode_hamiltonian()
    qubitize_hamiltonian: Node = Node(process_model=LUCJ_QPEQubitizeHam)
    init_state: Node = Node(process_model=LUCJ_QPEInitState)
    evolve_state: Node = Node(process_model=LUCJ_QPEEvolveState)
    compute_gse: Node = Node(process_model=LUCJ_QPEComputeGSE)

    num_ancillas_input = Data(
        data=num_ancillas, properties={"Usage": "Number of Ancillas"}
    )
    input_edge = DirectedEdge(
        data=(num_ancillas_input,),
        source_node=None,
        dest_nodes=[evolve_state],
    )
    evolve_state.append_input_edge(input_edge)

    network = encode_hamiltonian + qubitize_hamiltonian
    network = network @ init_state
    network = network + evolve_state + compute_gse

    df_encoding: Node = encode_hamiltonian.get_node(LUCJ_DFEncoding)[0]
    grouping = {
        node: [init_state, df_encoding] for node in encode_hamiltonian.output_nodes
    }
    network.name = "LUCJ GSE QPE"
    network.description = (
        f"Compute the ground state energy using QPE with {num_ancillas} ancillas"
    )
    network.groupings = grouping

    return network


def LUCJ_gse_sqd(iterations, bitstrings_per_subspace) -> Network:
    encode_hamiltonian: Network = LUCJ_encode_hamiltonian()
    init_circuit: Node = Node(process_model=LUCJ_SQDPrepareCircuit)
    sample_circuit: Node = Node(process_model=LUCJ_SQDSampleCircuit)
    subspace_partition: Node = Node(
        process_model=LUCJ_SQDPartitionSubspace,
        bitstrings_per_subspace=bitstrings_per_subspace,
    )
    subspace_diagonalization: Node = Node(process_model=LUCJ_SQDDiagonalize)
    check_convergence: Node = Node(
        process_model=LUCJ_SQDCheckConvergence, remaining_itrs=iterations
    )

    network = init_circuit + sample_circuit + subspace_partition
    network = network @ encode_hamiltonian
    network = network + subspace_diagonalization + check_convergence

    for node in encode_hamiltonian.output_nodes:
        node.extend(check_convergence)

    df_encoding: Node = encode_hamiltonian.get_node(LUCJ_DFEncoding)[0]
    grouping = {
        node: [init_circuit, df_encoding] for node in encode_hamiltonian.output_nodes
    }

    network.name = "LUCJ GSE SQD"
    network.description = (
        f"Compute the ground state energy using SQD with {iterations} iterations"
    )
    network.groupings = grouping
    return network


def LUCJ_gse_vqe(iterations: int) -> Network:
    encode_hamiltonian: Network = LUCJ_encode_hamiltonian()
    init_ansatz: Node = Node(process_model=LUCJ_VQESetAnsatz)
    vqe_evolve_state: Node = Node(process_model=LUCJ_VQEEvolveState)  # QUANTUM
    measure_expect_val: Node = Node(process_model=LUCJ_VQEMeasureExpVal)
    vqe_check_convergence: Node = Node(
        process_model=LUCJ_VQECheckConvergence, remaining_itrs=iterations
    )

    init_ansatz.extend(vqe_evolve_state)
    init_ansatz.extend(vqe_check_convergence)
    vqe_evolve_state.extend(measure_expect_val)
    measure_expect_val.extend(vqe_check_convergence)

    vqe_iteration: Network = Network(
        nodes=[
            init_ansatz,
            vqe_evolve_state,
            measure_expect_val,
            vqe_check_convergence,
        ],
        input_nodes=[measure_expect_val, vqe_check_convergence],
        output_nodes=[vqe_check_convergence],
    )

    df_encoding: Node = encode_hamiltonian.get_node(LUCJ_DFEncoding)[0]
    grouping = {
        node: [
            init_ansatz,
            df_encoding,
            vqe_evolve_state,
            measure_expect_val,
            vqe_check_convergence,
        ]
        for node in encode_hamiltonian.output_nodes
    }

    network = encode_hamiltonian + vqe_iteration
    network.input_nodes.extend([init_ansatz, vqe_evolve_state, vqe_check_convergence])
    network.groupings = grouping

    network.name = "LUCJ GSE VQE"
    network.description = (
        f"Compute the ground state energy using VQE with {iterations} iterations"
    )
    return network


def LUCJ_nevpt2() -> Network:
    # TODO
    pass


# basis_length: keep from 10-16 (only those that interact with the water molecules at close range)
# num_images: number of images generated by NEB (each image computes a GSE) (atleast 1, no more than 10)
# hf_iterations: Hartree Fock iterations
# Select active space selection method: "DD", "AVAS", "IAO", "IBO"
# Select GSE method: "DMRG", "QPE", "SQD", "VQE"
# Select Hamiltonian encoding method: "SCBK", "JW", "BK"
# for PDS experiments
# Typical materials "Mg" "Al"
# Typical reactants "H2O" "OH"
def run_LUCJ_comp_network(
    basis_length_slab=10,  # what does this mean in the PDS context
    basis_length_react=2,  # what does this mean in the PDS context
    slab_species="Mg",  # substrate material.  Is this what the slab is made of?
    reactant_species="H2O",  # reactant
    num_images=1,  # why images?  Why?
    hf_iterations=10,
    active_space_method=None,
    gse_method=None,
    encoding_method=None,
    vqe_iterations=0,
    dmrg_iterations=0,
    dmrg_max_bond=1024,
    qpe_epsilon=0.01,  ## choose one of [0.1, 0.01, 0.0016] do we even use this?
    sqd_iterations=30,
    sqd_bitstrings_per_subspace=5e3,
    broker=None,
):
    available_AS_methods = ["DD", "AVAS", "IAO", "IBO"]
    available_GSE_methods = ["DMRG", "QPE", "SQD", "VQE"]
    available_ham_encoding_methods = ["SCBK", "JW", "BK"]

    assert active_space_method in available_AS_methods
    assert gse_method in available_GSE_methods
    assert qpe_epsilon in [0.1, 0.01, 0.0016], f"Unsupported epsilon value for QPE"

    gse_idxs = [None, None, None, None]
    gse_idxs[available_GSE_methods.index(gse_method)] = (
        available_ham_encoding_methods.index(encoding_method)
    )

    selection_idxs = (
        [available_AS_methods.index(active_space_method)] + gse_idxs
    ) * num_images

    starting_inputs = [
        [
            Data(data="Mg", properties={"Usage": "Material"}),
            Data(data=basis_length_slab, properties={"Usage": "Number of Sites"}),
        ],
        [
            Data(data="H2O", properties={"Usage": "Reactant"}),
            Data(data=basis_length_react, properties={"Usage": "Number of Sites"}),
        ],
        [Data(data=num_images, properties={"Usage": "Number of Images"})],
    ]

    max_bond_input = Data(
        data=dmrg_max_bond, properties={"Usage": "Max Bond Dimension"}
    )

    qpe_epsilon_input = Data(data=qpe_epsilon, properties={"Usage": "QPE Epsilon"})

    network = LUCJ_computational_network(
        num_images,
        hf_iterations,
        dmrg_iterations,
        sqd_iterations,
        sqd_bitstrings_per_subspace,
        vqe_iterations,
        broker,
    )

    for node in network.get_node(LUCJ_DMRGInitializeMPS):
        input_edge = DirectedEdge(
            data=(max_bond_input,),
            source_node=None,
            dest_nodes=[node],
        )
        node.append_input_edge(input_edge)

    for node in network.get_node(LUCJ_QPEEvolveState):
        input_edge = DirectedEdge(
            data=(qpe_epsilon_input,),
            source_node=None,
            dest_nodes=[node],
        )
        node.append_input_edge(input_edge)

    df = network.run(
        network.input_nodes,
        starting_inputs=starting_inputs,
        selected_nodes=selection_idxs,
    )

    return df, network
