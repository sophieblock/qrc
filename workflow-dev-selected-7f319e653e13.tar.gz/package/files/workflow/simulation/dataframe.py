import pandas as pd
from typing import Optional, TYPE_CHECKING, Dict
from .process import ClassicalProcess, QuantumProcess, Task

if TYPE_CHECKING:
    from workflow.simulation.graph import Node
    from workflow.simulation.process import Process


class SimulationResults:

    def __init__(self, df: pd.DataFrame):
        self._df = df
        self._descriptions = {node: node.process.description for node in df["Process"]}

    @property
    def raw(self) -> pd.DataFrame:
        """Directly access the raw pandas dataframe object"""

        return self._df

    def filter(self, *conditions) -> "SimulationResults":
        """Filter out rows by matching ALL columns condition args. The conditions argument is a tuple of 3 elements:
        (column name [str], operator [str], value) where only rows satisfying the condition of the column name and value
        are returned.

        Examples:
            1. filter(("Device Name", "==", "Lab Scientist")) will return only rows where the "Device Name" is "Lab Scientist"
            2. filter(("Device Name", "==", "IBM Torino"), ("Qubits Used", "<", 100)) will return only rows where less than 100 qubits were used on IBM Torino
            1. filter(("Circuit Depth", "!=", pd.NA)) will return only rows where the "Circuit Depth" is NOT <N/A>

        Returns:
            SimulationResults: pd.Dataframe wrapper for filtered results
        """

        OPERATORS = {
            "eq": lambda a, b: a.isna() if b in [None, pd.NA] else a == b,
            "==": lambda a, b: a.isna() if b in [None, pd.NA] else a == b,
            "ne": lambda a, b: a.notna() if b in [None, pd.NA] else a != b,
            "!=": lambda a, b: a.notna() if b in [None, pd.NA] else a != b,
            "gt": lambda a, b: a > b,
            ">": lambda a, b: a > b,
            "gte": lambda a, b: a >= b,
            ">=": lambda a, b: a >= b,
            "lt": lambda a, b: a < b,
            "<": lambda a, b: a < b,
            "lte": lambda a, b: a <= b,
            "<=": lambda a, b: a <= b,
        }

        mask = pd.Series([True] * len(self._df), index=self._df.index)
        for condition in conditions:
            try:
                col_name, op, val = condition
            except:
                raise ValueError(
                    f"Each filter condition must be a (column name, operator, value) tuple"
                )

            assert (
                op in OPERATORS.keys()
            ), f"Invalid operator condition, must be one of ('==', '!=', '>', '>=', '<', '<=')"

            if col_name not in self._df.columns:
                raise ValueError(
                    f"Unknown column {col_name}, Available columns: {self._df.columns.tolist()}"
                )

            mask &= OPERATORS[op](self._df[col_name], val)

        return SimulationResults(self._df[mask])

    def top(
        self, N: int, col_name: str, ascending: bool = False
    ) -> "SimulationResults":
        """Returns the top N rows in the column. The values of the column must be numerical

        Args:
            N (int): Number of rows to keep
            col_name (str): Name of the column
            ascending (bool, optional): Whether to display the top N (False) or bottom N (True) rows. Defaults to False.

        Returns:
            SimulationResults: SimulationResults containing only the top N rows of values in the specified column
        """

        if col_name not in self._df.columns:
            raise ValueError(
                f"Unknown column {col_name}, Available columns: {self._df.columns.tolist()}"
            )

        return SimulationResults(
            self._df.nlargest(N, col_name)
            if not ascending
            else self._df.nsmallest(N, col_name)
        )

    def bottom(self, N: int, col_name: str) -> "SimulationResults":
        """Returns the bottom N rows in the column. The values of the column must be numerical

        Args:
            N (int): Number of rows to keep
            col_name (str): Name of the column

        Returns:
            SimulationResults: SimulationResults containing only the bottom N rows of values in the specified column
        """

        return self.top(N, col_name, ascending=True)

    def search(self, process_query: str, case: bool = False) -> "SimulationResults":
        """Returns all rows that contain process_query anywhere in its Process name

        Args:
            process_query (str): string to query
            case (bool, optional): Determines whether query is case sensitive. Defaults to False.

        Returns:
            SimulationResults: SimulationResults object with only Processes containing query in its name
        """

        mask = (
            self._df["Process"]
            .astype(str)
            .str.contains(process_query, case=case, na=False)
        )
        return SimulationResults(self._df[mask])

    def unique(self, column: str) -> list:
        """Returns all unique values for a given column

        Args:
            column (str): Name of the column

        Returns:
            list: List of all unique values of the specified column
        """

        if column not in self._df.columns:
            raise ValueError(
                f"Unknown column {column}, Available columns: {self._df.columns.tolist()}"
            )

        return self._df[column].unique().tolist()

    def group(self, column: str) -> pd.DataFrame:
        """Counts the number of occurrences of unique values in the specified column

        Args:
            column (str): Name of the column.

        Returns:
            pd.DataFrame: Pandas Dataframe counting the number of unique occurrences of each value
        """

        if column not in self._df.columns:
            raise ValueError(
                f"Unknown column {column}, Available columns: {self._df.columns.tolist()}"
            )

        return self._df.groupby(column, dropna=False).size().reset_index(name="count")

    def get_description(self, process: "Node | int") -> str:
        """Gets the description (if it exists) of the underlying process for the given Node or dataframe row index.

        Args:
            process (Node | int): Node object or dataframe row index to get description of

        Returns:
            str: The process description (if it exists) or None.
        """
        if type(process).__name__ == "Node":
            return self._descriptions[process]
        elif isinstance(process, int):
            return self._descriptions[self._df["Process"].iloc[process]]

        raise TypeError(
            f"Expected argument of type Node or int of the dataframe row index"
        )

    def qubits_used(self) -> Dict["Process", int]:
        """Returns a dictionary mapping the process to the number of qubits used. Only quantum processes
        with nontrivial number of used qubits are tracked.

        Returns:
            Dict[Process, int]: dictionary mapping individual quantum processes to their number of qubits used
        """

        df = self.filter(("Qubits Used", "!=", pd.NA))
        return {row["Process"]: len(row["Qubits Used"]) for _, row in df.raw.iterrows()}

    def summary(self) -> pd.DataFrame:
        return self._df.describe()

    @property
    def columns(self) -> list:
        return self._df.columns.tolist()

    @property
    def classical_processes(self) -> "SimulationResults":
        """Returns a SimulationResults object with only the classical processes executed on the CPU/GPU

        Returns:
            SimulationResults: Filters only classical processes
        """

        is_classical_process = lambda a: isinstance(a.process, ClassicalProcess)
        mask = self._df["Process"].apply(is_classical_process)

        return SimulationResults(self._df[mask])

    @property
    def quantum_processes(self) -> "SimulationResults":
        """Returns a SimulationResults object with only the quantum processes executed on the QPU

        Returns:
            SimulationResults: Filters only quantum processes
        """

        is_quantum_process = lambda a: isinstance(a.process, QuantumProcess)
        mask = self._df["Process"].apply(is_quantum_process)

        return SimulationResults(self._df[mask])

    @property
    def task_processes(self) -> "SimulationResults":
        """Returns a SimulationResults object with only the task processes operated by Personnel/Equipment

        Returns:
            SimulationResults: Filters only task processes
        """

        is_task_process = lambda a: isinstance(a.process, Task)
        mask = self._df["Process"].apply(is_task_process)

        return SimulationResults(self._df[mask])

    @property
    def shape(self) -> tuple:
        return self._df.shape

    def __len__(self) -> int:
        return len(self._df)

    def __repr__(self) -> str:
        return f"SimulationResults: {self.shape[0]} rows x {self.shape[1]} cols\n{self._df.head()}"
