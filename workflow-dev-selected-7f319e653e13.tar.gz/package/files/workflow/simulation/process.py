# -*- coding: utf-8 -*-
"""This file contains class definitions for the base Process
class that specifies how individual processes/tasks are to
be executed/updated.

"""
import inspect
from typing import List, TYPE_CHECKING, Optional, Tuple, Dict, Any, Callable
from torch.fx.operator_schemas import type_matches

# from quimb.tensor import MatrixProductState
from itertools import chain
import logging
import copy
from .utilities import (
    all_dict1_vals_in_dict2_vals,
    any_dict1_vals_in_dict2_vals,
    InitError,
)
from .data import Data, ShapeEnv
from .devices.ibm_calibration import (
    SINGLE_QUBIT_GATES,
    TWO_QUBIT_GATES,
)
from ..core.schema import Flow, Signature

if TYPE_CHECKING:
    from .data import Data, Flow, Signature, ShapeEnv
    from .resources.resources import Resource
    from .resources.quantum_device import (
        QDeviceAllocation,
        QuantumResource,
        QuantumDevice,
        QuantumCircuit,
        QiskitQuantumCircuit,
    )
    from .resources.classical_device import DeviceAllocation, ClassicalDevice
    from .resources.equipment import Equipment
    from .resources.personnel import Personnel
    from .quantum import QuantumCircuit
    from .graph import Node, Network, DirectedEdge

import logging

logger: logging.Logger = logging.getLogger(__name__)

from typing import NamedTuple
import torch
from torch.fx.operator_schemas import (
    OpOverload,
    OpOverloadPacket,
    type_matches,
    _args_kwargs_to_normalized_args_kwargs,
)

from qiskit import transpile
from qiskit.transpiler import CouplingMap
from qiskit import QuantumCircuit as QiskitQuantumCircuit


def build_inspect_signature_from_process_signature(
    signature: "Signature",
) -> inspect.Signature:
    """
    Convert the left-flow portion of `signature` into a Python Signature object:
      - Non-variadic specs => normal positional params
      - If exactly one is variadic => we represent it with a *args param
      - We skip specs that are purely flow=RIGHT, so we don't demand them at call-time
    """
    params = []
    # logger.debug(f"Signature: {signature}")
    # for reg in signature:
    #     if reg.flow & Flow.LEFT:
    #         print("reg.flow & Flow.LEFT: ",reg.flow & Flow.LEFT)
    #     logger.debug(reg.flow)
    left_specs = [str(s) for s in signature if s.flow & Flow.LEFT]
    # print(f"left_specs: {left_specs}")
    # print(f"right_specs: {[str(s) for s in signature if s.flow & Flow.RIGHT]}")
    # If you allow multiple variadic specs, you'd need more advanced logic.
    # We assume at most one is variadic for now.
    variadic_seen = False

    for i, spec in enumerate(signature.lefts()):
        if not spec.variadic:
            # a normal positional parameter
            # logger.debug(f'spec name: {spec.name}, {spec.name.isidentifier()}')
            params.append(
                inspect.Parameter(
                    name=spec.name,
                    kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                )
            )
        else:
            # If we already saw a variadic, we can’t add a second *args
            if variadic_seen:
                raise ValueError(
                    "Multiple variadic specs found; not supported by this approach."
                )
            variadic_seen = True
            # Represent it with a *args param
            params.append(
                inspect.Parameter(
                    name=spec.name,
                    kind=inspect.Parameter.VAR_POSITIONAL,  # means *<spec.name>
                )
            )
            # We don't create subsequent params, or we keep scanning if you want
            # For a single-variadic approach, we can just continue or break
            # break

    return inspect.Signature(parameters=params)


def _decompose_helper(process: "Process"):
    from .builder import ProcessBuilder

    builder, initial_ports = ProcessBuilder.from_signature(
        process.signature, immutable=False
    )
    out_ports = process.build_composite(builder=builder, **initial_ports)
    return builder.finalize(**out_ports)


def selection(cls):
    """
    A class decorator to set the cls.selected class variable to False. This is used to denote this process as
    a potentional candidate for branching purposes.
    """
    original_init = cls.__init__

    def new_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self.selected = False

    cls.__init__ = new_init
    return cls


class Process:
    """
    Abstract base class for process models that lays out the basic functionality
    for basic process classes which will inherit from Process and
    are wrapped by Node.

    This class is responsible for:
    1) Storing `inputs` (list of `Data`) and matching them to `expected_input_properties`.
    2) Building or inferring `signature` (left, right data).
    3) Validating input data properties. If mismatches occur, it raises `InitError`.

    Legacy: Constructing a Process requires inheriting from this base class
    and constructing the required methods:
        - "set_expected_input_properties"
        - "set_required_resources"
        - "set_output_properties"
        - "compute_flop_count"
        - "validate_data"
        - "update"
        - "generate_output"


    Notes from legacy (pre- signature/RegisterSpec):
    - the attributes output_properties are only used when connecting
    the output Nodes of one network with the input Nodes of another network. In most
    cases they won't be necessary if the Node/Process are neither input/output
    Nodes of a larger Network. It will be useful to include nevertheless for reuseability.
    """

    UNSTARTED = "UNSTARTED"
    READY = "READY"
    ACTIVE = "ACTIVE"
    COMPLETED = "COMPLETED"

    def __init__(
        self,
        **kwargs,
    ):

        self.inputs: Optional[List[Data]] = kwargs.get("inputs", None)
        self.description: Optional[str] = kwargs.get("description", None)
        self.label: Optional[str] = kwargs.get("label", None)

        self.required_resources: Resource | List[Resource] = kwargs.get(
            "required_resources", []
        )
        self.output_properties: Optional[List[Dict[str, Any]]] = kwargs.get(
            "output_properties", []
        )
        self.expected_input_properties: Optional[List[Dict[str, Any]]] = kwargs.get(
            "expected_input_properties", []
        )

        self.selected: bool = True
        self.dynamic: bool = kwargs.get("dynamic", False)
        self.status: str = Process.UNSTARTED

        self.time_till_completion: float = float("inf")
        #     self._validate_inputs()
        self._signature = None

        # self.shape_env = kwargs.get("shape_env", ShapeEnv())

        if self.inputs != None:
            if not hasattr(self, "input_data"):
                self.input_data = self._build_legacy_input_mapping(self.inputs)
                # logger.debug("Legacy self.input_data automatically generated:")

                # logger.info(pretty_repr(self.input_data))

        if not self.expected_input_properties:
            try:
                self.set_expected_input_properties()
            except NotImplementedError:
                self.expected_input_properties = (
                    self._derive_input_props_from_signature()
                )
        if not self.output_properties:
            try:
                self.set_output_properties()
                # logger.debug(f"Output props provided by Process: {self.output_properties}")
            except NotImplementedError:
                self.output_properties = self.infer_output_properties()
                # logger.debug(f"Infering output from signature: {self.output_properties}")

        # logger.debug(f'{self} provided inputs: {self.inputs}')

        if self.inputs != None:
            if not self.validate_data_properties():
                raise InitError(
                    f"""Input data properties {[input.properties for input in self.inputs]} 
                does not satisfy expected properties: {self.expected_input_properties} 
                for process {self.__class__.__name__}"""
                )

            if not self.required_resources:
                self.set_required_resources()

    @property
    def signature(self) -> Signature:
        """Allow lazy access to the signature."""
        if self._signature is None:
            if self.inputs:
                # logger.debug(f"Building signature for {self}")
                # self._signature = self.build_signature()
                self._signature = Signature.build_from_data(
                    self.inputs, self.output_properties
                )
            else:
                self._signature = Signature.build_from_properties(
                    input_props=self.expected_input_properties,
                    output_props=self.output_properties,
                )
            self.initialized = True
        else:
            pass
            # logger.debug(f"Accessing cached signature for {self}")
        return self._signature

    def decompose(self):
        return _decompose_helper(self)

    def as_composite(self):
        from .builder import ProcessBuilder

        builder, init_ports = ProcessBuilder.from_signature(self.signature)
        # logger.debug(f"As composite operation. Initial ports: {init_ports}")
        return builder.finalize(**builder.add_d(self, **init_ports))

    # --- Helper methods for input mapping and logging ---
    def _build_mappings(self):
        self.input_id_to_spec, self.spec_to_input_id = {}, {}
        self.usage_to_spec, self.spec_to_usage = {}, {}
        self.hint_to_spec = {}
        self.spec_to_hint = {}

        for arg, data_obj in self.normalized_map.items():
            self.input_id_to_spec[data_obj.id] = arg
            self.spec_to_input_id[arg] = data_obj.id

            usage = data_obj.properties.get("Usage")
            if usage:
                self.usage_to_spec[usage] = arg
                self.spec_to_usage[arg] = usage

            hint = None
            if (
                hasattr(data_obj, "metadata")
                and hasattr(data_obj.metadata, "hint")
                and data_obj.metadata.hint
            ):
                hint = data_obj.metadata.hint
            if hint:
                self.hint_to_spec[hint] = arg
                self.spec_to_hint[arg] = hint
            else:
                self.spec_to_hint[arg] = usage

        description = (
            f"{self} initialized with the following map attributes:\n"
            f" - input_id_to_spec: {self.input_id_to_spec} \n"
            f" - spec_to_input_id: {self.spec_to_input_id}\n"
            f" - spec_to_hint: {self.spec_to_hint}\n"
            f" - spec_to_usage: {self.spec_to_usage}\n"
        )
        logger.debug(description)

    def _build_legacy_input_mapping(self, inputs: List[Data]) -> Dict[str, Any]:
        mapping = {}
        for data in inputs:
            usage = data.properties.get("Usage")
            if usage is not None:
                if usage == "Reduction Row":
                    key = usage
                elif "Row Idx" in data.properties:
                    key = f"{usage} {data.properties['Row Idx']}"
                else:
                    key = usage
            else:
                key = data.id
            mapping[key] = data.data
        return mapping

    def _derive_input_props_from_signature(self) -> List[Dict[str, Any]]:
        if self.signature is None:
            return []

        input_props = []
        for regspec in self.signature.lefts():
            print(regspec)

            prop_dict = {
                "Data Type": regspec.dtype,
            }
            input_props.append(prop_dict)
        logger.debug(f" - Infered input props from sig: {input_props}")
        return input_props

    def infer_output_properties(self):
        """
        If no explicit output_properties are set, we try building from the signature’s RIGHT data.
        """
        if self.signature:
            output_signature = self.signature.rights()
            ret = []
            for s in output_signature:
                ret.append({"Data Type": s.dtype})
            return ret
        else:
            return []
        #     if self.inputs is None:
        #         self.inputs = list(self.signature.lefts())
        #     output_signature = self.signature.rights()
        #     return [out.properties for out in output_signature if out.flow == Flow.RIGHT]
        # else:
        #     raise ValueError("Cannot infer outputs without a valid signature")

    # ------------------------------- VALIDATION ------------------------------- #
    def validate_data_properties(self, show_debug_log=False) -> bool:
        """Basic verification that input data has the expected input
        properties
        """

        if len(self.expected_input_properties) == 0:
            return True

        if all(isinstance(elt, dict) for elt in self.expected_input_properties):
            self.inputs_copy = copy.copy(self.inputs)
            result = all(
                self.expected_property_in_inputs(expected_property)
                for expected_property in self.expected_input_properties
            )
        elif all(
            isinstance(elt, (list, tuple)) for elt in self.expected_input_properties
        ):
            assert all(
                isinstance(prop, dict)
                for prop in chain.from_iterable(self.expected_input_properties)
            )

            for valid_properties_option in self.expected_input_properties:
                self.inputs_copy = copy.copy(self.inputs)
                result = all(
                    self.expected_property_in_inputs(expected_property)
                    for expected_property in valid_properties_option
                )
                if result:
                    break
        else:
            raise ValueError(
                f"Expected self.expected_input_properties to be of type list[dict] or list[list[dict]]"
            )

        del self.inputs_copy
        return result

    def get_missing_data_properties(
        self, input_edges: "List[DirectedEdge]"
    ) -> List[dict] | List[List[dict]]:
        if len(self.expected_input_properties) == 0:
            return []

        input_data: List[Data] = []
        for input_edge in input_edges:
            for data in input_edge.data:
                input_data.append(data)

        if all(isinstance(elt, dict) for elt in self.expected_input_properties):
            self.inputs_copy = copy.copy(input_data)
            missing_properties = []
            for expected_property in self.expected_input_properties:
                if not self.expected_property_in_inputs(expected_property):
                    missing_properties.append(expected_property)

            received_properties = [
                {"Data Type": type(data.data)} | data.properties
                for data in self.inputs_copy
            ]
            missing_properties = {
                "Expected": missing_properties,
                "Received": received_properties,
            }

        elif all(
            isinstance(elt, (list, tuple)) for elt in self.expected_input_properties
        ):
            assert all(
                isinstance(prop, dict)
                for prop in chain.from_iterable(self.expected_input_properties)
            )

            missing_properties = []
            for valid_properties_option in self.expected_input_properties:
                self.inputs_copy = copy.copy(input_data)
                missing_properties_option = []
                for expected_property in valid_properties_option:
                    if not self.expected_property_in_inputs(expected_property):
                        missing_properties_option.append(expected_property)

                received_properties = [
                    {"Data Type": type(data.data)} | data.properties
                    for data in self.inputs_copy
                ]
                missing_properties.append(
                    [
                        {
                            "Expected": missing_properties_option,
                            "Received": received_properties,
                        }
                    ]
                )
        else:
            raise ValueError(
                f"Expected self.expected_input_properties to be of type list[dict] or list[list[dict]]"
            )

        del self.inputs_copy
        return missing_properties

    def expected_property_in_inputs(self, expected_property: dict) -> bool:
        concrete_inputs = list(self.inputs_copy or [])
        for data in list(concrete_inputs):
            if all(
                any_dict1_vals_in_dict2_vals(data.properties.get(key, None), val)
                for key, val in expected_property.items()
            ):
                self.inputs_copy.remove(
                    data
                )  ##Needed in case expected_input_properties has multiple copies of the same property
                return True
        return False

    # --- Abstract methods to be implemented/overwritten by subclasses ---
    def set_required_resources(self):
        """Sets the appropriate resources required to run the process. This method should update
        self.required_resources to be a list of Resources required for the Process to successfully run.
        Will be unique for each process.
        """

        raise NotImplementedError

    def set_expected_input_properties(self):
        """Sets the expected input properties of the Process to execute/update successfully.
        This method should update self.expected_input_properties to be a list of dictionaries, with each
        dictionary specifying the expected properties of an input Data instance. A Process that requires
        N inputs will require N such dictionaries specifying its properties. Will be unique to each Process.
        """

        raise NotImplementedError

    def set_output_properties(self):
        """Sets the expected properties of the generated outputs of the Process.
        This method should update self.output_properties to be a list of dictionaries,
        with each dictionary specifying the expected properties of each output Data
        """

        pass

    def validate_data(self) -> bool:
        """Process specific verification that ensures input data has
        correct specifications. Will be unique to each process
        """

        raise NotImplementedError

    def update(self):

        raise NotImplementedError

    def generate_output(self) -> List["Data"]:
        """After completing updates, the process will wrap its results
        and return a (unordered) set of Data states to be processed by Node.
        The expected output will be unique to the process.
        """

        raise NotImplementedError

    def set_required_resources(self):
        """Default: No resources required."""
        self.required_resources = []

    def build_composite(self, builder, **ports):
        """
        Override this method to define a process in terms of its atomic parts

        Args:
            builder (`ProcessBuilder`): A `ProcessBuilder` instance to append sub-processes to
            **ports (`PortT`): The initial `Port` (or array-like of ports) corresponding to the inputs
            of the process
        Returns:
            The ports corresponding to the outputs of the process (keyed by name)
        """
        raise NotImplementedError(f"{self} has no decomposition.")

    def extend_network(self) -> "Node" | List["Node"] | "Network":
        """Initializes and returns the list of Nodes this instance would connect to
        in the Network. These Nodes are generated during Network.run() to allow
        initialization of Nodes that depend on input values.
        """
        raise NotImplementedError

    def __repr__(self):
        return self.__class__.__name__

    @property
    def describe(self):
        if self.status == Process.COMPLETED:
            description = (
                f"Process: {self}\n"
                # f"inputs: {self.inputs}; outputs: {self.generate_output()}\n"
                f"inputs: {self.inputs}\n"
                f"status: {self.status}\n"
                f"dyn: {self.dynamic}\n"
            )
        else:
            description = (
                f"Process: {self}\n"
                f"inputs: {self.inputs}\n"
                f"status: {self.status}\n"
                f"dyn: {self.dynamic}\n"
            )
        # logger.debug(description)
        print(description)


class ClassicalProcess(Process):
    def __init__(
        self,
        inputs=None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        description=None,
        label=None,
        dynamic=False,
        shape_env=None,
    ):
        super().__init__(
            inputs=inputs,
            expected_input_properties=expected_input_properties,
            required_resources=required_resources,
            output_properties=output_properties,
            description=description,
            label=label,
            dynamic=dynamic,
            shape_env=shape_env,
        )
        if inputs != None:
            self.flops = self.compute_flop_count()

    def compute_flop_count(self) -> int:
        """Computes the number of required flops for this process to complete given
        valid inputs from self.inputs. Will be unique to each Process.
        """

        raise NotImplementedError

    def _compute_classical_process_update_time(
        self, allocations: dict["Resource", "DeviceAllocation"]
    ) -> float:

        try:
            (allocation,) = allocations.values()
        except ValueError:
            raise ValueError(
                f"Expected a single allocation/resource for ClassicalProcess, multiple resource requests are currently unsupported"
            )

        assert (
            self.flops >= 0
        ), f"Required flop counts for {self.__class__.__name__} is negative! Please check compute_flop_count to ensure non-negative flops."
        if self.required_resources is None:
            time_till_completion = 0
        else:
            time_till_completion = self.flops / allocation.clock_frequency
        # logger.debug(f'{repr(self)} requires {self.flops} (clock_freq={ allocation.clock_frequency:.2e})\n      --> time until completion set to: {time_till_completion:.2e}')
        return time_till_completion

    def get_process_duration(self, device: "ClassicalDevice") -> float:
        assert (
            type(device).__name__ == "ClassicalDevice"
        ), f"Attempting to compute process duration of a ClassicalProcess on a {type(device).__name__}"
        duration = self.flops / device.clock_frequency
        return duration


class QuantumProcess(Process):
    def __init__(
        self,
        inputs=None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        description=None,
        shots=1,
        dynamic=False,
        shape_env=None,
    ):
        super().__init__(
            inputs=inputs,
            expected_input_properties=expected_input_properties,
            required_resources=required_resources,
            output_properties=output_properties,
            description=description,
            dynamic=dynamic,
            shape_env=shape_env,
        )

        self.shots = shots
        # if inputs != None:
        #     self.circuit: "QuantumCircuit" = self.compute_circuit()

    def compute_circuit(self) -> int:
        """Computes the number of required flops for this process to complete given
        valid inputs from self.inputs. Will be unique to each Process.
        """

        raise NotImplementedError

    def __connectivity_contains_attributes(
        self, device: "QuantumDevice", qubit_indices: List[int] = None
    ):
        return self.__contain_single_qubit_attributes(
            device, qubit_indices
        ) and self.__contain_two_qubit_attributes(device, qubit_indices)

    def __contain_single_qubit_attributes(
        self, device: "QuantumDevice", qubit_indices: List[int] = None
    ):
        connectivity = device.connectivity
        if qubit_indices is None:
            qubit_indices = list(connectivity.nodes())

        single_qubit_gates = [
            gate for gate in device.gate_set if gate in SINGLE_QUBIT_GATES
        ]

        contains_attributes = True
        for gate in single_qubit_gates:
            for qubit_idx in qubit_indices:
                if gate not in connectivity.nodes[qubit_idx].keys():
                    contains_attributes = False
        return contains_attributes

    def __contain_two_qubit_attributes(
        self, device: "QuantumDevice", qubit_indices: List[int] = None
    ):
        connectivity = device.connectivity
        if qubit_indices is None:
            qubit_indices = list(connectivity.nodes())

        two_qubit_gates = [gate for gate in device.gate_set if gate in TWO_QUBIT_GATES]
        edges = list(connectivity.subgraph(qubit_indices).edges())

        contains_attributes = True
        for gate in two_qubit_gates:
            for q1, q2 in edges:
                if gate not in connectivity[q1][q2].keys():
                    contains_attributes = False
        return contains_attributes

    def _compute_quantum_process_update_time(
        self, allocations: dict["Resource", "QDeviceAllocation"]
    ) -> float:

        try:
            (allocation,) = allocations.values()
        except ValueError:
            raise ValueError(
                f"Expected a single allocation/resource for QuantumProcess, multiple resource requests are currently unsupported"
            )

        if allocation.T_count is not None:
            assert isinstance(allocation.T_count, int)
            num_qubits = len(allocation.allocated_qubit_idxs)
            return allocation.T_count * allocation.device.T_gate_time / (num_qubits - 2)

        elif isinstance(allocation.transpiled_circuit, QiskitQuantumCircuit):
            time_till_completion = {
                qubit_idx: 0 for qubit_idx in allocation.allocated_qubit_idxs
            }
            qc = allocation.transpiled_circuit

            if self.__connectivity_contains_attributes(
                allocation.device, allocation.allocated_qubit_idxs
            ):
                for instruction in qc.data:
                    gate_name = instruction.operation.name.upper()
                    qubit_idxs = [qc.find_bit(q).index for q in instruction.qubits]

                    if len(qubit_idxs) == 1:
                        time_till_completion[
                            qubit_idxs[0]
                        ] += allocation.device_connectivity.nodes[qubit_idxs[0]][
                            gate_name
                        ][
                            "Duration"
                        ]

                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time
                            + allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Duration"]
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time
                            + allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Duration"]
                        )
                    else:
                        raise NotImplementedError(
                            f"3+ qubit gates are currently unsupported"
                        )
            else:
                single_qubit_duration = allocation.device.singleQ_time
                two_qubit_duration = allocation.device.doubleQ_time

                for instruction in qc.data:
                    qubit_idxs = [qc.find_bit(q).index for q in instruction.qubits]

                    if len(qubit_idxs) == 1:
                        time_till_completion[qubit_idxs[0]] += single_qubit_duration
                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time + two_qubit_duration
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time + two_qubit_duration
                        )

            return max(time_till_completion.values()) * 1e-9

        elif isinstance(allocation.transpiled_circuit, QuantumCircuit):
            time_till_completion = {
                qubit_idx: 0 for qubit_idx in allocation.allocated_qubit_idxs
            }
            qc = allocation.transpiled_circuit

            if self.__connectivity_contains_attributes(
                allocation.device, allocation.allocated_qubit_idxs
            ):
                for instruction in qc.instructions:
                    gate_name = instruction.gate.name.upper()
                    qubit_idxs = instruction.gate_indices

                    if len(qubit_idxs) == 1:
                        time_till_completion[
                            qubit_idxs[0]
                        ] += allocation.device_connectivity.nodes[qubit_idxs[0]][
                            gate_name
                        ][
                            "Duration"
                        ]

                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time
                            + allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Duration"]
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time
                            + allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Duration"]
                        )
                    else:
                        raise NotImplementedError(
                            f"3+ qubit gates are currently unsupported"
                        )
            else:
                single_qubit_duration = allocation.device.singleQ_time
                two_qubit_duration = allocation.device.doubleQ_time

                for instruction in qc.instructions:
                    qubit_idxs = instruction.gate_indices

                    if len(qubit_idxs) == 1:
                        time_till_completion[qubit_idxs[0]] += single_qubit_duration
                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time + two_qubit_duration
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time + two_qubit_duration
                        )

            return max(time_till_completion.values()) * 1e-9

        else:
            raise ValueError(
                f"Expected allocation.transpiled_circuit of type QuantumCircuit or QiskitQuantumCircuit but got {type(allocation.transpiled_circuit)} instead."
            )

    def get_process_duration(self, device: "QuantumDevice") -> float:

        assert (
            type(device).__name__ == "QuantumDevice"
        ), f"Attempting to compute process duration of a QuantumProcess on a {type(device).__name__}"

        try:
            (requested_resource,) = self.required_resources
        except ValueError:
            raise ValueError(
                f"QuantumProcess {self} requesting 2 or more Resources is currently unsupported"
            )

        requested_resource: "QuantumResource"
        if requested_resource.T_gates is not None:

            assert isinstance(requested_resource.T_gates, int)
            return (
                requested_resource.T_gates
                * device.T_gate_time
                / (device.num_qubits - 2)
            )

        else:
            gate_set = [gate.lower() for gate in device.gate_set if gate != "I"]
            coupling_map = CouplingMap(list(device.connectivity.edges()))
            transpiled_circuit: QiskitQuantumCircuit = transpile(
                requested_resource.circuit,
                basis_gates=gate_set,
                coupling_map=coupling_map,
            )
            qubit_indices = [
                transpiled_circuit.find_bit(q).index for q in transpiled_circuit.qubits
            ]

            time_till_completion = {
                qubit_idx: 0.0 for qubit_idx in range(transpiled_circuit.num_qubits)
            }

            if self.__connectivity_contains_attributes(device, qubit_indices):
                for instruction in transpiled_circuit.data:
                    gate_name = instruction.operation.name.upper()
                    qubit_idxs = [
                        transpiled_circuit.find_bit(q).index for q in instruction.qubits
                    ]

                    if len(qubit_idxs) == 1:
                        time_till_completion[
                            qubit_idxs[0]
                        ] += device.connectivity.nodes[qubit_idxs[0]][gate_name][
                            "Duration"
                        ]

                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time
                            + device.connectivity[qubit_idxs[0]][qubit_idxs[1]][
                                gate_name
                            ]["Duration"]
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time
                            + device.connectivity[qubit_idxs[0]][qubit_idxs[1]][
                                gate_name
                            ]["Duration"]
                        )
                    else:
                        raise NotImplementedError(
                            f"3+ qubit gates are currently unsupported"
                        )
            else:
                single_qubit_duration = device.singleQ_time
                two_qubit_duration = device.doubleQ_time

                for instruction in transpiled_circuit.data:
                    qubit_idxs = [
                        transpiled_circuit.find_bit(q).index for q in instruction.qubits
                    ]

                    if len(qubit_idxs) == 1:
                        time_till_completion[qubit_idxs[0]] += single_qubit_duration
                    elif len(qubit_idxs) == 2:
                        current_time = max(
                            time_till_completion[qubit_idxs[0]],
                            time_till_completion[qubit_idxs[1]],
                        )
                        time_till_completion[qubit_idxs[0]] = (
                            current_time + two_qubit_duration
                        )
                        time_till_completion[qubit_idxs[1]] = (
                            current_time + two_qubit_duration
                        )

            return max(time_till_completion.values()) * 1e-9

    def _compute_sucess_probability(self, allocation: "QDeviceAllocation") -> float:
        success_probability = 1.0

        if allocation.T_count is not None:
            assert isinstance(allocation.T_count, int)
            for _ in range(allocation.T_count):
                success_probability *= allocation.device.T_fidelity
            return success_probability
        elif isinstance(allocation.transpiled_circuit, QiskitQuantumCircuit):
            qc = allocation.transpiled_circuit

            if self.__connectivity_contains_attributes(
                allocation.device, allocation.allocated_qubit_idxs
            ):
                for instruction in qc.data:
                    gate_name = instruction.operation.name.upper()
                    qubit_idxs = [qc.find_bit(q).index for q in instruction.qubits]

                    if len(qubit_idxs) == 1:
                        success_probability *= (
                            1
                            - allocation.device_connectivity.nodes[qubit_idxs[0]][
                                gate_name
                            ]["Error"]
                        )
                    elif len(qubit_idxs) == 2:
                        success_probability *= (
                            1
                            - allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Error"]
                        )
                    else:
                        raise NotImplementedError(
                            f"3+ qubit gates are currently unsupported"
                        )

            else:
                single_qubit_error = allocation.device.singleQ_error
                two_qubit_error = allocation.device.doubleQ_error

                for instruction in qc.data:
                    qubit_idxs = [qc.find_bit(q).index for q in instruction.qubits]

                    if len(qubit_idxs) == 1:
                        success_probability *= 1 - single_qubit_error
                    elif len(qubit_idxs) == 2:
                        success_probability *= 1 - two_qubit_error

            return success_probability

        elif isinstance(allocation.transpiled_circuit, QuantumCircuit):
            qc = allocation.transpiled_circuit

            if self.__connectivity_contains_attributes(
                allocation.device, allocation.allocated_qubit_idxs
            ):
                for instruction in qc.instructions:
                    gate_name = instruction.gate.name.upper()
                    qubit_idxs = instruction.gate_indices

                    if len(qubit_idxs) == 1:
                        success_probability *= (
                            1
                            - allocation.device_connectivity.nodes[qubit_idxs[0]][
                                gate_name
                            ]["Error"]
                        )
                    elif len(qubit_idxs) == 2:
                        success_probability *= (
                            1
                            - allocation.device_connectivity[qubit_idxs[0]][
                                qubit_idxs[1]
                            ][gate_name]["Error"]
                        )
                    else:
                        raise NotImplementedError(
                            f"3+ qubit gates are currently unsupported"
                        )
            else:
                single_qubit_error = allocation.device.singleQ_error
                two_qubit_error = allocation.device.doubleQ_error

                for instruction in qc.instructions:
                    qubit_idxs = instruction.gate_indices

                    if len(qubit_idxs) == 1:
                        success_probability *= 1 - single_qubit_error
                    elif len(qubit_idxs) == 2:
                        success_probability *= 1 - two_qubit_error

            return success_probability

        else:
            raise ValueError(
                f"Expected allocation.transpiled_circuit of type QuantumCircuit or QiskitQuantumCircuit but got {type(allocation.transpiled_circuit)} instead."
            )


class Task(Process):
    def __init__(
        self,
        inputs=None,
        expected_input_properties=None,
        required_resources=None,
        output_properties=None,
        description=None,
        label=None,
        dynamic=False,
        shape_env=None,
    ):
        super().__init__(
            inputs=inputs,
            expected_input_properties=expected_input_properties,
            required_resources=required_resources,
            output_properties=output_properties,
            description=description,
            label=label,
            dynamic=dynamic,
            shape_env=shape_env,
        )
        if inputs != None:
            self.duration = self.compute_task_duration()

    def compute_task_duration(self) -> float:
        """Computes the amount of time in seconds to successfully execute this Task given
        valid inputs from self.inputs. Will be unique to each Task.
        """

        raise NotImplementedError

    def get_process_duration(self, device: "Personnel | Equipment" = None) -> float:
        ###TODO: Update this with device specific duration dependencies

        return self.duration


def normalize_process_call(
    target: Callable,
    args: Tuple[Any, ...],
    kwargs: Optional[Dict[str, Any]] = None,
    *,
    arg_types: Optional[Tuple[Any, ...]] = None,
    kwarg_types: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    A unified function that attempts to "bind" user inputs to either:
        (1) A Process subclass's signature (like MatrixMult)
        (2) A torch operator (like torch.add)
        (3) A normal Python function
    Returns a dictionary {param_name -> actual_argument} if successful,
    or raises an error if the binding fails.

    1. If 'target' is an instance of Process, we:
       - Build an inspect.Signature from 'process.signature'
       - Attempt signature.bind(*args, **kwargs)
       - Validate each input Data with the RegisterSpecs
       - Return {param_name: Data}

    2. If 'target' is a torch op (OpOverload/OpOverloadPacket) or a BuiltinFunctionType,
       we use `get_signature_for_torch_op(...)` to retrieve schemas. We do a first pass to see
       which schemas can bind the real arguments, then if multiple match, use `arg_types/kwarg_types`
       to disambiguate. Finally, we do a `bound = chosen_sig.bind(*args, **kwargs)` and return
       `dict(bound.arguments)` so that param names match e.g. ("input", "other").

    3. Otherwise, fallback to a normal Python function check with inspect.signature(target).

    NOTE: This merges the advanced multiple-dispatch logic in operator_schemas.py
    with your custom logic for Process. We skip `inspect.signature` for built-in ops
    to avoid "no signature found" errors.

    Args:
        target (Union[Process, callable]): The function or Process object
        args (Tuple[Any]): The positional args
        kwargs (Optional[Dict[str, Any]]): The keyword args
        arg_types (Optional[Tuple[Any]]): Additional type hints for disambiguation
        kwarg_types (Optional[Dict[str, Any]]): Additional type hints for disambiguation

    Returns:
        A dict {param_name -> Data or python object} with resolved inputs, or raises an error.
    """
    import inspect
    import re
    import types
    from typing import Any, Dict, Tuple, Optional, Callable

    if kwargs is None:
        kwargs = {}
    normalized_data: Dict[str, Any] = {}

    from torch._library.infer_schema import infer_schema

    # print(infer_schema)

    # (1) If target is a Process => build an inspect.Signature from process signature
    if isinstance(target, Process):
        fx_sig = build_inspect_signature_from_process_signature(target.signature)

        param_names = [p.name for p in target.signature.lefts()]
        # logger.debug(f'Process {target} with param names: {param_names}')
        # Attempt to bind
        args_for_bind = [d.data for d in args]  # or just 'args' if they're Data
        kwargs_for_bind = {
            k: (v.data if hasattr(v, "data") else v) for k, v in kwargs.items()
        }
        try:
            bound = fx_sig.bind(*args_for_bind, **kwargs_for_bind)
            bound.apply_defaults()
        except TypeError as te:
            matchobj = re.search(r"missing a required argument: '(.*?)'", str(te))
            if matchobj:
                missing_param = matchobj.group(1)
                raise ValueError(f"Missing data for parameter {missing_param}") from te
            raise ValueError(
                f"Failed to bind arguments to Process {target}: {te}"
            ) from te
        # Reconstruct param_name -> original Data
        param_list = list(fx_sig.parameters.keys())
        used_positional_count = len(bound.args)
        for idx, pname in enumerate(param_list):
            if idx < used_positional_count:
                data_obj = args[idx]
            else:
                data_obj = kwargs.get(pname, None)
            if data_obj is None:
                raise ValueError(f"Missing data for parameter {pname}")

            normalized_data[pname] = data_obj
            # logger.debug(f"{pname}: {data_obj}")
            # print(pname, type(data_obj))

        # Additional typed checks using the process's signature
        # e.g. 'signature.validate_data_with_register_specs(inputs)'
        # or your own logic with regspec.matches_data
        # for k,v in normalized_data.items():
        #     logger.debug(f"{k}: {v} of type {type(v)}")

        target.signature.validate_data_with_register_specs(
            [normalized_data[p.name] for p in target.signature.lefts()]
        )
        return normalized_data

    # (2) If target is a torch op => do advanced schema approach, skip normal signature fallback
    from torch.fx.operator_schemas import (
        get_signature_for_torch_op,
        OpOverload,
        OpOverloadPacket,
    )

    if (
        isinstance(target, OpOverloadPacket)
        or isinstance(target, OpOverload)
        or isinstance(target, types.BuiltinFunctionType)
    ):
        torch_op_sigs = get_signature_for_torch_op(target)
        if not torch_op_sigs:
            # No known signatures => can't bind
            raise ValueError(f"No signature found for PyTorch op: {target}")

        # 2.1) Try to find *all* matches by attempting sig.bind(*args, **kwargs)
        matched_schemas = []
        for candidate_sig in torch_op_sigs:
            try:
                candidate_sig.bind(*args, **kwargs)
                matched_schemas.append(candidate_sig)
            except TypeError:
                continue

        if len(matched_schemas) == 0:
            # No valid schema matched => can't unify
            raise ValueError(
                f"No valid overload for {target} with arguments={args}, kwargs={kwargs}"
            )
        elif len(matched_schemas) == 1:
            # Exactly one match => perfect
            chosen_sig = matched_schemas[0]
        else:
            # Multiple matches => we need arg_types/kwarg_types to break ties
            if not arg_types and not kwarg_types:
                # Raise an error for ambiguity
                raise ValueError(
                    f"Ambiguous call to {target}. Multiple overloads matched, "
                    "and you did not provide arg_types/kwarg_types to disambiguate."
                )

            # 2.2) Second pass: do type-based filtering
            # We'll see which schemas match your provided param-type hints
            # We require that every param name's type passes type_matches().
            filtered = []
            for candidate_sig in matched_schemas:
                try:
                    # We'll do a parallel "bind" but with arg_types instead of real values
                    bound_type_check = candidate_sig.bind(
                        *(arg_types or ()), **(kwarg_types or {})
                    )
                except TypeError:
                    continue

                all_good = True
                for name, user_type in bound_type_check.arguments.items():
                    param = candidate_sig.parameters[name]
                    if param.annotation is not inspect.Parameter.empty:
                        if not type_matches(param.annotation, user_type):
                            all_good = False
                            break
                    # else no annotation => ignore
                if all_good:
                    filtered.append(candidate_sig)

            if len(filtered) == 0:
                raise ValueError(
                    f"Could not find a matching schema for {target} even after "
                    f"type-based disambiguation. arg_types={arg_types} kwarg_types={kwarg_types}"
                )
            elif len(filtered) > 1:
                raise ValueError(
                    f"Still ambiguous: multiple overloads match the provided arg_types={arg_types} "
                    f"and kwarg_types={kwarg_types} for {target}. Overloads: {filtered}"
                )
            else:
                chosen_sig = filtered[0]

        # Finally, we have a single chosen_sig => do a final bind
        bound = chosen_sig.bind(*args, **kwargs)
        bound.apply_defaults()
        return dict(bound.arguments)

    # (3) If not a Process or a torch op => fallback to normal Python signature
    sig = inspect.signature(inspect.unwrap(target))
    bound = sig.bind(*args, **kwargs)
    bound.apply_defaults()
    return dict(bound.arguments)
