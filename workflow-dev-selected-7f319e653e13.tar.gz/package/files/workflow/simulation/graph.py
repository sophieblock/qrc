"""

This file contains class definitions for a directed acyclic graph
(DAG) data structure for workflow resource estimation. Individual
tasks and processes are contained in their respective Nodes which
are connected with DirectedEdges. Nodes contain the Process necessary
for executing and updating the subtask. DirectedEdges contain the
relevant input/output data that is passed along the Network.
"""

from __future__ import annotations
from typing import List, Tuple, Dict
from collections import OrderedDict, deque, Counter
import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd
import copy
from numpy import inf as INFINITY
import numpy as np
from itertools import chain
import plotly.express as px
import plotly.graph_objects as go
from functools import singledispatchmethod
import math


from .process import Process, ClassicalProcess, QuantumProcess, Task, InitError
from .resources.resources import Allocation, Resource
from .resources.classical_device import DeviceAllocation, ClassicalResource
from .resources.quantum_device import QDeviceAllocation, QuantumResource
from .resources.equipment import EquipmentAllocation, EquipmentResource
from .resources.personnel import PersonnelAllocation, PersonnelResource, Personnel
from .resources.q_interop.qiskit_interop import count_gates
from .resources.q_interop.qiskit_interop import count_gates
from .broker import Broker, IncompatibleDevicesError
from .data import Data, Result
from .dataframe import SimulationResults
from .utilities import (
    get_next_id,
    all_dict1_vals_in_dict2_vals,
    any_dict1_vals_in_dict2_vals,
    publish_gantt,
)

import datetime
import logging
import warnings

logger: logging.Logger = logging.getLogger(__name__)


class DirectedEdge:
    """The "directed edge" connecting Nodes in a DAG. A DirectedEdge
    may have up to one source node and any number of destination nodes
    but must be connected to atleast one node at any given instance.
    The DirectedEdge class contains and propagates the necessary
    Data for Node execution and additional information regarding
    its connectivity and status. DirectedEdges with multiple destination
    nodes propagate the same Data to all destination nodes.
    """

    def __init__(
        self,
        data=None,
        source_node=None,
        dest_nodes=None,
    ):

        if data != None:
            assert isinstance(
                data, tuple
            ), f"DirectedEdge may only accept data as tuples"
        self.data: Tuple[Data] = data
        self.source_node: Node = source_node
        self.dest_nodes: list[Node] = dest_nodes or []

    def update_data(self, data):
        self.data = data if isinstance(data, tuple) else (data,)

    def update_source_node(self, new_source):
        self.source_node = new_source

    def insert_destination_node(self, new_dest_node):
        if new_dest_node not in self.dest_nodes:
            self.dest_nodes.append(new_dest_node)

    def remove_destination_node(self, dest_node):
        self.dest_nodes.remove(dest_node)

    def edge_type(self):
        if self.source_node is None:
            return "INPUT"
        elif len(self.dest_nodes) == 0:
            return "OUTPUT"
        elif self.source_node is None and len(self.dest_nodes) == 0:
            return "FLOATING"
        else:
            return "CONNECTED"

    def __add__(self, other):
        assert (
            self.source_node == other.source_node
        ), f"Directed edges {self} and {other} do not have the same source node"
        assert (
            self.dest_nodes == other.dest_nodes
        ), f"Directed edges {self} and {other} do not have the same destination node"

        return DirectedEdge(
            data=self.data + other.data,
            source_node=self.source_node,
            dest_nodes=self.dest_nodes,
        )

    def __repr__(self) -> str:
        usage_list = (
            [d.properties.get("Usage", "?") for d in self.data] if self.data else []
        )
        return f"{self.edge_type()} Edge: {repr(self.source_node)} -- {usage_list} -> {self.dest_nodes if self.dest_nodes else None}"


class ExpectedNodeError(Exception):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class EdgeAssignmentError(Exception):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class Node:
    """Represents, stores and manages information on the most basic process/task
    of the larger network. Wraps and runs the entire process of verifying, simulating and
    storing data for the given process. Can be aggregated along with Edges to form a larger
    Network specifying a larger, more complex and fixed algorithm class.
    """

    def __init__(
        self,
        id=None,
        process_model=None,
        input_edges=None,
        output_edges=None,
        output_nodes=None,
        extend_dynamic=False,
        **kwargs,
    ):
        """
        Args:
            id (str, optional): id of the Node, constructed using get_next_id() if not specified. Defaults to None.
            process_model (Process, optional): The process model this Node simulates. Defaults to None.
            network_type (str, optional): Type of Node inside a larger Network, can be INPUT, NETWORK or OUTPUT. Defaults to None.
            input_edges (List[DirectedEdge], optional): List of incoming DirectedEdges to the Node. Defaults to [].
            output_edges (List[DirectedEdge], optional): List of outgoing DirectedEdges from the Node. Defaults to [].
            output_nodes (List[Nodes], optional): List of Nodes to send the process results to. Defaults to [].
        """

        self.id: str = id or get_next_id()
        self.model: Process = process_model
        self.process: Process = process_model(**kwargs) if self.model != None else None
        self.input_edges: List[DirectedEdge] = input_edges or []
        self.output_edges: List[DirectedEdge] = output_edges or []
        self.output_nodes: List[Node] = output_nodes or []
        self.allocation: dict[Resource, Allocation] = None
        self.extend_dynamic = extend_dynamic
        self.kwargs = kwargs

        if isinstance(self.process, Process):
            self.expected_input_properties = self.process.expected_input_properties

    def is_process_initialized(self) -> bool:
        """
        Returns True if self.process is fully constructed with a signature
        and ephemeral rename pass is (likely) done. This is a heuristic
        that checks several common fields:
        1) self.process is not None
        2) self.process.signature is built
        3) ephemeral rename pass is done
            (e.g. if final usage-based name is in self.process.normalized_map)
        """
        if not self.process:
            return False

        # If the user’s ephemeral rename pass sets self._signature
        # and modifies self.normalized_map, check they exist
        if not hasattr(self.process, "initialized"):

            return False
        rights = list(self.process.signature.rights())
        logger.debug(f"{self} with right registers: {rights}")
        return True

    def append_input_edge(self, edge: DirectedEdge):
        assert (
            not edge in self.input_edges
        ), f"Edge {edge} already exists as an input edge to Node {self.id}"
        assert (
            self in edge.dest_nodes
        ), f"Cannot append Edge to Node {self} that is assigned to {edge.dest_nodes}"
        self.input_edges.append(edge)

    def extend(self, val: "Node" | "Network"):
        if isinstance(val, Node):
            self.insert_output_node(val)
        elif isinstance(val, Network):
            self.extend_network(val)
        else:
            raise ValueError(
                f"Expected Node or Network type, but got {type(val).__name__} instead"
            )

    def insert_output_node(self, output_node):
        assert isinstance(output_node, Node), f"{output_node} must be a Node object"

        if output_node in self.output_nodes:
            return
        self.output_nodes.append(output_node)

    ### TODO: Connects current node to ALL network.input_nodes
    def extend_network(self, network: "Network"):
        assert isinstance(network, Network), f"{network} must be a Network object"

        for node in network.input_nodes:
            self.insert_output_node(node)

    ### TODO: Implement
    def check_if_previously_completed(self) -> bool:
        if self.output_edges != [] and all(
            output.status == DirectedEdge.COMPLETED for output in self.output_edges
        ):
            return True
        return False

    def initialize(self):
        """Prepares the Node for process execution. This method
        validates the incoming data, initializes the specified Process
        and maps empty, INCOMPLETE DirectedEdges to its output_nodes.

        Should only start when the desired list of output_nodes are
        fully specified, otherwise outgoing DirectedEdges will not
        map correctly.
        """

        self.__initialize_process_with_inputs()
        assert (
            self.process.validate_data()
        ), f"Errror node {repr(self)}: Invalid input data for process {str(self.process)} with inputs: {[d for d in self.process.inputs]}"

        self.start_time = datetime.datetime.now()
        self.total_duration = 0.0
        # logger.debug(f"\nStarting node {repr(self)} with inputs: {[d for d in self.process.inputs]}")
        # logger.debug(f"Starting node {self.id} at t={self.start_time}")

    def check_if_ready(self):
        """
        checks if this node is ready to start or not

        This method should evaluate the node inputs (list of Data instances)
        against the process.signature (i.e. the RegisterSpec's). If correct,
        then the node should be marked for starting.
        Returns True if this Node’s incoming Data satisfy its Process’s
        expected_input_properties (via validate_data_properties), False otherwise.
        Does not raise; simply peeks at validity.
        """
        # 1) gather all Data from incoming edges
        inputs = [d for edge in self.input_edges for d in edge.data]

        # 2) temporarily assign into the existing process and test
        orig_inputs = self.process.inputs
        self.process.inputs = inputs
        try:
            ok = self.process.validate_data_properties(show_debug_log=False)
        except InitError:
            ok = False
        # 3) restore
        self.process.inputs = orig_inputs
        return ok

    def ensure_ready(self):
        """
        Validates inputs by actually instantiating the Process.
        On success, it replaces self.process with the new instance,
        sets its status to Process.READY, and returns None.
        On failure, it propagates the InitError with full mismatch detail.
        """
        # 1) gather all Data
        inputs = [d for edge in self.input_edges for d in edge.data]

        # 2) inject into our existing process and run the verbose check
        self.process.inputs = inputs
        # First, perform the lightweight boolean validation. If it fails,
        # fall back to the verbose variant which will raise an InitError
        # with detailed mismatch diagnostics.
        ok = self.process.validate_data_properties(show_debug_log=True)
        if not ok:
            # Verbose path expected to raise InitError; if for some reason it
            # returns False without raising, we raise a generic InitError.
            try:
                self.process.validate_data_properties_verbose(show_debug_log=True)
            except InitError:
                raise
            else:
                raise InitError(
                    "Input data properties validation failed (ensure_ready)."
                )

        # 3) mark ready
        self.process.status = Process.READY

    def ready_to_start(self):
        input_data: List[Data] = []
        for input_edge in self.input_edges:
            for data in input_edge.data:
                input_data.append(data)

        if all(
            isinstance(prop, dict) for prop in self.process.expected_input_properties
        ):
            try:
                process = self.model(inputs=input_data, **self.kwargs)
                valid_inputs = process.validate_data()
                is_ready = valid_inputs

            except InitError as e:
                is_ready = False

        elif all(
            isinstance(elt, (list, tuple))
            for elt in self.process.expected_input_properties
        ):
            try:
                process = self.model(inputs=input_data, **self.kwargs)
                valid_inputs = process.validate_data()
                is_ready = valid_inputs
            except InitError as e:
                is_ready = False

        else:
            raise ValueError(
                "Expected self.expected_input_properties to be of type list[dict] or list[list[dict]]"
            )

        return is_ready and self.process.selected

    def __initialize_process_with_inputs(self):
        """Aggregates data from incoming DirectedEdges and initializes the Process object"""
        if self.process.status == "ACTIVE":
            raise AssertionError(
                f"ERROR: Attempting to initialize node {str(self)} but is already being executed in the network"
            )
        elif self.process.status == "COMPLETED":
            raise AssertionError(
                f"ERROR: Attempting to initialize node {str(self)} but has already been executed in the network"
            )

        input_data = []
        for input_edge in self.input_edges:
            for data in input_edge.data:
                input_data.append(data)

        selected = self.process.selected
        self.process = self.model(inputs=input_data, **self.kwargs)
        self.process.selected = selected
        # del self.model

    def execute_process(self, timestep: float):
        """Simulates the wrapped process entirely. The execute assuming:

        1. Given inputs are valid for the process
        2. Resources are allocated by the broker
        #"""

        assert (
            self.process.status == Process.ACTIVE
        ), f"Node {self.id} cannot execute it's process with status {self.process.status}"

        self.process.time_till_completion = self.process.time_till_completion - timestep
        assert (
            self.process.time_till_completion >= 0.0
        ), f"{self} has negative time till completion of process execution"

        if self.process.time_till_completion == 0.0:
            # self.process.update()
            self.process.status = Process.COMPLETED

    def verify_allocation(self) -> bool:
        if self.process.required_resources is None:
            return True

        required_resources = (
            self.process.required_resources
            if isinstance(self.process.required_resources, list)
            else [self.process.required_resources]
        )

        assert all(
            resource in self.allocation.keys() for resource in required_resources
        ), f"One or more required resources missing from allocation"
        assert len(self.allocation.keys()) == len(required_resources)

        verified_allocation = True
        for resource, allocation in self.allocation.items():
            if isinstance(resource, ClassicalResource):
                assert isinstance(
                    allocation, DeviceAllocation
                ), f"Expected DeviceAllocation for ClassicalResource requirement but got {type(allocation).__name__} instead"

                conditions = (
                    resource.memory <= allocation.allocated_memory,
                    resource.num_cores <= allocation.allocated_cores,
                )

            elif isinstance(resource, QuantumResource):
                assert isinstance(
                    allocation, QDeviceAllocation
                ), f"Expected QDeviceAllocation for QuantumResource requirement but got {type(allocation).__name__} instead"

                try:
                    qubit_count = resource.circuit.qubit_count
                except:
                    qubit_count = resource.circuit.num_qubits

                conditions = (qubit_count <= len(allocation.allocated_qubit_idxs),)

            elif isinstance(resource, EquipmentResource):
                assert isinstance(
                    allocation, EquipmentAllocation
                ), f"Expected EquipmentAllocation for Equipment requirement but got {type(allocation).__name__} instead"

                conditions = (
                    resource.name == allocation.name,
                    resource.slots <= allocation.slots,
                )

            elif isinstance(resource, PersonnelResource):
                assert isinstance(
                    allocation, PersonnelAllocation
                ), f"Expected PersonnelAllocation for Personnel requirement but got {type(allocation).__name__} instead"

                conditions = (
                    resource.title == allocation.title or resource.title is None,
                    Personnel.CLEARANCE[resource.clearance]
                    <= Personnel.CLEARANCE[allocation.clearance],
                    all(skill in allocation.skillset for skill in resource.skillset),
                    all(cert in allocation.certs for cert in resource.certs),
                )

            else:
                raise TypeError(
                    f"Invalid Resource type: {type(resource).__name__}. Expected ClassicalResource, QuantumResource, EquipmentResource or PersonnelResource"
                )

            verified_allocation = verified_allocation and all(conditions)

        assert (
            verified_allocation
        ), f"Node {self.id} cannot execute it's process with given allocation {self.allocation}"

    def complete(self):
        assert (
            self.allocation is None
        ), f"Node {self.id} has not deallocated resources after completing"
        assert (
            self.process.status == Process.COMPLETED
        ), f"Node {self.id} has not completed, cannot mark as complete"

        self.generate_output_edges()
        self.map_edges_to_output_nodes()
        # logger.debug(f"Node {self.id} has completed at t={self.completion_time}")

    def generate_output_edges(self):
        """Generates the output edges of a Node after it's Process has completed execution"""

        for result in self.process.generate_output():
            # usage_str = result.properties.get("Usage", None)
            # logger.debug(f"     [EdgeGen]  Handling output result: {result} => usage={usage_str} hint={result.metadata.hint}")
            self.output_edges.append(
                DirectedEdge(
                    data=(result,),
                    source_node=self,
                    dest_nodes=None,
                )
            )
        # logger.debug(f" [EdgeGen]  final output_edges => {self.output_edges}")

    def map_edges_to_output_nodes(self):
        """Maps outgoing DirectedEdges to the next appropriate Nodes in the
        network as specified by self.output_nodes.

        Edges are mapped to output nodes when the data properties contained
        in the DirectedEdge match expected_input_properties of a Node.

        Unassigned Edges are left as 'hanging' edges of the Network.
        """
        if self.output_nodes == []:
            return

        for edge in self.output_edges:
            try:
                expected_nodes = self.get_expected_nodes(edge, self.output_nodes)
            except ExpectedNodeError:
                continue
            self.__map_edge_to_output_nodes(edge, expected_nodes)

    def get_expected_nodes(self, edge: DirectedEdge, output_nodes):
        """Finds the expected output Node that outgoing DirectedEdge edge
        should connect to based off matching data properties.

        Args:
            edge (DirectedEdge): Outgoing DirectedEdge object to connect to output node
            output_nodes (List[Node]): List of output nodes to search

        Raises:
            ExpectedNodeError: Cannot find a connecting Node with matching data properties

        Returns:
            Node: The expected Node that DirectedEdge edge connects to
        """
        # logger.debug(f" [Hooking] Checking data usage for {edge} => data usage(s): "
        #             f"{[d.properties.get('Usage') for d in edge.data]}")
        assert all(
            isinstance(output_node, Node) for output_node in output_nodes
        ), f"{output_nodes} must be a list of Nodes"
        assert (
            edge.source_node == self
        ), f"Node {self} does not have permission to assign edge of Node {edge.source_node}"
        # usage_list = [d.properties.get('Usage','?') for d in edge.data] if edge.data else []
        # logger.debug(f"[Hooking] Checking which nodes require edge {edge}")

        dest_nodes = []
        for node in output_nodes:
            if all(
                self.__edge_properties_in_output_node(edge_data.properties, node)
                for edge_data in edge.data
            ):
                dest_nodes.append(node)

        if not dest_nodes:
            logger.debug(f"     => NO match among {output_nodes}*")
            raise ExpectedNodeError(
                f"A mapping between Edge {edge} and Nodes {self.output_nodes} cannot be found"
            )

        return dest_nodes

    def __edge_properties_in_output_node(
        self, data_properties: dict, output_node
    ) -> bool:
        """Checks whether data_properties of a DirectedEdge are contained in
        the expected_input_properties of output_node.

        Args:
            data_properties (dict): Data properties of a DirectedEdge object
            output_node (Node): Output Node that may or may not contain the expected data_properties
        """
        assert isinstance(output_node, Node), f"{output_node} must be a Node object"
        if len(output_node.expected_input_properties) == 0:
            return False

        if all(
            isinstance(prop, dict) for prop in output_node.expected_input_properties
        ):
            expected_input_properties = output_node.expected_input_properties
        elif all(
            isinstance(elt, (list, tuple))
            for elt in output_node.expected_input_properties
        ):
            expected_input_properties = list(
                chain.from_iterable(output_node.expected_input_properties)
            )
        else:
            raise ValueError(
                f"Expected self.expected_input_properties to be of type list[dict] or list[list[dict]]"
            )

        for input_properties in expected_input_properties:
            if all(
                any_dict1_vals_in_dict2_vals(data_properties.get(key, None), val)
                for key, val in input_properties.items()
            ):
                return True
        return False

    def __map_edge_to_output_nodes(self, edge: DirectedEdge, output_nodes):
        """Maps edge to the specified output_node. The edge must be of type
        OUTPUT and output_node must be in the list of output_nodes. Can be used
        to manually override automatic assignments of edges to nodes.
        """
        assert all(
            isinstance(output_node, Node) for output_node in output_nodes
        ), f"{output_nodes} must contain Node objects"
        assert all(
            output_node in self.output_nodes for output_node in output_nodes
        ), f"Attempting to map edge to Node outside list of accepted output_nodes"

        for output_node in output_nodes:
            if output_node not in edge.dest_nodes:
                edge.insert_destination_node(output_node)
                output_node.append_input_edge(edge)

    @property
    def describe(self):
        # input_ids = [edge.source_node for edge in self.input_edges]
        output_ids = [node for node in self.output_nodes]
        description = (
            f"Node ID: {self.id}\n"
            f" - Process Model: {self.process if self.process else None}\n"
            f" - Network Type: {self.network_type}\n"
            f" - Input Edges: {[str(edge) for edge in self.input_edges]}\n"
            f" - Output Edges: {[str(edge) for edge in self.output_edges]}\n"
            f" - Output Nodes: {output_ids}\n"
            # f" - Process.signature: {self.process.signature}\n"
            # f" - Process.signature.left: {self.process.signature._lefts}\n"
            # f" - Process.signature.right: {self.process.signature._rights}\n"
            f" - Allocation: {self.allocation}\n"
        )
        logger.debug(description)

    def __str__(self):
        return self.process.__class__.__name__

    def __repr__(self):
        return self.process.__class__.__name__ + "." + self.id

    def __add__(self, other) -> "Network":
        if isinstance(other, Node):
            self.extend(other)
            network = Network(
                nodes=[self, other], input_nodes=[self], output_nodes=[other]
            )

            return network

        elif isinstance(other, Network):
            self.extend(other)

            nodes = other.nodes + [self]
            input_nodes = [self]

            return Network(
                name=other.name,
                description=other.description,
                nodes=nodes,
                input_nodes=input_nodes,
                output_nodes=other.output_nodes,
                selection_nodes=other.selection_nodes,
                groupings=other.groupings,
                broker=other.broker,
            )

        raise ValueError(f'Can only "add" objects of type Node or Network')

    def __matmul__(self, other) -> "Network":
        if isinstance(other, Node):
            return Network(
                nodes=[self, other],
                input_nodes=[self, other],
                output_nodes=[self, other],
            )
        elif isinstance(other, Network):
            return Network(
                name=other.name,
                nodes=other.nodes + [self],
                input_nodes=other.input_nodes + [self],
                output_nodes=other.output_nodes + [self],
                selection_nodes=other.selection_nodes,
                groupings=other.groupings,
                broker=other.broker,
            )


class AllocationError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class Network:
    """Collection of connected Nodes and Edges to represent
    larger, more complex but fixed algorithms. Smaller Networks
    can be summed together to form larger and more complex Networks
    assuming the outputs of one Network are valid inputs of the other.
    """

    def __init__(
        self,
        name="default",
        description=None,
        nodes=None,
        input_nodes=None,
        output_nodes=None,
        selection_nodes=None,
        groupings=None,
        broker: Broker = None,
    ):
        """
        Args:
            name (str): Name of the Network
            nodes (List[Node]): All the nodes contained in the Network. Defaults to None.
            input_nodes (List[Node]): List of input Nodes for the Network intended to be the starting Node for a workflow. Defaults to None.
            output_nodes (List[Node]): List of output Nodes for the Network intended to be the final Node for a workflow. Defaults to None.
            broker (Broker): Broker used for resource allocation. Defaults to None.
        """
        self.name: str = name
        self.description: str = description
        self.nodes: List[Node] = (
            sorted(nodes, key=lambda x: int(x.id[1:])) if nodes is not None else []
        )
        self.input_nodes: List[Node] = (
            sorted(input_nodes, key=lambda x: int(x.id[1:]))
            if input_nodes is not None
            else []
        )
        self.output_nodes: List[Node] = (
            sorted(output_nodes, key=lambda x: int(x.id[1:]))
            if output_nodes is not None
            else []
        )
        self.selection_nodes: List[Tuple[Node]] = (
            selection_nodes if selection_nodes is not None else []
        )
        self.groupings: dict = groupings or dict()
        self.broker: Broker = broker or Broker()
        self.execution_order: List[Node] = []

        assert all(
            isinstance(node, Node) for node in self.nodes
        ), f"One or more nodes are of invalid type, expected list of Node objects"
        assert all(
            isinstance(node, Node) for node in self.input_nodes
        ), f"One or more input_nodes are of invalid type, expected list of Node objects"
        assert all(
            isinstance(node, Node) for node in self.output_nodes
        ), f"One or more output_nodes are of invalid type, expected list of Node objects"

    def extend_input_nodes(self, node: Node):
        if node not in self.input_nodes:
            self.input_nodes.append(node)
            self.nodes.append(node)

    def extend_output_nodes(self, node: Node):
        if node not in self.output_nodes:
            self.output_nodes.append(node)
            self.nodes.append(node)

    def extend_node_destination(self, nodes: List[Node], output_node: Node):
        """For all nodes in nodes, insert output_node into the list of output
        nodes. That is, all nodes in nodes have output_node as an output_node.
        Automatically updates network_types if necessary.
        """
        nodes_cpy = copy.copy(nodes)
        for node in nodes_cpy:
            if node in self.output_nodes:
                self.output_nodes.remove(node)
            node.insert_output_node(output_node)

        self.extend_output_nodes(output_node)

    @singledispatchmethod
    def get_node(self, id: type | str) -> Node:
        raise TypeError(f"Expected id of type str or Process, got {type(id)} instead")

    @get_node.register
    def _(self, id: str) -> List[Node]:
        for node in self.nodes:
            if node.id == id:
                return [node]

        return [node for node in self.nodes if str(node.process) == id]

    @get_node.register
    def _(self, id: type) -> List[Node]:
        return [node for node in self.nodes if isinstance(node.process, id)]

    def get_nodes(self, *ids) -> list[Node]:
        return sum([self.get_node(id) for id in ids], [])

    ### TODO: Make private
    def update_broker(self, broker):
        self.broker = broker

    def run(
        self,
        starting_nodes: List[Node],
        starting_inputs: List[List[Data]] = [],
        selected_nodes: List[List[bool]] | List[int] = [],
        simulate=True,
    ):
        """Runs the simulation of the Network beginning at starting_nodes.

        Args:
            starting_nodes (List[Node]): List of nodes to start the simulation
            starting_inputs (List[List[Data]], optional): Input Data to begin Simulation. Defaults to None.
            selected_nodes (List[int], optional): List of indexes to select which selection nodes to run the network with.
                                                    E.g. for a branch with 3 nodes and another with 4 nodes and we want to select third and second respectively:
                                                        selected_nodes = [2, 1]
        """

        assert all(
            node in self.input_nodes for node in starting_nodes
        ), f"One or more Node in {starting_nodes} is not in self.input_nodes"
        assert len(selected_nodes) == len(
            self.selection_nodes
        ), f"There are one or more branches in this network, expected values for selected_nodes parameter"

        if len(self.selection_nodes) > 0:
            self.__select_branching_nodes(selected_nodes)

        if len(starting_inputs) > 0:
            self.__init_input_data(starting_nodes, starting_inputs)
        else:
            for node in starting_nodes:
                if len(node.input_edges) == 0 and node.expected_input_properties != []:
                    raise ValueError(
                        f"Node {str(node)} in starting_nodes is not assigned required input DirectedEdge(s)"
                    )

        remaining_nodes = copy.copy(starting_nodes)
        active_nodes: List[Node] = []
        elapsed_time = 0.0
        execution_idx = 0
        results: Dict[Node, Result] = {}
        while len(remaining_nodes) != 0 or len(active_nodes) != 0:
            any_node_processed = False
            node_idx = 0
            while node_idx < len(remaining_nodes):
                node = remaining_nodes[node_idx]
                try:
                    node.initialize()
                    self.__allocate_resources(node)
                    node.verify_allocation()
                    self.__update_node_duration(node)
                except (AllocationError, InitError):
                    node_idx = node_idx + 1
                    continue

                active_nodes.append(node)
                remaining_nodes.remove(node)
                self.execution_order.append(node)
                node.process.update()

                results[node] = Result(
                    network_idx=execution_idx,
                    start_time=elapsed_time,
                    device_name=[],
                    memory_usage=0.0,
                )

                self.__update_allocation_estimates(node, results, simulate)
                any_node_processed = True
                execution_idx += 1

            node_idx = 0
            update_timestep = self.__compute_min_timestep(active_nodes)
            elapsed_time += update_timestep
            while node_idx < len(active_nodes):
                active_node = active_nodes[node_idx]
                self.__progress_node_timestep(active_node, update_timestep)

                if active_node.process.status == Process.COMPLETED:
                    if active_node.process.dynamic:
                        self.__extend_dynamic_node(active_node)

                    cost = 0
                    process_duration = elapsed_time - results[active_node].start_time
                    for allocation in active_node.allocation.values():
                        cost += (
                            allocation.costOverhead
                            + process_duration * allocation.costOperational
                        )

                    results[active_node].cost = round(cost, 2)
                    results[active_node].end_time = elapsed_time
                    self.__fill_NA(active_node, results)

                    self.__complete_node(active_node)
                    active_nodes.remove(active_node)
                    remaining_nodes.extend(
                        [
                            node
                            for node in self.get_prepared_output_nodes(active_node)
                            if node not in active_nodes + remaining_nodes
                        ]
                    )
                    logger.debug(
                        f"Removing {repr(active_node)} from active nodes and preparing new remaining nodes"
                    )
                    any_node_processed = True
                    continue

                node_idx = node_idx + 1

            if not any_node_processed:
                assert update_timestep == np.inf and len(active_nodes) == 0.0
                properties_mismatch = "\n\t".join(
                    [
                        str(node)
                        + f" --> {node.process.get_missing_data_properties(node.input_edges)}"
                        for node in remaining_nodes
                    ]
                )
                error_message = f"""Input mismatch or missing for one or more nodes: \n\t{properties_mismatch}"""
                raise ValueError(error_message)

        self.results = SimulationResults(self.generate_results_dataframe(results))
        return self.results

    def __select_branching_nodes(self, selected_nodes: List[int]):
        """Helper function for run(). Selects which nodes to simulate/run whenever there are branches in the Network.

        Args:
            selected_nodes (List[int], optional): List of indexes to select which selection nodes to run the network with.
                                                    E.g. for a branch with 3 nodes and another with 4 nodes and we want to select third and second respectively:
                                                        selected_nodes = [2, 1]
        """
        for idx in range(len(selected_nodes)):
            idx_to_select = selected_nodes[idx]
            if idx_to_select is None or idx_to_select == []:
                continue
            selected_node = self.selection_nodes[idx][idx_to_select]

            selected_node.process.selected = True
            if selected_node in self.groupings:
                for grouped_node in self.groupings[selected_node]:
                    grouped_node.process.selected = True

    def __init_input_data(
        self, starting_nodes: List[Node], starting_inputs: List[List[Data]]
    ):
        assert len(starting_nodes) == len(
            starting_inputs
        ), f"Each Node in starting_nodes must have a corresponding Data object(s) in starting_inputs"

        for idx in range(len(starting_nodes)):
            inputs = starting_inputs[idx]
            node = starting_nodes[idx]
            input_edge = DirectedEdge(
                data=tuple(inputs),
                source_node=None,
                dest_nodes=[node],
            )
            node.append_input_edge(input_edge)

    def __update_allocation_estimates(self, node: Node, results: dict, simulate: bool):
        for allocation in node.allocation.values():
            if isinstance(allocation, DeviceAllocation):
                if simulate:
                    memory_usage = allocation.allocated_memory
                else:
                    node.process.time_till_completion = node.process.time
                    memory_usage = node.process.memory

                results[node].device_name.append(allocation.name)
                results[node].memory_usage += memory_usage

            elif isinstance(allocation, QDeviceAllocation):
                assert isinstance(
                    node.process, QuantumProcess
                ), f"Expected QuantumProcess for QDeviceAllocation {allocation}"

                try:
                    circuit_depth = allocation.transpiled_circuit.depth()
                    gate_counts = count_gates(allocation.transpiled_circuit)
                except AttributeError as e:
                    if "'NoneType' object has no attribute 'depth'" in str(e):
                        circuit_depth = int(
                            allocation.T_count
                            / (len(allocation.allocated_qubit_idxs) - 2)
                        )
                        T_gate_counts = allocation.device.T_transpiled_counts
                        gate_counts = Counter(
                            {
                                1: allocation.T_count * T_gate_counts[1],
                                2: allocation.T_count * T_gate_counts[2],
                            }
                        )
                    else:
                        raise

                results[node].device_name.append(allocation.name)
                results[node].qubits_used = tuple(allocation.allocated_qubit_idxs)
                results[node].circuit_depth = circuit_depth
                results[node].gate_counts = gate_counts
                results[node].success_probability = (
                    node.process._compute_sucess_probability(allocation)
                )

            elif isinstance(allocation, (PersonnelAllocation, EquipmentAllocation)):
                assert isinstance(
                    node.process, Task
                ), f"Expected Task for PersonnelAllocation/EquipmentAllocation {allocation}"

                results[node].device_name.append(allocation.name)

            else:
                assert (
                    allocation.name is None
                ), f"Expected None allocation for no required resources"

                results[node].device_name = None

    def __update_node_duration(self, node: Node):
        if isinstance(node.process, ClassicalProcess):
            time_till_completion = node.process._compute_classical_process_update_time(
                node.allocation
            )
        elif isinstance(node.process, QuantumProcess):
            time_till_completion = (
                node.process._compute_quantum_process_update_time(node.allocation)
                * node.process.shots
            )
        elif isinstance(node.process, Task):
            time_till_completion = node.process.get_process_duration()

        node.process.time_till_completion = time_till_completion

    def __fill_NA(self, node: Node, results: dict):
        if all(
            not isinstance(allocation, DeviceAllocation)
            for allocation in node.allocation.values()
        ):
            results[node].memory_usage = pd.NA

        if all(
            not isinstance(allocation, QDeviceAllocation)
            for allocation in node.allocation.values()
        ):
            results[node].qubits_used = pd.NA
            results[node].circuit_depth = pd.NA
            results[node].success_probability = pd.NA
            results[node].gate_counts = Counter({1: pd.NA, 2: pd.NA})

    def reset_network(self):
        for node in self.nodes:
            node.output_edges = []
            if node not in self.input_nodes:
                node.input_edges = []
            node.process.selected = True

    def __allocate_resources(self, node: Node):
        """Requests allocation of resources for a process state from its broker.

        This method shall initiate a request for resource allocation for
        a process state from its associated broker. This request does not
        guarantee resource allocation.

        Returns:
            `Allocation`: An allocation result

        """
        if node.process.required_resources is None:
            if isinstance(node.process, ClassicalProcess):
                resource_type = Resource.CLASSICAL
            elif isinstance(node.process, QuantumProcess):
                resource_type = Resource.QUANTUM
            elif isinstance(node.process, Task):
                resource_type = Resource.EQUIPMENT

            allocation = {
                Resource(resource_type): Allocation(name=None, device_type=None)
            }

        else:
            # logger.debug(f"Node {node.id} is attempting allocation...")
            try:
                allocation = self.broker.request_allocation(node.process)
                # logger.debug(f"Node {node.id} resource allocation successful")
            except IncompatibleDevicesError:
                raise IncompatibleDevicesError(
                    f"No devices under current broker can support the resource requirements for node {node}"
                )
            except AssertionError as e:
                if str(e) == "No available devices":
                    raise AllocationError(f"Node {node.id} resource allocation FAILED")
                else:
                    raise e

        node.process.status = Process.ACTIVE
        node.allocation = allocation

    def __progress_node_timestep(self, node: Node, timestep: float):
        node.execute_process(timestep)

    def __extend_dynamic_node(self, dynamic_node: Node):
        if dynamic_node in self.output_nodes:
            self.output_nodes.remove(dynamic_node)

        sub_network = dynamic_node.process.extend_network()
        output_nodes = copy.copy(
            [node for node in dynamic_node.output_nodes if node.extend_dynamic]
        )

        if isinstance(sub_network, Node):
            dynamic_node.output_nodes = [sub_network]
            self.nodes.append(sub_network)
            if len(output_nodes) == 0:
                self.output_nodes.append(sub_network)
            sub_network.output_nodes = output_nodes

        elif isinstance(sub_network, list):
            assert all(
                isinstance(subnode, Node) for subnode in sub_network
            ), f"Process.extend_network must either be a Node, a list of Nodes, or a Network"

            dynamic_node.output_nodes = sub_network
            for subnode in sub_network:
                self.nodes.append(subnode)
                if len(output_nodes) == 0:
                    self.output_nodes.append(subnode)
                subnode.output_nodes = output_nodes

        elif isinstance(sub_network, Network):
            dynamic_node.output_nodes.extend(sub_network.input_nodes)

            if len(sub_network.output_nodes) == 0:
                assert all(
                    node in sub_network.input_nodes for node in sub_network.nodes
                ), f"Network {sub_network.name} cannot have NETWORK nodes without OUTPUT nodes"

                for node in sub_network.input_nodes:
                    self.nodes.append(node)
                    if len(output_nodes) == 0:
                        self.output_nodes.append(node)
                    node.output_nodes = output_nodes

            else:
                for node in sub_network.nodes:
                    self.nodes.append(node)
                    if node in sub_network.output_nodes:
                        if len(output_nodes) == 0:
                            self.output_nodes.append(node)
                        node.output_nodes.extend(output_nodes)

        else:
            raise ValueError(
                "Process.extend_network must either be a Node, a list of Nodes, or a Network"
            )

    def __complete_node(self, node: Node):
        self.__deallocate_resources(node)
        node.complete()

    def __deallocate_resources(self, node: Node):
        """Requests deallocation of resources from a process state's broker.

        This method shall initiate a request for resource freeing and
        release for a process state from its broker. This request does
        not guarantee release of resources.

        """

        if node.process.required_resources is None:
            node.allocation = None
        else:
            for allocation in node.allocation.values():
                self.broker.request_deallocation(allocation)
            node.allocation = None

    def get_prepared_output_nodes(self, node: Node):
        """Returns a list of all nodes in node.output_nodes whose
        input DirectedEdges are all completed and thus ready to execute
        """
        prepared_nodes = []
        for output_node in node.output_nodes:
            if (
                output_node.process.status == Process.UNSTARTED
                and output_node.process.selected
                and output_node not in self.input_nodes
            ):
                prepared_nodes.append(output_node)

        return prepared_nodes

    def __compute_min_timestep(self, active_nodes: List[Node]) -> float:
        """Compares the remaining process execution time of all active nodes and selects
        the smallest one.

        Returns:
            float: The minimum timestep
        """
        assert all(
            node.process.status == Process.ACTIVE for node in active_nodes
        ), f"One or more Nodes in {active_nodes} have not been allocated resources"

        min_timestep = INFINITY
        for node in active_nodes:
            if node.process.time_till_completion < min_timestep:
                min_timestep = node.process.time_till_completion

        return min_timestep

    def generate_gantt_plot(self):
        assert isinstance(
            self.results, SimulationResults
        ), f"Generate simulation results by calling network.run()!"

        publish_gantt(self.results.raw)

    def generate_results_dataframe(self, results: Dict[Node, Result]) -> pd.DataFrame:
        results_dict = {
            "Network Idx": [],
            "Node Idx": [],
            "Process": [],
            "Start Time [s]": [],
            "End Time [s]": [],
            "Duration [s]": [],
            "Device Name": [],
            "Memory Cost [B]": [],
            "Cost [$]": [],
            "Qubits Used": [],
            "Circuit Depth": [],
            "Gates [1]": [],
            "Gates [2]": [],
            "Success Probability": [],
        }

        for key, val in results.items():
            if not val.device_name:
                devices = None
            elif len(val.device_name) > 1:
                devices = tuple(val.device_name)
            else:
                devices = val.device_name[0]

            results_dict["Network Idx"].append(val.network_idx)
            results_dict["Node Idx"].append(repr(key).split(".")[1])
            results_dict["Process"].append(key)
            results_dict["Start Time [s]"].append(val.start_time)
            results_dict["End Time [s]"].append(val.end_time)
            results_dict["Duration [s]"].append(val.end_time - val.start_time)
            results_dict["Device Name"].append(devices)
            results_dict["Memory Cost [B]"].append(val.memory_usage)
            results_dict["Cost [$]"].append(val.cost)
            results_dict["Qubits Used"].append(val.qubits_used)
            results_dict["Circuit Depth"].append(val.circuit_depth)
            results_dict["Gates [1]"].append(val.gate_counts[1])
            results_dict["Gates [2]"].append(val.gate_counts[2])
            results_dict["Success Probability"].append(val.success_probability)

        dataframe = pd.DataFrame(results_dict)
        dataframe = dataframe.sort_values(by="Network Idx")
        dataframe.drop("Network Idx", axis=1, inplace=True)

        return dataframe

    def __matmul__(self, other):
        """Combines two networks under a single larger network such that
        input and output nodes are concatenated
        """

        if isinstance(other, Node):
            return Network(
                name=self.name,
                nodes=self.nodes + [other],
                input_nodes=self.input_nodes + [other],
                output_nodes=self.output_nodes + [other],
                selection_nodes=self.selection_nodes,
                groupings=self.groupings,
                broker=self.broker,
            )

        elif isinstance(other, Network):
            name = f"{self.name} & {other.name}"
            nodes = self.nodes + other.nodes
            input_nodes = self.input_nodes + other.input_nodes
            output_nodes = self.output_nodes + other.output_nodes
            selection_nodes = self.selection_nodes + other.selection_nodes
            groupings = self.groupings | other.groupings
            broker = self.broker + other.broker

            return Network(
                name=name,
                nodes=nodes,
                input_nodes=input_nodes,
                output_nodes=output_nodes,
                selection_nodes=selection_nodes,
                groupings=groupings,
                broker=broker,
            )
        else:
            raise ValueError(
                f"Expected a Node or Network object, but got {type(other).__name__} instead"
            )

    def __add__(self, other) -> Network:
        """Combines the networks such that the outputs of self are connected
        to the inputs of other. Outputs without a connected input will be
        treated as outputs of the combined network
        """

        self.unassigned_output_nodes = []
        if isinstance(other, Node):
            for output_node in self.output_nodes:
                self.__assign_network_output_nodes(output_node, [other])

            if len(self.output_nodes) == len(self.unassigned_output_nodes):
                warnings.warn(f"Unable to find connection for Node {str(other)}")

            return Network(
                name=self.name,
                nodes=self.nodes + [other],
                input_nodes=self.input_nodes,
                output_nodes=self.unassigned_output_nodes + [other],
                selection_nodes=self.selection_nodes,
                groupings=self.groupings,
                broker=self.broker,
            )

        elif isinstance(other, Network):
            for output_node in self.output_nodes:
                self.__assign_network_output_nodes(output_node, other.input_nodes)

            ### TODO: INPUT NODES THAT ARE NOT ASSIGNED BECOME INPUT NODES OF THE WHOLE NETWORK

            name = f"{self.name} + {other.name}"
            nodes = self.nodes + other.nodes
            input_nodes = self.input_nodes
            output_nodes = other.output_nodes + self.unassigned_output_nodes
            selection_nodes = self.selection_nodes + other.selection_nodes
            groupings = self.groupings | other.groupings
            broker = self.broker + other.broker

            return Network(
                name=name,
                nodes=nodes,
                input_nodes=input_nodes,
                output_nodes=output_nodes,
                selection_nodes=selection_nodes,
                groupings=groupings,
                broker=broker,
            )

    def __assign_network_output_nodes(self, node: Node, input_nodes: list[Node]):
        """Attempts to assign output node to the appropriate destination nodes in input_nodes"""

        if node.process.output_properties is None:
            raise ValueError(
                f"self.output_properties is not set for class {str(node.process)}. Ensure the corresponding set_output_properties method is complete."
            )

        output_nodes = set()
        for node_property in node.process.output_properties:
            for input_node in input_nodes:
                if self.__output_property_in_expected_input_properties(
                    node_property, input_node.expected_input_properties
                ):
                    output_nodes.add(input_node)
                    # break

        if len(output_nodes) == 0:
            self.unassigned_output_nodes.append(node)
        else:
            node.output_nodes.extend(list(output_nodes))

    ## TODO: REALLY MESSY, CLEAN UP
    def __output_property_in_expected_input_properties(
        self, output_property: dict, expected_input_properties: List[dict]
    ):
        if isinstance(expected_input_properties[0], dict):
            for expected_input_property in expected_input_properties:
                if all(
                    any_dict1_vals_in_dict2_vals(
                        expected_input_property.get(key, None), val
                    )
                    for key, val in output_property.items()
                ):
                    return True
            return False
        elif isinstance(expected_input_properties[0], list):
            for expected_properties in expected_input_properties:
                for expected_input_property in expected_properties:
                    if all(
                        any_dict1_vals_in_dict2_vals(
                            expected_input_property.get(key, None), val
                        )
                        for key, val in output_property.items()
                    ):
                        return True
            return False

    def separate(self, separation_edge):
        del separation_edge
        pass

    def assign_hierarchical_positions(self, G: nx.DiGraph):
        sources = [n for n in G.nodes() if G.in_degree(n) == 0]

        if not sources:
            min_in_degree = min(G.in_degree(n) for n in G.nodes())
            sources = [n for n in G.nodes() if G.out_degree(n) == min_in_degree]

        levels = {node: 0 for node in sources}

        try:
            topo_order = list(nx.topological_sort(G))
        except nx.NetworkXError:
            topo_order = list(G.nodes())

        for node in topo_order:
            if node not in levels:
                predecessors = list(G.predecessors(node))

                if predecessors:
                    max_pred_level = max(levels.get(pred, 0) for pred in predecessors)
                    levels[node] = max_pred_level + 1
                else:
                    levels[node] = 0

        levels_dict = {}
        for node, level in levels.items():
            if level not in levels_dict:
                levels_dict[level] = []
            levels_dict[level].append(node)

        def extract_hex(node_name):
            hex_string = node_name.split(".")[1]
            hex_string = hex_string[1:]

            return int(hex_string, 16)

        pos = {}
        for level, nodes in levels_dict.items():
            x = level
            num_nodes = len(nodes)

            sorted_nodes = sorted(nodes, key=extract_hex)
            for i, node in enumerate(sorted_nodes):
                y = (i - num_nodes / 2) * 1.5
                pos[node] = (x, y)

        return pos

    def visualize(
        self,
        figsize=(12, 8),
        node_size=800,
        font_size=10,
        title_size=14,
        hide_repeated=False,
        interactive=True,
        swap_xy=False,
        hide_unstarted=False,
        completed_node_color="lightblue",
        completed_edge_color="darkblue",
        unstarted_node_color="lightgray",
        unstarted_edge_color="darkgray",
    ):
        """Visualize the nodes and edge connections in the DAG network. Can only be used AFTER the network is .run().
        Setting interactive=True enables functionality to click and drag nodes in the display.

        Args:
            figsize (tuple, optional): Width and height of displayed figure size. Defaults to (12, 8).
            node_size (int, optional): Size of displayed nodes. Defaults to 800.
            font_size (int, optional): Size of process names in each node. Defaults to 10.
            hide_repeated (bool, optional): Whether or not to hide repeated nodes in the network. Defaults to True.
            interactive (bool, optional): Whether or not to enable interactive functionality. Defaults to True.
            swap_xy (bool, optional): Swaps from left-to-right dataflow (default) to top-to-bottom dataflow. Defaults to False.
            hide_unstarted (bool, optional): Hides nodes that were not executed in the simulation. Defaults to False.
            completed_node_color (str, optional): Sets the color of completed nodes. Defaults to "lightblue".
            completed_edge_color (str, optional): Sets the color of completed node borders. Defaults to "darkblue".
            unstarted_node_color (str, optional): Sets the color of unexecuted nodes. Defaults to "lightgray".
            unstarted_edge_color (str, optional): Sets the color of unexecuted node borders. Defaults to "darkgray".
        """

        if hasattr(self, "results"):
            assert isinstance(self.results, SimulationResults)
        else:
            raise AttributeError(
                f"Network simulation results not found. Please .run() the network with appropriate input nodes before visualizing"
            )

        G: nx.DiGraph = self.to_nx(hide_repeated)
        fig, ax = plt.subplots(figsize=figsize)

        pos = self.assign_hierarchical_positions(G)
        if swap_xy:
            vmin = min([v[0] for _, v in pos.items()])
            vmax = max([v[0] for _, v in pos.items()])
            pos = {k: (v[1], vmax + vmin - v[0]) for k, v in pos.items()}

        completed_nodes = [
            n for n in G.nodes() if G.nodes[n].get("status") == "COMPLETED"
        ]
        unstarted_nodes = [
            n for n in G.nodes() if G.nodes[n].get("status") == "UNSTARTED"
        ]

        if hide_unstarted:
            edge_list = [
                edge
                for edge in G.edges
                if edge[0] in completed_nodes and edge[1] in completed_nodes
            ]
        else:
            edge_list = G.edges

        graph_artists = {
            "edges": None,
            "COMPLETED": None,
            "UNSTARTED": None,
            "labels": None,
        }

        def draw_graph():
            ax.clear()

            graph_artists["edges"] = nx.draw_networkx_edges(
                G,
                pos,
                edgelist=edge_list,
                edge_color="gray",
                arrows=True,
                arrowsize=20,
                arrowstyle="->",
                width=2,
                alpha=0.6,
                connectionstyle="arc3,rad=0.1",
                node_size=node_size,
                ax=ax,
            )

            if completed_nodes:
                graph_artists["COMPLETED"] = nx.draw_networkx_nodes(
                    G,
                    pos,
                    nodelist=completed_nodes,
                    node_color=completed_node_color,
                    node_size=node_size,
                    edgecolors=completed_edge_color,
                    linewidths=2,
                    ax=ax,
                )

            if not hide_unstarted:
                graph_artists["UNSTARTED"] = nx.draw_networkx_nodes(
                    G,
                    pos,
                    nodelist=unstarted_nodes,
                    node_color=unstarted_node_color,
                    node_size=node_size,
                    edgecolors=unstarted_edge_color,
                    linewidths=2,
                    ax=ax,
                )

            labels = {}
            if hide_unstarted:
                labels = {node: str(node).split(".")[0] for node in completed_nodes}
            else:
                labels = {node: str(node).split(".")[0] for node in G.nodes()}

            graph_artists["labels"] = nx.draw_networkx_labels(
                G, pos, labels=labels, font_size=font_size, font_weight="bold", ax=ax
            )

            ax.set_title(
                f"Graph visualization for {self.name} Network",
                fontsize=title_size,
                fontweight="bold",
            )
            ax.axis("off")
            fig.canvas.draw_idle()

        draw_graph()

        if interactive:
            dragging = {"node": None, "offset": None}

            def on_press(event):
                if event.inaxes != ax:
                    return

                for node, (x, y) in pos.items():
                    dx = event.xdata - x
                    dy = event.ydata - y
                    dist = np.sqrt(dx**2 + dy**2)

                    node_radius = np.sqrt(node_size) / 100.0
                    if dist < node_radius:
                        dragging["node"] = node
                        dragging["offset"] = (dx, dy)
                        break

            def on_motion(event):
                if dragging["node"] is None or event.inaxes != ax:
                    return

                node = dragging["node"]
                dx, dy = dragging["offset"]
                pos[node] = (event.xdata - dx, event.ydata - dy)

                draw_graph()

            def on_release(event):
                dragging["node"] = None
                dragging["offset"] = None

            fig.canvas.mpl_connect("button_press_event", on_press)
            fig.canvas.mpl_connect("motion_notify_event", on_motion)
            fig.canvas.mpl_connect("button_release_event", on_release)

        plt.tight_layout()
        plt.show()

    def to_nx(self, hide_repeated=True):
        assert isinstance(
            self.results, SimulationResults
        ), f"Network has not been run, please run() the network before visualizing"

        G = nx.DiGraph()

        nx_edges = []
        for node in self.nodes:
            for edge in node.output_edges:
                for dest_node in edge.dest_nodes:
                    nx_edges.append((repr(node), repr(dest_node)))

        G.add_edges_from(nx_edges)

        for node in self.nodes:
            try:
                G.nodes[repr(node)]["status"] = node.process.status
            except KeyError:
                continue
            except:
                raise

        if hide_repeated:
            appearances = dict()
            for node in G.nodes():
                name = str(node).split(".")[0]
                if name not in appearances:
                    appearances[name] = 1
                else:
                    appearances[name] += 1

            to_trim_name = [
                node_name
                for node_name, appearance in appearances.items()
                if appearance > 1
            ]
            to_trim_node = [
                self.find_first_completed_node(G, name) for name in to_trim_name
            ]
            connection = {node: [] for node in to_trim_node}
            to_remove = set()
            for node in G.nodes():
                if node in to_trim_node:
                    to_search = [node]

                    while len(to_search) > 0:
                        search = to_search.pop(0)
                        successors = list(G.successors(search))

                        for successor in successors:
                            if str(successor).split(".")[0] in to_trim_name:
                                to_search.append(successor)
                                to_remove.add(successor)
                                G.remove_edge(search, successor)
                                if search in connection[node]:
                                    connection[node].remove(search)
                                connection[node].append(successor)

            for node, connections in connection.items():
                for c in connections:
                    if str(c).split(".")[0] in to_trim_name:
                        successors = list(G.successors(c))
                        for successor in successors:
                            G.add_edge(node, successor)
                    else:
                        G.add_edge(node, c)

            for node in G.nodes():
                if str(node).split(".")[0] in to_trim_name:
                    if node not in to_trim_node:
                        to_remove.add(node)

            for node in to_remove:
                G.remove_node(node)

        return G

    def find_first_completed_node(self, G: nx.DiGraph, target_name: str):
        sources = [n for n in G.nodes() if G.in_degree(n) == 0]

        if not sources:
            min_in_degree = min(G.in_degree(n) for n in G.nodes())
            sources = [n for n in G.nodes() if G.in_degree(n) == min_in_degree]

        queue = deque(sources)
        visited = set(sources)

        for node in sources:
            if (
                str(node).split(".")[0] == target_name
                and G.nodes[node]["status"] == "COMPLETED"
            ):
                return node

        while queue:
            current = queue.popleft()

            for successor in G.successors(current):
                if successor not in visited:
                    visited.add(successor)

                    if (
                        str(successor).split(".")[0] == target_name
                        and G.nodes[successor]["status"] == "COMPLETED"
                    ):
                        return successor

                    queue.append(successor)

        return None

    def pie_chart(
        self, parameter: str = "time", display_threshold: int = 5, font_size: int = 12
    ):
        """Generates a basic pie chart displaying the breakdown of process durations for the network. Different Nodes with
        the same processes will have their durations summed into a single slice. Slices with duration less than the
        display_threshold percentage will have their labels hidden. Hovering over the slices will display Node
        information, execution duration and relative percentage. The legend on the left is sorted by largest contribution
        from top to bottom.

        Args:
            parameter (str, optional): The parameter to display. Only 'time' and 'cost' are currently supported. Defaults to 'time'.
            display_threshold (int, optional): The minimum relative percentage of the slice to display a percentage label. Defaults to 5.
        """

        if parameter == "time":
            param = "Duration [s]"
            df = self.results.raw.copy()
            hovertemplate = "<b>%{label}</b><br>Duration: %{value:.3E} s<br>Percent: %{percent}<extra></extra>"

        elif parameter == "cost":
            param = "Cost [$]"
            df = self.results.raw.copy()
            hovertemplate = "<b>%{label}</b><br>Cost: $%{value:.3E}<br>Percent: %{percent}<extra></extra>"

        elif parameter == "memory":
            param = "Memory Cost [B]"

            df = SimulationResults(self.results.raw.copy())
            df = df.filter(("Memory Cost [B]", "!=", pd.NA))
            df = df.raw

            hovertemplate = "<b>%{label}</b><br>Memory: %{value:.3E} B<br>Percent: %{percent}<extra></extra>"

        else:
            raise ValueError(
                f"Unsupported value for parameter. Only 'time' and 'cost' are currently supported"
            )

        df["Process"] = df["Process"].astype(str)
        process_totals = df.groupby("Process")[param].sum()
        val_total = df[param].sum()

        if val_total == 0.0:
            raise ValueError(
                f"All parameter values are 0.0. Please ensure there is atleast one nonzero entry or try another parameter."
            )

        group_percent = df["Process"].map(process_totals) / val_total * 100

        display_text = [
            f"<b>{group_p:.1f}%</b>" if group_p >= display_threshold else ""
            for group_p in group_percent
        ]

        fig = px.pie(df, values=param, names="Process")
        fig.update_traces(
            text=display_text,
            textinfo="text",
            hovertemplate=hovertemplate,
            textfont=dict(size=font_size),
        )

        fig.show()

    def pie_overlap(self, dataframe: SimulationResults | pd.DataFrame = None):
        """Generates an interactive pie chart where processes that are executed in parallel overlap accordingly. The
        first process of the network begins at the top of the pie chart and are executed following a clockwise fashion.
        The processes are also displayed in the legend on the right in the sequence they are executed.

        Args:
            dataframe (SimulationResults, pd.DataFrame, optional): SimulationResults or pd.DataFrame object to visualize.
            Rows MUST be time continguous. None defaults to the entire results dataframe object
        """

        if dataframe is None:
            df = self.results.raw.copy()
            min_time = 0.0
        elif isinstance(dataframe, SimulationResults):
            df = dataframe.raw
            min_time = df["Start Time [s]"].min()
        elif isinstance(dataframe, pd.DataFrame):
            df = dataframe
            min_time = df["Start Time [s]"].min()
        else:
            raise ValueError(
                f"Invalid value for sim_results. Expecting a SimulationResults or pd.Dataframe object but got {type(dataframe)} instead."
            )

        walltime = df["End Time [s]"].max() - min_time
        palette = px.colors.qualitative.Alphabet

        fig = go.Figure()
        for i, row in df.iterrows():
            color = palette[i % len(palette)]
            fig.add_trace(
                go.Barpolar(
                    r=[100],
                    theta=[
                        -(row["Start Time [s]"] + row["End Time [s]"] - 2 * min_time)
                        / walltime
                        * 180
                        + 90
                    ],
                    width=[
                        (row["End Time [s]"] - row["Start Time [s]"]) / walltime * 360
                    ],
                    base=[0],
                    name=str(row["Process"]),
                    opacity=0.3,
                    marker_color=color,
                    hovertemplate=f"<b>{row['Process']}</b><br> Duration: {round(row['Duration [s]'],2)} s <br> Percent: {round(row['Duration [s]']/walltime * 100,2)}%<extra></extra>",
                )
            )

        custom_js = """
        var plot = document.getElementsByClassName('plotly-graph-div')[0];

        plot.on('plotly_hover', function(data) {
            var idx = data.points[0].curveNumber; 
            var update = {opacity: 1};
            Plotly.restyle(plot, update, [idx]);
        });

        plot.on('plotly_unhover', function(data) {
            var idx = data.points[0].curveNumber;
            var update = {opacity: 0.3};
            Plotly.restyle(plot, update, [idx]);
        });
        """

        fig.update_layout(
            polar=dict(radialaxis=dict(visible=False), angularaxis=dict(visible=False)),
            showlegend=True,
        )

        fig.show(post_script=custom_js)

    @property
    def describe(self):
        # node_ids = [node for node in self.nodes]
        # node_edges = [node.id for node in self.nodes]
        # input_ids = [node for node in self.input_nodes]
        # node_edges = [f"{node}, {node.network_type}" for node in self.nodes]
        # output_ids = [node for node in self.output_nodes]

        active = [node for node in self.nodes if node.process.status == Process.ACTIVE]
        inactive = [
            node for node in self.nodes if node.process.status == Process.UNSTARTED
        ]
        completed = [
            node for node in self.nodes if node.process.status == Process.COMPLETED
        ]
        description = (
            f"Network: {self.name}\n"
            # f"Nodes: {node_ids}\n"
            f" - Active Nodes: {active}\n"
            # f"Node .network_types: {node_edges}\n"
            f" - Unstarted Nodes: {inactive}\n"
            f" - Completed Nodes: {completed}"
        )

        logger.debug(description)

    def __str__(self):
        return self.name
