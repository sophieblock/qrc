""" """

from ...quantum_gates import *
from ...quantum import QuantumCircuit, QuantumInstruction
import workflow.simulation.quantum_gates as quantum_gateset

from qiskit import QuantumCircuit as QiskitCircuit
import qiskit
import qiskit.circuit.library as qiskit_library
from qiskit.circuit import Gate

from collections import Counter


def qiskit_to_quantum_circuit(qc: QiskitCircuit):
    from numpy import angle, pi

    circ = QuantumCircuit(qubit_count=qc.num_qubits, instructions=[])

    for inst, qargs, _c in qc.data:
        name = inst.name.upper()

        # -------------- tidy special-cases -----------------
        if name == "TDG":
            name = "Tdg"

        # -------------- generic path -----------------------
        GateCls = getattr(quantum_gateset, name)
        qidx = tuple(q.index if hasattr(q, "index") else q._index for q in qargs)

        if name in ("RX", "RY", "RZ", "CZPow", "RZZ"):
            circ.add_instruction(QuantumInstruction(GateCls(inst.params[0]), qidx))
        else:
            circ.add_instruction(QuantumInstruction(GateCls(), qidx))

    return circ


def quantum_circuit_to_qiskit(qc: QuantumCircuit):
    circuit = QiskitCircuit(qc.qubit_count, 0)
    for instruction in qc.instructions:
        gate_name = instruction.gate.name

        if gate_name == "CZPow":
            circuit.append(
                qiskit_library.CZGate().power(instruction.gate.param),
                list(instruction.gate_indices),
            )
        elif gate_name == "SWAP":
            circuit.append(
                qiskit_library.SwapGate(),
                list(instruction.gate_indices),
            )
        else:
            qiskit_gate = getattr(qiskit_library, gate_name + "Gate")
            if hasattr(instruction.gate, "param"):
                circuit.append(
                    qiskit_gate(instruction.gate.param), list(instruction.gate_indices)
                )
            else:
                circuit.append(qiskit_gate(), list(instruction.gate_indices))

    return circuit


def count_gates(qc: QuantumCircuit):
    gate_counts = Counter()

    for instruction in qc.data:
        op = instruction.operation
        if isinstance(op, Gate):
            gate_counts[len(instruction.qubits)] += 1

    return gate_counts
