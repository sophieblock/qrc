from .quantum_devices import (
    IBM_Boston,
    IBM_Miami,
    IBM_Fez,
    IBM_Kingston,
    IBM_Pittsburgh,
    IBM_Marrakesh,
)
