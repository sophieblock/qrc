from statistics import fmean
from typing import List
import networkx as nx
import pandas as pd
import os
import inspect
import math

from workflow.simulation.quantum_gates import QuantumGate
import workflow.simulation.quantum_gates as quantum_gateset

input_path = os.path.join(os.path.dirname(__file__), "quantum-device-data")

SUPPORTED_GATES = ["I", "CZ", "RX", "RZ", "SX", "X", "RZZ"]
SINGLE_QUBIT_GATES = ["I", "RX", "RZ", "SX", "X"]
TWO_QUBIT_GATES = ["CZ", "RZZ"]
CSV_TO_GATE_ID = {
    "ID": "I",
    "CZ": "CZ",
    "RX": "RX",
    "Z-axis rotation (rz)": "RZ",
    "√x (sx)": "SX",
    "Pauli-X": "X",
    "RZZ": "RZZ",
}


class LoadQuantumDeviceData:
    def __init__(self, file_name: str):
        self.connectivity = nx.Graph()
        self.configuration_df = self.load_device_configuration(file_name)
        self.gate_set = self.get_supported_gates()
        self.initialize_connectivity()
        self.average_vals = self.get_average_connection_vals()

    def load_device_configuration(self, file_name: str) -> pd.DataFrame:
        df = pd.read_csv(os.path.join(input_path, file_name))
        return df

    def get_supported_gates(self):
        supported_gates = []
        for column in self.configuration_df:
            col_split = column.split(" ")
            col_head = " ".join(col_split[:-1])
            if col_split[-1] == "error" and col_head in CSV_TO_GATE_ID.keys():
                assert (
                    CSV_TO_GATE_ID[col_head] not in supported_gates
                ), f"{CSV_TO_GATE_ID[col_head]} is already a gate in supported_gates"
                supported_gates.append(CSV_TO_GATE_ID[col_head])
        return supported_gates

    def initialize_connectivity(self):
        num_qubits = len(self.configuration_df["Qubit"])
        self.connectivity.add_nodes_from(range(num_qubits))

        for node in self.connectivity.nodes:
            for gate_name in self.gate_set:
                if gate_name in SINGLE_QUBIT_GATES:
                    self.connectivity.nodes[node][gate_name] = {
                        "Duration": None,
                        "Error": None,
                    }

        for column in self.configuration_df.columns:
            col_split = column.split(" ")
            col_head = " ".join(col_split[:-1])

            if col_split[-1] == "error" and col_head in CSV_TO_GATE_ID.keys():
                if CSV_TO_GATE_ID[col_head] in TWO_QUBIT_GATES:
                    for qubit_idx, error in enumerate(self.configuration_df[column]):
                        errors_list = error.split(";")
                        errors_list = [err.split(":") for err in errors_list]
                        qubit_connections = [int(err[0]) for err in errors_list]

                        for idx in qubit_connections:
                            if not self.connectivity.has_edge(qubit_idx, idx):
                                self.connectivity.add_edge(qubit_idx, idx)
                            self.connectivity.edges[qubit_idx, idx].setdefault(
                                CSV_TO_GATE_ID[col_head], {}
                            )["Duration"] = 0.0
                            self.connectivity.edges[qubit_idx, idx].setdefault(
                                CSV_TO_GATE_ID[col_head], {}
                            )["Error"] = 0.0

    def get_average_connection_vals(self):
        average_vals = {}
        for column in self.configuration_df:
            col_split = column.split(" ")
            col_head = " ".join(col_split[:-1])

            vals_list = []
            if col_split[-1] == "error" and col_head in CSV_TO_GATE_ID.keys():
                for error in self.configuration_df[column]:
                    if isinstance(error, (int, float)):
                        if math.isnan(error):
                            continue
                        else:
                            vals_list.append(error)
                        continue

                    try:
                        errors_list = error.split(";")
                        errors_list = [err.split(":") for err in errors_list]
                        errors_list = [float(err[1]) for err in errors_list]

                        vals_list.extend(errors_list)
                    except:
                        continue

                average_vals[CSV_TO_GATE_ID[col_head] + " error"] = fmean(vals_list)

            elif col_split[-1] == "(ns)" and col_head in [
                "Single-qubit gate length",
                "Gate length",
            ]:
                for duration in self.configuration_df[column]:
                    if isinstance(duration, (int, float)):
                        vals_list.append(duration)
                        continue

                    try:
                        duration_list = duration.split(";")
                        duration_list = [dur.split(":") for dur in duration_list]
                        duration_list = [float(dur[1]) for dur in duration_list]

                        vals_list.extend(duration_list)
                    except:
                        continue

                if col_head == "Gate length":
                    average_vals["Two Qubit Duration"] = fmean(vals_list)
                else:
                    average_vals["Single Qubit Duration"] = fmean(vals_list)

        return average_vals

    def generate_connectivity(self):
        self.load_gate_errors()
        self.load_gate_durations()

        return self.connectivity

    def load_gate_errors(self):
        for column in self.configuration_df.columns:
            col_split = column.split(" ")
            col_head = " ".join(col_split[:-1])

            if col_split[-1] == "error" and col_head in CSV_TO_GATE_ID.keys():
                gate_name = CSV_TO_GATE_ID[col_head]
                if gate_name in SINGLE_QUBIT_GATES:
                    for qubit_idx, error in enumerate(self.configuration_df[column]):
                        if isinstance(error, float):
                            if error == 0.0 or math.isnan(error):
                                self.connectivity.nodes[qubit_idx][gate_name][
                                    "Error"
                                ] = self.average_vals[gate_name + " error"]
                            else:
                                self.connectivity.nodes[qubit_idx][gate_name][
                                    "Error"
                                ] = error
                        else:
                            self.connectivity.nodes[qubit_idx][gate_name]["Error"] = (
                                self.average_vals[gate_name + " error"]
                            )
                else:
                    for qubit_idx, error in enumerate(self.configuration_df[column]):
                        try:
                            errors_list = error.split(";")
                            errors_list = [err.split(":") for err in errors_list]
                            errors_list = [
                                (int(err[0]), float(err[1])) for err in errors_list
                            ]

                            for idx, err in errors_list:
                                if err == 0.0:
                                    self.connectivity[qubit_idx][idx][gate_name][
                                        "Error"
                                    ] = max(
                                        self.connectivity[qubit_idx][idx][gate_name][
                                            "Error"
                                        ],
                                        self.average_vals[gate_name + " error"],
                                    )
                                else:
                                    self.connectivity[qubit_idx][idx][gate_name][
                                        "Error"
                                    ] = max(
                                        self.connectivity[qubit_idx][idx][gate_name][
                                            "Error"
                                        ],
                                        err,
                                    )

                        except:
                            neighbors = list(self.connectivity.neighbors(qubit_idx))
                            for idx in neighbors:
                                self.connectivity[qubit_idx][idx][gate_name][
                                    "Error"
                                ] = max(
                                    self.connectivity[qubit_idx][idx][gate_name][
                                        "Error"
                                    ],
                                    self.average_vals[gate_name + " error"],
                                )

    def load_gate_durations(self):
        for column in self.configuration_df.columns:
            col_split = column.split(" ")
            col_head = " ".join(col_split[:-1])

            if col_split[-1] == "(ns)" and col_head in [
                "Single-qubit gate length",
                "Gate length",
            ]:
                if col_head == "Single-qubit gate length":
                    for gate_name in self.gate_set:
                        if gate_name in SINGLE_QUBIT_GATES:
                            for idx, duration in enumerate(
                                self.configuration_df[column]
                            ):
                                if isinstance(duration, (int, float)):
                                    self.connectivity.nodes[idx][gate_name][
                                        "Duration"
                                    ] = duration
                                else:
                                    self.connectivity.nodes[idx][gate_name][
                                        "Duration"
                                    ] = self.average_vals["Single Qubit Duration"]

                elif col_head == "Gate length":
                    for gate_name in self.gate_set:
                        if gate_name in TWO_QUBIT_GATES:
                            for qubit_idx, duration in enumerate(
                                self.configuration_df[column]
                            ):
                                if isinstance(duration, (float)):
                                    neighbors = self.connectivity.neighbors(qubit_idx)
                                    self.connectivity[qubit_idx][neighbors[0]][
                                        gate_name
                                    ]["Duration"] = duration
                                    continue

                                try:
                                    duration_list = duration.split(";")
                                    duration_list = [
                                        dur.split(":") for dur in duration_list
                                    ]
                                    duration_list = [
                                        (float(dur[0]), float(dur[1]))
                                        for dur in duration_list
                                    ]

                                    for idx, dur in duration_list:
                                        self.connectivity[qubit_idx][idx][gate_name][
                                            "Duration"
                                        ] = dur
                                except:
                                    neighbors = self.connectivity.neighbors(qubit_idx)
                                    for idx in neighbors:
                                        self.connectivity[qubit_idx][idx][gate_name][
                                            "Duration"
                                        ] = self.average_vals["Two Qubit Duration"]
