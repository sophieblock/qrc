from workflow.simulation.devices.ibm_calibration import LoadQuantumDeviceData
from workflow.simulation.resources import QuantumDevice
import networkx as nx
from typing import Tuple


def IBM_Fez():
    return QuantumDevice(
        device_name="IBM Fez",
        connectivity=LoadQuantumDeviceData(
            "ibm_fez_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "RZZ", "SX", "X"),
    )


def IBM_Boston():
    return QuantumDevice(
        device_name="IBM Boston",
        connectivity=LoadQuantumDeviceData(
            "ibm_boston_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "RZZ", "SX", "X"),
    )


def IBM_Miami():
    return QuantumDevice(
        device_name="IBM Miami",
        connectivity=LoadQuantumDeviceData(
            "ibm_miami_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "SX", "X"),
    )


def IBM_Kingston():
    return QuantumDevice(
        device_name="IBM Kingston",
        connectivity=LoadQuantumDeviceData(
            "ibm_kingston_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "RZZ", "SX", "X"),
    )


def IBM_Pittsburgh():
    return QuantumDevice(
        device_name="IBM Pittsburgh",
        connectivity=LoadQuantumDeviceData(
            "ibm_pittsburgh_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "RZZ", "SX", "X"),
    )


def IBM_Marrakesh():
    return QuantumDevice(
        device_name="IBM Marrakesh",
        connectivity=LoadQuantumDeviceData(
            "ibm_marrakesh_calibrations.csv"
        ).generate_connectivity(),
        gate_set=("CZ", "I", "RX", "RZ", "RZZ", "SX", "X"),
    )


def generate_complete_quantum_device(
    num_qubits: int,
    device_name=None,
    gate_set: Tuple[str] = None,
    singleQ_duration: float = 20e-9,
    doubleQ_duration: float = 50e-9,
    singleQ_error: float = 1e-4,
    doubleQ_error: float = 1e-3,
) -> QuantumDevice:
    """Generates a basic all-to-all connectivity (complete) QuantumDevice to
    be used in the Broker.

    Args:
        num_qubits (int): Number of qubits in the device
        device_name (str, optional): Device name. Defaults to None.
        gate_set (Tuple[str], optional): Tuple of gate names. Must form a universal set. Defaults to None.
        singleQ_duration (float, optional): Duration of single qubit gates. Defaults to 20e-9.
        doubleQ_duration (float, optional): Duration of two qubit gates. Defaults to 50e-9.
        singleQ_fidelity (float, optional): Fidelity of single qubit gates. Defaults to 0.9999.
        doubleQ_fidelity (float, optional): Fidelity of two qubit gates. Defaults to 0.999.

    Returns:
        QuantumDevice: QuantumDevice object to allocate quantum resources for the broker.
    """
    device_name = (
        device_name
        if isinstance(device_name, str)
        else f"{num_qubits} Qubit All-to-All Device"
    )
    connectivity = nx.complete_graph(num_qubits)
    gate_set = gate_set if gate_set is not None else ("CZ", "I", "RX", "RZ", "RZZ", "SX", "X")

    return QuantumDevice(
        device_name=device_name,
        connectivity=connectivity,
        gate_set=gate_set,
        singleQ_time=singleQ_duration,
        doubleQ_time=doubleQ_duration,
        singleQ_error=singleQ_error,
        doubleQ_error=doubleQ_error,
    )


def view_connectivity(device: QuantumDevice):
    connectivity = device.connectivity

    for node in connectivity.nodes:
        print(node, connectivity.nodes[node])
    for edge in connectivity.edges:
        print(edge, connectivity[edge[0]][edge[1]])
