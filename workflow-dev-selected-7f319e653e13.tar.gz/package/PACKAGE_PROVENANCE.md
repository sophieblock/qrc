# Selected work-dev import provenance

This package contains the exact target blobs for the paths represented in the
previously exported 48-path staged diff. It is a selected-path reconstruction,
not a complete repository mirror and not a transfer of Git history.

- Source commit: `7f319e653e13edc17e37d23f4d7d95dff5f60bb3`
- Source tree: `778d9f02c9a0302f0b1c69197bcccb1a6eac6c35`
- Recorded source commit author: Richard J Thompson
- Recorded source commit date: 2026-08-10T11:27:16-07:00
- Recorded source subject: Merge branch 'michael' into 'dev'
- Present paths packaged: 40
- Explicit deletions: 8

The recorded merge and side-commit authors in `SOURCE_COMMITS.tsv` are
confirmed commit metadata. They do not establish line-by-line authorship.
Authorship of any other imported line or path is intentionally not inferred.
The eventual local import commit records transport and reconstruction only; it
does not claim original implementation authorship.
